package com.samyak.shareacar.Models;

import android.os.Parcel;
import android.os.Parcelable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "dailyRideId",
        "fromDailyDate",
        "toDailyDate",
        "dailyTime",
        "pricePerPerson",
        "daysList",
        "noOfPersonAvailable",
        "rideMessage",
        "finalRates"
})

@JsonIgnoreProperties(ignoreUnknown = true)
public class UpdateDailyRideBean implements Parcelable {

    public final static Parcelable.Creator<UpdateDailyRideBean> CREATOR = new Creator<UpdateDailyRideBean>() {


        @SuppressWarnings({
                "unchecked"
        })
        public UpdateDailyRideBean createFromParcel(Parcel in) {
            UpdateDailyRideBean instance = new UpdateDailyRideBean();
            instance.dailyRideId = ((String) in.readValue((String.class.getClassLoader())));
            instance.fromDailyDate = ((String) in.readValue((String.class.getClassLoader())));
            instance.toDailyDate = ((String) in.readValue((String.class.getClassLoader())));
            instance.dailyTime = ((String) in.readValue((String.class.getClassLoader())));
            instance.pricePerPerson = ((String) in.readValue((String.class.getClassLoader())));
            in.readList(instance.daysList, (java.lang.String.class.getClassLoader()));
            instance.noOfPersonAvailable = ((String) in.readValue((String.class.getClassLoader())));
            instance.rideMessage = ((String) in.readValue((String.class.getClassLoader())));
            in.readList(instance.finalRates, (java.lang.Integer.class.getClassLoader()));
            return instance;
        }

        public UpdateDailyRideBean[] newArray(int size) {
            return (new UpdateDailyRideBean[size]);
        }

    };
    @JsonProperty("dailyRideId")
    private String dailyRideId;
    @JsonProperty("fromDailyDate")
    private String fromDailyDate;
    @JsonProperty("toDailyDate")
    private String toDailyDate;
    @JsonProperty("dailyTime")
    private String dailyTime;
    @JsonProperty("pricePerPerson")
    private String pricePerPerson;
    @JsonProperty("daysList")
    private List<String> daysList = new ArrayList<String>();
    @JsonProperty("noOfPersonAvailable")
    private String noOfPersonAvailable;
    @JsonProperty("rideMessage")
    private String rideMessage;
    @JsonProperty("finalRates")
    private List<Integer> finalRates = new ArrayList<Integer>();

    @JsonProperty("dailyRideId")
    public String getDailyRideId() {
        return dailyRideId;
    }

    @JsonProperty("dailyRideId")
    public void setDailyRideId(String dailyRideId) {
        this.dailyRideId = dailyRideId;
    }

    @JsonProperty("fromDailyDate")
    public String getFromDailyDate() {
        return fromDailyDate;
    }

    @JsonProperty("fromDailyDate")
    public void setFromDailyDate(String fromDailyDate) {
        this.fromDailyDate = fromDailyDate;
    }

    @JsonProperty("toDailyDate")
    public String getToDailyDate() {
        return toDailyDate;
    }

    @JsonProperty("toDailyDate")
    public void setToDailyDate(String toDailyDate) {
        this.toDailyDate = toDailyDate;
    }

    @JsonProperty("dailyTime")
    public String getDailyTime() {
        return dailyTime;
    }

    @JsonProperty("dailyTime")
    public void setDailyTime(String dailyTime) {
        this.dailyTime = dailyTime;
    }

    @JsonProperty("pricePerPerson")
    public String getPricePerPerson() {
        return pricePerPerson;
    }

    @JsonProperty("pricePerPerson")
    public void setPricePerPerson(String pricePerPerson) {
        this.pricePerPerson = pricePerPerson;
    }

    @JsonProperty("daysList")
    public List<String> getDaysList() {
        return daysList;
    }

    @JsonProperty("daysList")
    public void setDaysList(List<String> daysList) {
        this.daysList = daysList;
    }

    @JsonProperty("noOfPersonAvailable")
    public String getNoOfPersonAvailable() {
        return noOfPersonAvailable;
    }

    @JsonProperty("noOfPersonAvailable")
    public void setNoOfPersonAvailable(String noOfPersonAvailable) {
        this.noOfPersonAvailable = noOfPersonAvailable;
    }

    @JsonProperty("rideMessage")
    public String getRideMessage() {
        return rideMessage;
    }

    @JsonProperty("rideMessage")
    public void setRideMessage(String rideMessage) {
        this.rideMessage = rideMessage;
    }

    @JsonProperty("finalRates")
    public List<Integer> getFinalRates() {
        return finalRates;
    }

    @JsonProperty("finalRates")
    public void setFinalRates(List<Integer> finalRates) {
        this.finalRates = finalRates;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(dailyRideId).append(fromDailyDate).append(toDailyDate).append(dailyTime).append(pricePerPerson).append(daysList).append(noOfPersonAvailable).append(rideMessage).append(finalRates).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof UpdateDailyRideBean) == false) {
            return false;
        }
        UpdateDailyRideBean rhs = ((UpdateDailyRideBean) other);
        return new EqualsBuilder().append(dailyRideId, rhs.dailyRideId).append(fromDailyDate, rhs.fromDailyDate).append(toDailyDate, rhs.toDailyDate).append(dailyTime, rhs.dailyTime).append(pricePerPerson, rhs.pricePerPerson).append(daysList, rhs.daysList).append(noOfPersonAvailable, rhs.noOfPersonAvailable).append(rideMessage, rhs.rideMessage).append(finalRates, rhs.finalRates).isEquals();
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(dailyRideId);
        dest.writeValue(fromDailyDate);
        dest.writeValue(toDailyDate);
        dest.writeValue(dailyTime);
        dest.writeValue(pricePerPerson);
        dest.writeList(daysList);
        dest.writeValue(noOfPersonAvailable);
        dest.writeValue(rideMessage);
        dest.writeList(finalRates);
    }

    public int describeContents() {
        return 0;
    }

}
