package com.samyak.shareacar.Models;

import android.os.Parcel;
import android.os.Parcelable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "datetimeOfArival",
        "rideMessage",
        "distance",
        "toLong",
        "carName",
        "fromLat",
        "toCity",
        "fromLong",
        "emailId",
        "mobileNo",
        "rideId",
        "userName",
        "userId",
        "carId",
        "noOfSeatsAvailable",
        "toLat",
        "isDeleted",
        "noOfStops",
        "datetimeOfDeparture",
        "pricePerPerson",
        "isExpired",
        "stopageInformation",
        "fromCity",
        "status",
        "rideViewType",
        "timeDaily",
        "daysList"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserRideInfoBean implements Parcelable {
    public final static Parcelable.Creator<UserRideInfoBean> CREATOR = new Creator<UserRideInfoBean>() {

        @SuppressWarnings({
                "unchecked"
        })
        public UserRideInfoBean createFromParcel(Parcel in) {
            UserRideInfoBean instance = new UserRideInfoBean();
            instance.datetimeOfArival = ((String) in.readValue((String.class.getClassLoader())));
            instance.rideMessage = ((String) in.readValue((String.class.getClassLoader())));
            instance.distance = ((String) in.readValue((String.class.getClassLoader())));
            instance.toLong = ((String) in.readValue((String.class.getClassLoader())));
            instance.carName = ((String) in.readValue((String.class.getClassLoader())));
            instance.fromLat = ((String) in.readValue((String.class.getClassLoader())));
            instance.toCity = ((String) in.readValue((String.class.getClassLoader())));
            instance.fromLong = ((String) in.readValue((String.class.getClassLoader())));
            instance.emailId = ((String) in.readValue((String.class.getClassLoader())));
            instance.mobileNo = ((String) in.readValue((String.class.getClassLoader())));
            instance.rideId = ((String) in.readValue((String.class.getClassLoader())));
            instance.userName = ((String) in.readValue((String.class.getClassLoader())));
            instance.userId = ((String) in.readValue((String.class.getClassLoader())));
            instance.carId = ((String) in.readValue((String.class.getClassLoader())));
            instance.noOfSeatsAvailable = ((int) in.readValue((int.class.getClassLoader())));
            instance.toLat = ((String) in.readValue((String.class.getClassLoader())));
            instance.isDeleted = ((int) in.readValue((int.class.getClassLoader())));
            instance.noOfStops = ((String) in.readValue((String.class.getClassLoader())));
            instance.datetimeOfDeparture = ((String) in.readValue((String.class.getClassLoader())));
            instance.pricePerPerson = ((String) in.readValue((String.class.getClassLoader())));
            instance.isExpired = ((boolean) in.readValue((boolean.class.getClassLoader())));
            in.readList(instance.stopageInformation, (StopageInformation.class.getClassLoader()));
            instance.fromCity = ((String) in.readValue((String.class.getClassLoader())));
            instance.status = ((int) in.readValue((int.class.getClassLoader())));
            instance.rideViewType = ((String) in.readValue((String.class.getClassLoader())));
            instance.timeDaily = ((String) in.readValue((String.class.getClassLoader())));
            in.readList(instance.daysList, (String.class.getClassLoader()));
            return instance;
        }

        public UserRideInfoBean[] newArray(int size) {
            return (new UserRideInfoBean[size]);
        }
    };
    @JsonProperty("datetimeOfArival")
    private String datetimeOfArival;
    @JsonProperty("rideMessage")
    private String rideMessage;
    @JsonProperty("distance")
    private String distance;
    @JsonProperty("toLong")
    private String toLong;
    @JsonProperty("carName")
    private String carName;
    @JsonProperty("fromLat")
    private String fromLat;
    @JsonProperty("toCity")
    private String toCity;
    @JsonProperty("fromLong")
    private String fromLong;
    @JsonProperty("emailId")
    private String emailId;
    @JsonProperty("mobileNo")
    private String mobileNo;
    @JsonProperty("rideId")
    private String rideId;
    @JsonProperty("userName")
    private String userName;
    @JsonProperty("userId")
    private String userId;
    @JsonProperty("carId")
    private String carId;
    @JsonProperty("noOfSeatsAvailable")
    private int noOfSeatsAvailable;
    @JsonProperty("toLat")
    private String toLat;
    @JsonProperty("isDeleted")
    private int isDeleted;
    @JsonProperty("noOfStops")
    private String noOfStops;
    @JsonProperty("datetimeOfDeparture")
    private String datetimeOfDeparture;
    @JsonProperty("pricePerPerson")
    private String pricePerPerson;
    @JsonProperty("isExpired")
    private boolean isExpired;
    @JsonProperty("stopageInformation")
    private List<StopageInformation> stopageInformation = new ArrayList<StopageInformation>();
    @JsonProperty("fromCity")
    private String fromCity;
    @JsonProperty("status")
    private int status;
    @JsonProperty("rideViewType")
    private String rideViewType;
    @JsonProperty("timeDaily")
    private String timeDaily;
    @JsonProperty("daysList")
    private ArrayList<String> daysList = new ArrayList<String>();

    @JsonProperty("datetimeOfArival")
    public String getDatetimeOfArival() {
        return datetimeOfArival;
    }

    @JsonProperty("datetimeOfArival")
    public void setDatetimeOfArival(String datetimeOfArival) {
        this.datetimeOfArival = datetimeOfArival;
    }

    @JsonProperty("rideMessage")
    public String getRideMessage() {
        return rideMessage;
    }

    @JsonProperty("rideMessage")
    public void setRideMessage(String rideMessage) {
        this.rideMessage = rideMessage;
    }

    @JsonProperty("distance")
    public String getDistance() {
        return distance;
    }

    @JsonProperty("distance")
    public void setDistance(String distance) {
        this.distance = distance;
    }

    @JsonProperty("toLong")
    public String getToLong() {
        return toLong;
    }

    @JsonProperty("toLong")
    public void setToLong(String toLong) {
        this.toLong = toLong;
    }

    @JsonProperty("carName")
    public String getCarName() {
        return carName;
    }

    @JsonProperty("carName")
    public void setCarName(String carName) {
        this.carName = carName;
    }

    @JsonProperty("fromLat")
    public String getFromLat() {
        return fromLat;
    }

    @JsonProperty("fromLat")
    public void setFromLat(String fromLat) {
        this.fromLat = fromLat;
    }

    @JsonProperty("toCity")
    public String getToCity() {
        return toCity;
    }

    @JsonProperty("toCity")
    public void setToCity(String toCity) {
        this.toCity = toCity;
    }

    @JsonProperty("fromLong")
    public String getFromLong() {
        return fromLong;
    }

    @JsonProperty("fromLong")
    public void setFromLong(String fromLong) {
        this.fromLong = fromLong;
    }

    @JsonProperty("emailId")
    public String getEmailId() {
        return emailId;
    }

    @JsonProperty("emailId")
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    @JsonProperty("mobileNo")
    public String getMobileNo() {
        return mobileNo;
    }

    @JsonProperty("mobileNo")
    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    @JsonProperty("rideId")
    public String getRideId() {
        return rideId;
    }

    @JsonProperty("rideId")
    public void setRideId(String rideId) {
        this.rideId = rideId;
    }

    @JsonProperty("userName")
    public String getUserName() {
        return userName;
    }

    @JsonProperty("userName")
    public void setUserName(String userName) {
        this.userName = userName;
    }

    @JsonProperty("userId")
    public String getUserId() {
        return userId;
    }

    @JsonProperty("userId")
    public void setUserId(String userId) {
        this.userId = userId;
    }

    @JsonProperty("carId")
    public String getCarId() {
        return carId;
    }

    @JsonProperty("carId")
    public void setCarId(String carId) {
        this.carId = carId;
    }

    @JsonProperty("noOfSeatsAvailable")
    public int getNoOfSeatsAvailable() {
        return noOfSeatsAvailable;
    }

    @JsonProperty("noOfSeatsAvailable")
    public void setNoOfSeatsAvailable(int noOfSeatsAvailable) {
        this.noOfSeatsAvailable = noOfSeatsAvailable;
    }

    @JsonProperty("toLat")
    public String getToLat() {
        return toLat;
    }

    @JsonProperty("toLat")
    public void setToLat(String toLat) {
        this.toLat = toLat;
    }

    @JsonProperty("isDeleted")
    public int getIsDeleted() {
        return isDeleted;
    }

    @JsonProperty("isDeleted")
    public void setIsDeleted(int isDeleted) {
        this.isDeleted = isDeleted;
    }

    @JsonProperty("noOfStops")
    public String getNoOfStops() {
        return noOfStops;
    }

    @JsonProperty("noOfStops")
    public void setNoOfStops(String noOfStops) {
        this.noOfStops = noOfStops;
    }

    @JsonProperty("datetimeOfDeparture")
    public String getDatetimeOfDeparture() {
        return datetimeOfDeparture;
    }

    @JsonProperty("datetimeOfDeparture")
    public void setDatetimeOfDeparture(String datetimeOfDeparture) {
        this.datetimeOfDeparture = datetimeOfDeparture;
    }

    @JsonProperty("pricePerPerson")
    public String getPricePerPerson() {
        return pricePerPerson;
    }

    @JsonProperty("pricePerPerson")
    public void setPricePerPerson(String pricePerPerson) {
        this.pricePerPerson = pricePerPerson;
    }

    @JsonProperty("isExpired")
    public boolean getIsExpired() {
        return isExpired;
    }

    @JsonProperty("isExpired")
    public void setIsExpired(boolean isExpired) {
        this.isExpired = isExpired;
    }

    @JsonProperty("stopageInformation")
    public List<StopageInformation> getStopageInformation() {
        return stopageInformation;
    }

    @JsonProperty("stopageInformation")
    public void setStopageInformation(List<StopageInformation> stopageInformation) {
        this.stopageInformation = stopageInformation;
    }

    @JsonProperty("fromCity")
    public String getFromCity() {
        return fromCity;
    }

    @JsonProperty("fromCity")
    public void setFromCity(String fromCity) {
        this.fromCity = fromCity;
    }

    @JsonProperty("status")
    public int getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(int status) {
        this.status = status;
    }

    @JsonProperty("rideViewType")
    public String getRideViewType() {
        return rideViewType;
    }

    @JsonProperty("rideViewType")
    public void setRideViewType(String rideViewType) {
        this.rideViewType = rideViewType;
    }

    @JsonProperty("timeDaily")
    public String getTimeDaily() {
        return timeDaily;
    }

    @JsonProperty("timeDaily")
    public void setTimeDaily(String timeDaily) {
        this.timeDaily = timeDaily;
    }

    @JsonProperty("daysList")
    public ArrayList<String> getDaysList() {
        return daysList;
    }

    @JsonProperty("daysList")
    public void setDaysList(ArrayList<String> daysList) {
        this.daysList = daysList;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(datetimeOfArival).append(rideMessage).append(distance).append(toLong).append(carName).append(fromLat).append(toCity).append(fromLong).append(emailId).append(mobileNo).append(rideId).append(userName).append(userId).append(carId).append(noOfSeatsAvailable).append(toLat).append(isDeleted).append(noOfStops).append(datetimeOfDeparture).append(pricePerPerson).append(isExpired).append(stopageInformation).append(fromCity).append(status).append(rideViewType).append(timeDaily).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof UserRideInfoBean) == false) {
            return false;
        }
        UserRideInfoBean rhs = ((UserRideInfoBean) other);
        return new EqualsBuilder().append(datetimeOfArival, rhs.datetimeOfArival).append(rideMessage, rhs.rideMessage).append(distance, rhs.distance).append(toLong, rhs.toLong).append(carName, rhs.carName).append(fromLat, rhs.fromLat).append(toCity, rhs.toCity).append(fromLong, rhs.fromLong).append(emailId, rhs.emailId).append(mobileNo, rhs.mobileNo).append(rideId, rhs.rideId).append(userName, rhs.userName).append(userId, rhs.userId).append(carId, rhs.carId).append(noOfSeatsAvailable, rhs.noOfSeatsAvailable).append(toLat, rhs.toLat).append(isDeleted, rhs.isDeleted).append(noOfStops, rhs.noOfStops).append(datetimeOfDeparture, rhs.datetimeOfDeparture).append(pricePerPerson, rhs.pricePerPerson).append(isExpired, rhs.isExpired).append(stopageInformation, rhs.stopageInformation).append(fromCity, rhs.fromCity).append(status, rhs.status).append(rideViewType, rhs.rideViewType).append(timeDaily, rhs.timeDaily).isEquals();
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(datetimeOfArival);
        dest.writeValue(rideMessage);
        dest.writeValue(distance);
        dest.writeValue(toLong);
        dest.writeValue(carName);
        dest.writeValue(fromLat);
        dest.writeValue(toCity);
        dest.writeValue(fromLong);
        dest.writeValue(emailId);
        dest.writeValue(mobileNo);
        dest.writeValue(rideId);
        dest.writeValue(userName);
        dest.writeValue(userId);
        dest.writeValue(carId);
        dest.writeValue(noOfSeatsAvailable);
        dest.writeValue(toLat);
        dest.writeValue(isDeleted);
        dest.writeValue(noOfStops);
        dest.writeValue(datetimeOfDeparture);
        dest.writeValue(pricePerPerson);
        dest.writeValue(isExpired);
        dest.writeList(stopageInformation);
        dest.writeValue(fromCity);
        dest.writeValue(status);
        dest.writeValue(rideViewType);
        dest.writeValue(timeDaily);
        dest.writeList(daysList);
    }

    public int describeContents() {
        return 0;
    }

}
