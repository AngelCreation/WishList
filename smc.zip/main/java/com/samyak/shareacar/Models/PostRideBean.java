package com.samyak.shareacar.Models;

import android.os.Parcel;
import android.os.Parcelable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.ArrayList;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "userId",
        "dateRide",
        "timeRide",
        "fromCity",
        "toCity",
        "fromLat",
        "fromLong",
        "toLat",
        "toLong",
        "total",
        "pricePerPerson",
        "daysList",
        "noOfPerson",
        "rideMessage",
        "rideTime",
        "stops",
        "distance",
        "fromDailyDate",
        "toDailyDate",
        "timeDaily",
        "isRideDaily"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class PostRideBean implements Parcelable {
    public final static Parcelable.Creator<PostRideBean> CREATOR = new Creator<PostRideBean>() {

        @SuppressWarnings({
                "unchecked"
        })
        public PostRideBean createFromParcel(Parcel in) {
            PostRideBean instance = new PostRideBean();
            instance.userId = ((int) in.readValue((int.class.getClassLoader())));
            instance.dateRide = ((String) in.readValue((String.class.getClassLoader())));
            instance.timeRide = ((String) in.readValue((String.class.getClassLoader())));
            instance.fromCity = ((String) in.readValue((String.class.getClassLoader())));
            instance.toCity = ((String) in.readValue((String.class.getClassLoader())));
            instance.fromLat = ((double) in.readValue((double.class.getClassLoader())));
            instance.fromLong = ((double) in.readValue((double.class.getClassLoader())));
            instance.toLat = ((double) in.readValue((double.class.getClassLoader())));
            instance.toLong = ((double) in.readValue((double.class.getClassLoader())));
            instance.total = ((String) in.readValue((String.class.getClassLoader())));
            in.readList(instance.pricePerPerson, (java.lang.Integer.class.getClassLoader()));
            in.readList(instance.daysList, (java.lang.String.class.getClassLoader()));
            instance.noOfPerson = ((String) in.readValue((String.class.getClassLoader())));
            instance.rideMessage = ((String) in.readValue((String.class.getClassLoader())));
            in.readList(instance.rideTime, (java.lang.String.class.getClassLoader()));
            in.readList(instance.stops, (java.lang.String.class.getClassLoader()));
            in.readList(instance.distance, (java.lang.Integer.class.getClassLoader()));
            instance.fromDailyDate = ((String) in.readValue((String.class.getClassLoader())));
            instance.toDailyDate = ((String) in.readValue((String.class.getClassLoader())));
            instance.timeDaily = ((String) in.readValue((String.class.getClassLoader())));
            instance.isRideDaily = ((boolean) in.readValue((boolean.class.getClassLoader())));
            return instance;
        }

        public PostRideBean[] newArray(int size) {
            return (new PostRideBean[size]);
        }

    };
    @JsonProperty("userId")
    private int userId;
    @JsonProperty("dateRide")
    private String dateRide;
    @JsonProperty("timeRide")
    private String timeRide;
    @JsonProperty("fromCity")
    private String fromCity;
    @JsonProperty("toCity")
    private String toCity;
    @JsonProperty("fromLat")
    private double fromLat;
    @JsonProperty("fromLong")
    private double fromLong;
    @JsonProperty("toLat")
    private double toLat;
    @JsonProperty("toLong")
    private double toLong;
    @JsonProperty("total")
    private String total;
    @JsonProperty("pricePerPerson")
    private ArrayList<Integer> pricePerPerson = new ArrayList<Integer>();
    @JsonProperty("daysList")
    private ArrayList<String> daysList = new ArrayList<String>();
    @JsonProperty("noOfPerson")
    private String noOfPerson;
    @JsonProperty("rideMessage")
    private String rideMessage;
    @JsonProperty("rideTime")
    private ArrayList<String> rideTime = new ArrayList<String>();
    @JsonProperty("stops")
    private ArrayList<String> stops = new ArrayList<String>();
    @JsonProperty("distance")
    private ArrayList<Integer> distance = new ArrayList<Integer>();
    @JsonProperty("fromDailyDate")
    private String fromDailyDate;
    @JsonProperty("toDailyDate")
    private String toDailyDate;
    @JsonProperty("timeDaily")
    private String timeDaily;
    @JsonProperty("isRideDaily")
    private boolean isRideDaily;

    @JsonProperty("userId")
    public int getUserId() {
        return userId;
    }

    @JsonProperty("userId")
    public void setUserId(int userId) {
        this.userId = userId;
    }

    @JsonProperty("dateRide")
    public String getDateRide() {
        return dateRide;
    }

    @JsonProperty("dateRide")
    public void setDateRide(String dateRide) {
        this.dateRide = dateRide;
    }

    @JsonProperty("timeRide")
    public String getTimeRide() {
        return timeRide;
    }

    @JsonProperty("timeRide")
    public void setTimeRide(String timeRide) {
        this.timeRide = timeRide;
    }

    @JsonProperty("fromCity")
    public String getFromCity() {
        return fromCity;
    }

    @JsonProperty("fromCity")
    public void setFromCity(String fromCity) {
        this.fromCity = fromCity;
    }

    @JsonProperty("toCity")
    public String getToCity() {
        return toCity;
    }

    @JsonProperty("toCity")
    public void setToCity(String toCity) {
        this.toCity = toCity;
    }

    @JsonProperty("fromLat")
    public double getFromLat() {
        return fromLat;
    }

    @JsonProperty("fromLat")
    public void setFromLat(double fromLat) {
        this.fromLat = fromLat;
    }

    @JsonProperty("fromLong")
    public double getFromLong() {
        return fromLong;
    }

    @JsonProperty("fromLong")
    public void setFromLong(double fromLong) {
        this.fromLong = fromLong;
    }

    @JsonProperty("toLat")
    public double getToLat() {
        return toLat;
    }

    @JsonProperty("toLat")
    public void setToLat(double toLat) {
        this.toLat = toLat;
    }

    @JsonProperty("toLong")
    public double getToLong() {
        return toLong;
    }

    @JsonProperty("toLong")
    public void setToLong(double toLong) {
        this.toLong = toLong;
    }

    @JsonProperty("total")
    public String getTotal() {
        return total;
    }

    @JsonProperty("total")
    public void setTotal(String total) {
        this.total = total;
    }

    @JsonProperty("pricePerPerson")
    public ArrayList<Integer> getPricePerPerson() {
        return pricePerPerson;
    }

    @JsonProperty("pricePerPerson")
    public void setPricePerPerson(ArrayList<Integer> pricePerPerson) {
        this.pricePerPerson = pricePerPerson;
    }

    @JsonProperty("daysList")
    public ArrayList<String> getDaysList() {
        return daysList;
    }

    @JsonProperty("daysList")
    public void setDaysList(ArrayList<String> daysList) {
        this.daysList = daysList;
    }

    @JsonProperty("noOfPerson")
    public String getNoOfPerson() {
        return noOfPerson;
    }

    @JsonProperty("noOfPerson")
    public void setNoOfPerson(String noOfPerson) {
        this.noOfPerson = noOfPerson;
    }

    @JsonProperty("rideMessage")
    public String getRideMessage() {
        return rideMessage;
    }

    @JsonProperty("rideMessage")
    public void setRideMessage(String rideMessage) {
        this.rideMessage = rideMessage;
    }

    @JsonProperty("rideTime")
    public ArrayList<String> getRideTime() {
        return rideTime;
    }

    @JsonProperty("rideTime")
    public void setRideTime(ArrayList<String> rideTime) {
        this.rideTime = rideTime;
    }

    @JsonProperty("stops")
    public ArrayList<String> getStops() {
        return stops;
    }

    @JsonProperty("stops")
    public void setStops(ArrayList<String> stops) {
        this.stops = stops;
    }

    @JsonProperty("distance")
    public ArrayList<Integer> getDistance() {
        return distance;
    }

    @JsonProperty("distance")
    public void setDistance(ArrayList<Integer> distance) {
        this.distance = distance;
    }

    @JsonProperty("fromDailyDate")
    public String getFromDailyDate() {
        return fromDailyDate;
    }

    @JsonProperty("fromDailyDate")
    public void setFromDailyDate(String fromDailyDate) {
        this.fromDailyDate = fromDailyDate;
    }

    @JsonProperty("toDailyDate")
    public String getToDailyDate() {
        return toDailyDate;
    }

    @JsonProperty("toDailyDate")
    public void setToDailyDate(String toDailyDate) {
        this.toDailyDate = toDailyDate;
    }

    @JsonProperty("timeDaily")
    public String getTimeDaily() {
        return timeDaily;
    }

    @JsonProperty("timeDaily")
    public void setTimeDaily(String timeDaily) {
        this.timeDaily = timeDaily;
    }

    @JsonProperty("isRideDaily")
    public boolean getIsRideDaily() {
        return isRideDaily;
    }

    @JsonProperty("isRideDaily")
    public void setIsRideDaily(boolean isRideDaily) {
        this.isRideDaily = isRideDaily;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(userId).append(dateRide).append(timeRide).append(fromCity).append(toCity).append(fromLat).append(fromLong).append(toLat).append(toLong).append(total).append(pricePerPerson).append(noOfPerson).append(rideMessage).append(rideTime).append(stops).append(distance).append(fromDailyDate).append(toDailyDate).append(timeDaily).append(isRideDaily).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof PostRideBean) == false) {
            return false;
        }
        PostRideBean rhs = ((PostRideBean) other);
        return new EqualsBuilder().append(userId, rhs.userId).append(dateRide, rhs.dateRide).append(timeRide, rhs.timeRide).append(fromCity, rhs.fromCity).append(toCity, rhs.toCity).append(fromLat, rhs.fromLat).append(fromLong, rhs.fromLong).append(toLat, rhs.toLat).append(toLong, rhs.toLong).append(total, rhs.total).append(pricePerPerson, rhs.pricePerPerson).append(noOfPerson, rhs.noOfPerson).append(rideMessage, rhs.rideMessage).append(rideTime, rhs.rideTime).append(stops, rhs.stops).append(distance, rhs.distance).append(fromDailyDate, rhs.fromDailyDate).append(toDailyDate, rhs.toDailyDate).append(timeDaily, rhs.timeDaily).append(isRideDaily, rhs.isRideDaily).isEquals();
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(userId);
        dest.writeValue(dateRide);
        dest.writeValue(timeRide);
        dest.writeValue(fromCity);
        dest.writeValue(toCity);
        dest.writeValue(fromLat);
        dest.writeValue(fromLong);
        dest.writeValue(toLat);
        dest.writeValue(toLong);
        dest.writeValue(total);
        dest.writeList(pricePerPerson);
        dest.writeValue(noOfPerson);
        dest.writeValue(rideMessage);
        dest.writeList(rideTime);
        dest.writeList(stops);
        dest.writeList(daysList);
        dest.writeList(distance);
        dest.writeValue(fromDailyDate);
        dest.writeValue(toDailyDate);
        dest.writeValue(timeDaily);
        dest.writeValue(isRideDaily);
    }

    public int describeContents() {
        return 0;
    }

}
