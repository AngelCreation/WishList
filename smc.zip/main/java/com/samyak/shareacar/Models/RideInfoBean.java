package com.samyak.shareacar.Models;


import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)

@JsonPropertyOrder({
        "datetimeOfArival",
        "rideMessage",
        "distance",
        "toLong",
        "carName",
        "fromLat",
        "toCity",
        "fromLong",
        "emailId",
        "mobileNo",
        "rideId",
        "userName",
        "userId",
        "carId",
        "noOfSeatsAvailable",
        "toLat",
        "isDeleted",
        "noOfStops",
        "datetimeOfDeparture",
        "pricePerPerson",
        "fromCity",
        "status"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class RideInfoBean {

    @JsonProperty("datetimeOfArival")
    private String datetimeOfArival;
    @JsonProperty("rideMessage")
    private String rideMessage;
    @JsonProperty("distance")
    private String distance;
    @JsonProperty("toLong")
    private String toLong;
    @JsonProperty("carName")
    private String carName;
    @JsonProperty("fromLat")
    private String fromLat;
    @JsonProperty("toCity")
    private String toCity;
    @JsonProperty("fromLong")
    private String fromLong;
    @JsonProperty("emailId")
    private String emailId;
    @JsonProperty("mobileNo")
    private String mobileNo;
    @JsonProperty("rideId")
    private String rideId;
    @JsonProperty("userName")
    private String userName;
    @JsonProperty("userId")
    private String userId;
    @JsonProperty("carId")
    private String carId;
    @JsonProperty("noOfSeatsAvailable")
    private int noOfSeatsAvailable;
    @JsonProperty("toLat")
    private String toLat;
    @JsonProperty("isDeleted")
    private int isDeleted;
    @JsonProperty("noOfStops")
    private String noOfStops;
    @JsonProperty("datetimeOfDeparture")
    private String datetimeOfDeparture;
    @JsonProperty("pricePerPerson")
    private String pricePerPerson;
    @JsonProperty("fromCity")
    private String fromCity;
    @JsonProperty("status")
    private int status;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * @return The datetimeOfArival
     */
    @JsonProperty("datetimeOfArival")
    public String getDatetimeOfArival() {
        return datetimeOfArival;
    }

    /**
     * @param datetimeOfArival The datetimeOfArival
     */
    @JsonProperty("datetimeOfArival")
    public void setDatetimeOfArival(String datetimeOfArival) {
        this.datetimeOfArival = datetimeOfArival;
    }

    /**
     * @return The rideMessage
     */
    @JsonProperty("rideMessage")
    public String getRideMessage() {
        return rideMessage;
    }

    /**
     * @param rideMessage The rideMessage
     */
    @JsonProperty("rideMessage")
    public void setRideMessage(String rideMessage) {
        this.rideMessage = rideMessage;
    }

    /**
     * @return The distance
     */
    @JsonProperty("distance")
    public String getDistance() {
        return distance;
    }

    /**
     * @param distance The distance
     */
    @JsonProperty("distance")
    public void setDistance(String distance) {
        this.distance = distance;
    }

    /**
     * @return The toLong
     */
    @JsonProperty("toLong")
    public String getToLong() {
        return toLong;
    }

    /**
     * @param toLong The toLong
     */
    @JsonProperty("toLong")
    public void setToLong(String toLong) {
        this.toLong = toLong;
    }

    /**
     * @return The carName
     */
    @JsonProperty("carName")
    public String getCarName() {
        return carName;
    }

    /**
     * @param carName The carName
     */
    @JsonProperty("carName")
    public void setCarName(String carName) {
        this.carName = carName;
    }

    /**
     * @return The fromLat
     */
    @JsonProperty("fromLat")
    public String getFromLat() {
        return fromLat;
    }

    /**
     * @param fromLat The fromLat
     */
    @JsonProperty("fromLat")
    public void setFromLat(String fromLat) {
        this.fromLat = fromLat;
    }

    /**
     * @return The toCity
     */
    @JsonProperty("toCity")
    public String getToCity() {
        return toCity;
    }

    /**
     * @param toCity The toCity
     */
    @JsonProperty("toCity")
    public void setToCity(String toCity) {
        this.toCity = toCity;
    }

    /**
     * @return The fromLong
     */
    @JsonProperty("fromLong")
    public String getFromLong() {
        return fromLong;
    }

    /**
     * @param fromLong The fromLong
     */
    @JsonProperty("fromLong")
    public void setFromLong(String fromLong) {
        this.fromLong = fromLong;
    }

    /**
     * @return The emailId
     */
    @JsonProperty("emailId")
    public String getEmailId() {
        return emailId;
    }

    /**
     * @param emailId The emailId
     */
    @JsonProperty("emailId")
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    /**
     * @return The mobileNo
     */
    @JsonProperty("mobileNo")
    public String getMobileNo() {
        return mobileNo;
    }

    /**
     * @param mobileNo The mobileNo
     */
    @JsonProperty("mobileNo")
    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    /**
     * @return The rideId
     */
    @JsonProperty("rideId")
    public String getRideId() {
        return rideId;
    }

    /**
     * @param rideId The rideId
     */
    @JsonProperty("rideId")
    public void setRideId(String rideId) {
        this.rideId = rideId;
    }

    /**
     * @return The userName
     */
    @JsonProperty("userName")
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName The userName
     */
    @JsonProperty("userName")
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * @return The userId
     */
    @JsonProperty("userId")
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId The userId
     */
    @JsonProperty("userId")
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * @return The carId
     */
    @JsonProperty("carId")
    public String getCarId() {
        return carId;
    }

    /**
     * @param carId The carId
     */
    @JsonProperty("carId")
    public void setCarId(String carId) {
        this.carId = carId;
    }

    /**
     * @return The noOfSeatsAvailable
     */
    @JsonProperty("noOfSeatsAvailable")
    public int getNoOfSeatsAvailable() {
        return noOfSeatsAvailable;
    }

    /**
     * @param noOfSeatsAvailable The noOfSeatsAvailable
     */
    @JsonProperty("noOfSeatsAvailable")
    public void setNoOfSeatsAvailable(int noOfSeatsAvailable) {
        this.noOfSeatsAvailable = noOfSeatsAvailable;
    }

    /**
     * @return The toLat
     */
    @JsonProperty("toLat")
    public String getToLat() {
        return toLat;
    }

    /**
     * @param toLat The toLat
     */
    @JsonProperty("toLat")
    public void setToLat(String toLat) {
        this.toLat = toLat;
    }

    /**
     * @return The isDeleted
     */
    @JsonProperty("isDeleted")
    public int getIsDeleted() {
        return isDeleted;
    }

    /**
     * @param isDeleted The isDeleted
     */
    @JsonProperty("isDeleted")
    public void setIsDeleted(int isDeleted) {
        this.isDeleted = isDeleted;
    }

    /**
     * @return The noOfStops
     */
    @JsonProperty("noOfStops")
    public String getNoOfStops() {
        return noOfStops;
    }

    /**
     * @param noOfStops The noOfStops
     */
    @JsonProperty("noOfStops")
    public void setNoOfStops(String noOfStops) {
        this.noOfStops = noOfStops;
    }

    /**
     * @return The datetimeOfDeparture
     */
    @JsonProperty("datetimeOfDeparture")
    public String getDatetimeOfDeparture() {
        return datetimeOfDeparture;
    }

    /**
     * @param datetimeOfDeparture The datetimeOfDeparture
     */
    @JsonProperty("datetimeOfDeparture")
    public void setDatetimeOfDeparture(String datetimeOfDeparture) {
        this.datetimeOfDeparture = datetimeOfDeparture;
    }

    /**
     * @return The pricePerPerson
     */
    @JsonProperty("pricePerPerson")
    public String getPricePerPerson() {
        return pricePerPerson;
    }

    /**
     * @param pricePerPerson The pricePerPerson
     */
    @JsonProperty("pricePerPerson")
    public void setPricePerPerson(String pricePerPerson) {
        this.pricePerPerson = pricePerPerson;
    }

    /**
     * @return The fromCity
     */
    @JsonProperty("fromCity")
    public String getFromCity() {
        return fromCity;
    }

    /**
     * @param fromCity The fromCity
     */
    @JsonProperty("fromCity")
    public void setFromCity(String fromCity) {
        this.fromCity = fromCity;
    }

    /**
     * @return The status
     */
    @JsonProperty("status")
    public int getStatus() {
        return status;
    }

    /**
     * @param status The status
     */
    @JsonProperty("status")
    public void setStatus(int status) {
        this.status = status;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
