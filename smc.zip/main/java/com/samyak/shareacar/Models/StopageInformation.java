package com.samyak.shareacar.Models;

import android.os.Parcel;
import android.os.Parcelable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "stopageToPlaceName",
        "travelTime",
        "distance",
        "stopageId",
        "pricePerPerson",
        "rideId",
        "stopageFromPlaceName"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class StopageInformation implements Parcelable {
    public final static Parcelable.Creator<StopageInformation> CREATOR = new Creator<StopageInformation>() {

        @SuppressWarnings({
                "unchecked"
        })
        public StopageInformation createFromParcel(Parcel in) {
            StopageInformation instance = new StopageInformation();
            instance.stopageToPlaceName = ((String) in.readValue((String.class.getClassLoader())));
            instance.travelTime = ((String) in.readValue((String.class.getClassLoader())));
            instance.distance = ((String) in.readValue((String.class.getClassLoader())));
            instance.stopageId = ((String) in.readValue((String.class.getClassLoader())));
            instance.pricePerPerson = ((String) in.readValue((String.class.getClassLoader())));
            instance.rideId = ((String) in.readValue((String.class.getClassLoader())));
            instance.stopageFromPlaceName = ((String) in.readValue((String.class.getClassLoader())));
            return instance;
        }

        public StopageInformation[] newArray(int size) {
            return (new StopageInformation[size]);
        }

    };
    @JsonProperty("stopageToPlaceName")
    private String stopageToPlaceName;
    @JsonProperty("travelTime")
    private String travelTime;
    @JsonProperty("distance")
    private String distance;
    @JsonProperty("stopageId")
    private String stopageId;
    @JsonProperty("pricePerPerson")
    private String pricePerPerson;
    @JsonProperty("rideId")
    private String rideId;
    @JsonProperty("stopageFromPlaceName")
    private String stopageFromPlaceName;

    @JsonProperty("stopageToPlaceName")
    public String getStopageToPlaceName() {
        return stopageToPlaceName;
    }

    @JsonProperty("stopageToPlaceName")
    public void setStopageToPlaceName(String stopageToPlaceName) {
        this.stopageToPlaceName = stopageToPlaceName;
    }

    @JsonProperty("travelTime")
    public String getTravelTime() {
        return travelTime;
    }

    @JsonProperty("travelTime")
    public void setTravelTime(String travelTime) {
        this.travelTime = travelTime;
    }

    @JsonProperty("distance")
    public String getDistance() {
        return distance;
    }

    @JsonProperty("distance")
    public void setDistance(String distance) {
        this.distance = distance;
    }

    @JsonProperty("stopageId")
    public String getStopageId() {
        return stopageId;
    }

    @JsonProperty("stopageId")
    public void setStopageId(String stopageId) {
        this.stopageId = stopageId;
    }

    @JsonProperty("pricePerPerson")
    public String getPricePerPerson() {
        return pricePerPerson;
    }

    @JsonProperty("pricePerPerson")
    public void setPricePerPerson(String pricePerPerson) {
        this.pricePerPerson = pricePerPerson;
    }

    @JsonProperty("rideId")
    public String getRideId() {
        return rideId;
    }

    @JsonProperty("rideId")
    public void setRideId(String rideId) {
        this.rideId = rideId;
    }

    @JsonProperty("stopageFromPlaceName")
    public String getStopageFromPlaceName() {
        return stopageFromPlaceName;
    }

    @JsonProperty("stopageFromPlaceName")
    public void setStopageFromPlaceName(String stopageFromPlaceName) {
        this.stopageFromPlaceName = stopageFromPlaceName;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(stopageToPlaceName).append(travelTime).append(distance).append(stopageId).append(pricePerPerson).append(rideId).append(stopageFromPlaceName).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof StopageInformation) == false) {
            return false;
        }
        StopageInformation rhs = ((StopageInformation) other);
        return new EqualsBuilder().append(stopageToPlaceName, rhs.stopageToPlaceName).append(travelTime, rhs.travelTime).append(distance, rhs.distance).append(stopageId, rhs.stopageId).append(pricePerPerson, rhs.pricePerPerson).append(rideId, rhs.rideId).append(stopageFromPlaceName, rhs.stopageFromPlaceName).isEquals();
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(stopageToPlaceName);
        dest.writeValue(travelTime);
        dest.writeValue(distance);
        dest.writeValue(stopageId);
        dest.writeValue(pricePerPerson);
        dest.writeValue(rideId);
        dest.writeValue(stopageFromPlaceName);
    }

    public int describeContents() {
        return 0;
    }

}
