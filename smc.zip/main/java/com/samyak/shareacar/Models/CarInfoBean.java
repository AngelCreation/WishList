package com.samyak.shareacar.Models;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)

@JsonPropertyOrder({
        "carCompany",
        "carType",
        "fuelType",
        "carName",
        "carYear"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class CarInfoBean {

    @JsonProperty("carCompany")
    private String carCompany;
    @JsonProperty("carType")
    private String carType;
    @JsonProperty("fuelType")
    private String fuelType;
    @JsonProperty("carName")
    private String carName;
    @JsonProperty("carYear")
    private String carYear;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * @return The carCompany
     */
    @JsonProperty("carCompany")
    public String getCarCompany() {
        return carCompany;
    }

    /**
     * @param carCompany The carCompany
     */
    @JsonProperty("carCompany")
    public void setCarCompany(String carCompany) {
        this.carCompany = carCompany;
    }

    /**
     * @return The carType
     */
    @JsonProperty("carType")
    public String getCarType() {
        return carType;
    }

    /**
     * @param carType The carType
     */
    @JsonProperty("carType")
    public void setCarType(String carType) {
        this.carType = carType;
    }

    /**
     * @return The fuelType
     */
    @JsonProperty("fuelType")
    public String getFuelType() {
        return fuelType;
    }

    /**
     * @param fuelType The fuelType
     */
    @JsonProperty("fuelType")
    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    /**
     * @return The carName
     */
    @JsonProperty("carName")
    public String getCarName() {
        return carName;
    }

    /**
     * @param carName The carName
     */
    @JsonProperty("carName")
    public void setCarName(String carName) {
        this.carName = carName;
    }

    /**
     * @return The carYear
     */
    @JsonProperty("carYear")
    public String getCarYear() {
        return carYear;
    }

    /**
     * @param carYear The carYear
     */
    @JsonProperty("carYear")
    public void setCarYear(String carYear) {
        this.carYear = carYear;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
