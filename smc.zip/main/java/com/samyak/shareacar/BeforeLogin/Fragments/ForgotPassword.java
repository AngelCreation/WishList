package com.samyak.shareacar.BeforeLogin.Fragments;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.androidadvance.topsnackbar.TSnackbar;
import com.samyak.shareacar.R;
import com.samyak.shareacar.RetrofitApi.ShareACarApiService;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.Context.MODE_PRIVATE;

public class ForgotPassword extends Fragment {

    TextView textviewTitle;
    ImageView header;
    Call<ResponseBody> call;
    String result;
    EditText _emailText;
    Button _forgotPasswordButton;
    TextView _loginLink;
    //    private static final int REQUEST_SIGNUP = 0;
    private ProgressDialog progress;

    public ForgotPassword() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_forgot_password, container, false);

        _emailText = (EditText) view.findViewById(R.id.input_email_forgotPassword);
        _forgotPasswordButton = (Button) view.findViewById(R.id.btn_submit_forgotPassword);
        _loginLink = (TextView) view.findViewById(R.id.link_login_forgotPassword);

        SQLiteDatabase mydatabase = getActivity().openOrCreateDatabase("shareACar", MODE_PRIVATE, null);
        mydatabase.execSQL("CREATE TABLE IF NOT EXISTS loginInfo(userId INTEGER ,carId INTEGER , contactNo TEXT , emailId TEXT, userName TEXT);");
        Cursor c = mydatabase.rawQuery("Select * from loginInfo", null);

        if (c != null) {
            if (c.moveToFirst()) {
                do {
                    int userId = c.getInt(c.getColumnIndex("userId"));

                } while (c.moveToNext());
            }
        }

        _emailText.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_UP) {
                    hideKeyBoard(v);
                    try {
                        forgotPassword(v);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                return false;
            }
        });

        _forgotPasswordButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //close keyboard
                hideKeyBoard(v);
                try {
                    forgotPassword(v);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        _loginLink.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Fragment fragment = getFragmentManager().findFragmentById(R.id.frame);

                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
                ft.hide(fragment);
                ft.add(R.id.frame, new Login());
//                ft.addToBackStack(null);
                ft.commit();

            }
        });
        return view;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public void hideKeyBoard(View v) {
        InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        }
    }

    public void forgotPassword(final View view) throws ExecutionException, InterruptedException {
        if (validate(view)) {

            progress = new ProgressDialog(getActivity(),
                    R.style.appThemeDialogue);
            progress.setMessage("Loading...");
            progress.show();

            String email = _emailText.getText().toString();

            call = new ShareACarApiService(getActivity()).getShareACarApi().forgotPass(email);
            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    if ((progress != null) && progress.isShowing()) {
                        progress.dismiss();
                    }
                    if (response.code() == 200) {
                        try {
                            result = response.body().string();
                            checkForgotPass(view);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else {
                        TSnackbar snackbar = TSnackbar
                                .make(view, "Can't connect to server", TSnackbar.LENGTH_LONG);
                        snackbar.setActionTextColor(Color.WHITE);
                        View snackbarView = snackbar.getView();
                        snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                        textView.setTextColor(Color.WHITE);
                        textView.setTypeface(Typeface.DEFAULT_BOLD);
                        snackbar.show();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    if ((progress != null) && progress.isShowing()) {
                        progress.dismiss();
                    }
                    TSnackbar snackbar = TSnackbar
                            .make(view, "Please check your connection", TSnackbar.LENGTH_LONG);
                    snackbar.setActionTextColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                    textView.setTextColor(Color.WHITE);
                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                    snackbar.show();
                }
            });
        }
    }

    private void checkForgotPass(View view) {

        String output[] = result.split("::");
//        String userId;

        if (output[0].equalsIgnoreCase("Success")) {
            LayoutInflater factory = LayoutInflater.from(getActivity());
            final View confirmDialogView = factory.inflate(R.layout.alertbox, null);
            final Dialog confirmDialog = new Dialog(getActivity());
            confirmDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            confirmDialog.setContentView(confirmDialogView);
            TextView message = (TextView) confirmDialogView.findViewById(R.id.message);
            message.setText(output[1]);
            ((TextView) confirmDialogView.findViewById(R.id.confirm)).setText("Success!");
            ((TextView) confirmDialogView.findViewById(R.id.getPro)).setText("Ok");
            ((Button) confirmDialogView.findViewById(R.id.cancel)).setVisibility(View.GONE);
            ((Button) confirmDialogView.findViewById(R.id.ok)).setVisibility(View.GONE);
            confirmDialogView.findViewById(R.id.getPro).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //your business logic
                    confirmDialog.dismiss();
                    moveToLogin();
                }
            });

            confirmDialog.show();

        } else if (output[0].equalsIgnoreCase("Failed")) {
            TSnackbar snackbar = TSnackbar
                    .make(view, "EmailId doesn't exist", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();


        } else {
            TSnackbar snackbar = TSnackbar
                    .make(view, "Please check your connection", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();
        }
    }

    public void moveToLogin() {
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
        ft.replace(R.id.frame, new Login());
        ft.addToBackStack(null);
        ft.commit();
    }

    public boolean validate(final View view) {
        boolean valid = true;

        String email = _emailText.getText().toString();

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {

            TSnackbar snackbar = TSnackbar
                    .make(view, "Please enter valid email", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
        }
        return valid;
    }

    @Override
    public void onResume() {
        textviewTitle = (TextView) getActivity().findViewById(R.id.textviewTitle);
        if (textviewTitle.getVisibility() == View.GONE)
            textviewTitle.setVisibility(View.VISIBLE);
        textviewTitle.setText("Forgot Password");

        header = (ImageView) getActivity().findViewById(R.id.tv_header_title);
        if (header.getVisibility() == View.VISIBLE)
            header.setVisibility(View.GONE);

        super.onResume();
    }


}
