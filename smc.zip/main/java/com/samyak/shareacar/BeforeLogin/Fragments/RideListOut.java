package com.samyak.shareacar.BeforeLogin.Fragments;

import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.samyak.shareacar.Adapters.rideAdapter;
import com.samyak.shareacar.Models.UserRideInfoBean;
import com.samyak.shareacar.R;
import com.samyak.shareacar.RetrofitApi.ShareACarApiService;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class RideListOut extends Fragment {

    public static boolean changeTitle = false;
    TextView textviewTitle = null;
    ImageView header;
    //    private String LOG = "rideListFragment";
    TextView fromCity = null;
    TextView toCity = null;
    TextView rideDate = null;
    Button Submit = null;
    //    public static boolean loadFlag = false;
    String months[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

    List<UserRideInfoBean> rideInfoBeanArrayList = new ArrayList<>();

    LinearLayout connecting;
    TextView textviewM1, textviewM2, textviewWelcome, textviewM3;

    int userId = 0;

    View view;

    Call<List<UserRideInfoBean>> call;

    public RideListOut() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_ride_list, container, false);

        changeTitle = true;

        connecting = (LinearLayout) view.findViewById(R.id.connecting);
        textviewM1 = (TextView) view.findViewById(R.id.textviewM1);
        textviewM2 = (TextView) view.findViewById(R.id.textviewM2);
        textviewM3 = (TextView) view.findViewById(R.id.textviewM3);
        textviewWelcome = (TextView) view.findViewById(R.id.textviewWelcome);
        connecting.setVisibility(View.VISIBLE);

        rideDate = (TextView) view.findViewById(R.id.txt_find_ride_date);
//        rideDate.setTextColor(ColorStateList.valueOf(Color.rgb(204,204,204)));
        toCity = (TextView) view.findViewById(R.id.txt_to_city);
        fromCity = (TextView) view.findViewById(R.id.txt_from_city);

        Bundle bundle = this.getArguments();
        String startCityFind = bundle.getString("startCityFind");
        String destCityFind = bundle.getString("destCityFind");
        String rideDateTxt1 = bundle.getString("rideDateTxt");
        String dateArray[] = rideDateTxt1.split("-");

        String rideDateTxt = dateArray[0] + " " + months[Integer.parseInt(dateArray[1]) - 1] + " " + dateArray[2];
        rideDate.setText(rideDateTxt);
//        Log.e(LOG, "rideDateTxt " + rideDateTxt);
        toCity.setText(destCityFind);
        fromCity.setText(startCityFind);

        call = new ShareACarApiService(getActivity()).getShareACarApi().findRide(userId + "", startCityFind, destCityFind, rideDateTxt1);
        call.enqueue(new Callback<List<UserRideInfoBean>>() {
            @Override
            public void onResponse(Call<List<UserRideInfoBean>> call, Response<List<UserRideInfoBean>> response) {
                    /*try {
                        Log.e("response", new ObjectMapper().writeValueAsString(response.body()));
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }*/
                connecting.setVisibility(View.GONE);

                if (response.code() == 200) {

                    if (response.body().size() == 0) {

                        connecting.setVisibility(View.VISIBLE);
                        textviewM1.setText("No Rides Found");
                        textviewM1.setTextSize(25.0f);
                        textviewM2.setText("");
                        if (textviewWelcome.getVisibility() == View.VISIBLE)
                            textviewWelcome.setVisibility(View.GONE);

                        /*new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {

                                    Thread.sleep(2000);
                                    // Do some stuff
                                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                                    ft.replace(R.id.frame, new findRideFragment());
                                    ft.addToBackStack(null);
                                    ft.commit();


                                } catch (Exception e) {
                                    e.getLocalizedMessage();
                                }
                            }
                        }).start();*/

                    } else {
                        rideInfoBeanArrayList.clear();
                        rideInfoBeanArrayList = response.body();
                    }
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            final RecyclerView recList = (RecyclerView) view.findViewById(R.id.cardList);
                            recList.removeAllViews();
                            recList.setHasFixedSize(true);
                            LinearLayoutManager llm = new LinearLayoutManager(getActivity());
                            llm.setOrientation(LinearLayoutManager.VERTICAL);
                            recList.setLayoutManager(llm);
                            rideAdapter ca = new rideAdapter(rideInfoBeanArrayList, true, getActivity());
//                            loadFlag = false;
                            recList.setAdapter(ca);

                        }
                    });
                } else {
                    // Handle other response codes
                    connecting.setVisibility(View.VISIBLE);
                    textviewM1.setText("There may have been a connection");
                    textviewM2.setText("error with one of our servers.");

                    if (textviewWelcome.getVisibility() == View.VISIBLE)
                        textviewWelcome.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFailure(Call<List<UserRideInfoBean>> call, Throwable t) {
                connecting.setVisibility(View.VISIBLE);
                textviewM1.setText("There may have been a connection");
                textviewM2.setText("error with one of our servers.");
                textviewM1.setTypeface(null, Typeface.BOLD);
                textviewM2.setTypeface(null, Typeface.BOLD);

                if (textviewWelcome.getVisibility() == View.VISIBLE)
                    textviewWelcome.setVisibility(View.GONE);
            }
        });
        return view;
    }

    @Override
    public void onResume() {
        textviewTitle = (TextView) getActivity().findViewById(R.id.textviewTitle);
        if (textviewTitle.getVisibility() == View.GONE)
            textviewTitle.setVisibility(View.VISIBLE);
        textviewTitle.setText("Ride List");

        header = (ImageView) getActivity().findViewById(R.id.tv_header_title);
        if (header.getVisibility() == View.VISIBLE)
            header.setVisibility(View.GONE);

        super.onResume();
    }

}
