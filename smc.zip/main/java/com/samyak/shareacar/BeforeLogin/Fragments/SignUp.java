package com.samyak.shareacar.BeforeLogin.Fragments;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.androidadvance.topsnackbar.TSnackbar;
import com.samyak.shareacar.R;
import com.samyak.shareacar.RetrofitApi.ShareACarApiService;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignUp extends Fragment {

    private static final String TAG = "SignupActivity";
    public Button _signupButton;
    public TextView _loginLink;

    //    private static final int REQUEST_SIGNUP = 0;
    public EditText _passwordText;
    public EditText _confirmPasswordText;
    public EditText _emailText;
    public EditText _userNameText;
    public EditText _FirstNameText;
    public EditText _lastNameText;
    public EditText _mobileNoText;
    public String output[];
    TextView textviewTitle;
    ImageView header;
    Call<ResponseBody> call;
    String result;
    ScrollView scrollViewSignUp;
    private ProgressDialog progress;

    public SignUp() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_sign_up, container, false);
        _signupButton = (Button) view.findViewById(R.id.btn_signup);
        _loginLink = (TextView) view.findViewById(R.id.link_login);
        _passwordText = (EditText) view.findViewById(R.id.input_password);
        _confirmPasswordText = (EditText) view.findViewById(R.id.input_password_confirm);
        _emailText = (EditText) view.findViewById(R.id.input_email);
//        _userNameText = (EditText) findViewById(R.id.input_user_name);
        _FirstNameText = (EditText) view.findViewById(R.id.input_first_name);
        _lastNameText = (EditText) view.findViewById(R.id.input_last_name);
        _mobileNoText = (EditText) view.findViewById(R.id.input_mobile_no);
        scrollViewSignUp = (ScrollView) view.findViewById(R.id.scrollViewSignUp);

        _signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //close keyboard
                hideKeyBoard(v);
                try {
                    signup(v);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        _loginLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Finish the registration screen and return to the Login activity
               /* Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                finish();
                startActivityForResult(intent, REQUEST_SIGNUP);
                overridePendingTransition(R.anim.slide_in, R.anim.slide_out);*/
                Fragment fragment = getFragmentManager().findFragmentById(R.id.frame);

                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
                ft.hide(fragment);
                ft.add(R.id.frame, new Login());
//                ft.addToBackStack(null);
                ft.commit();
            }
        });

        _mobileNoText.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_UP) {

                    hideKeyBoard(v);
                    try {
                        signup(v);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                return false;
            }
        });

        return view;
    }

    public void signup(final View view) throws ExecutionException, InterruptedException {

        if (!validate(view)) {
            onSignupFailed();
            return;
        }
        _signupButton.setEnabled(false);

        progress = new ProgressDialog(getActivity(), R.style.appThemeDialogue);

        progress.setIndeterminate(true);
        progress.setMessage("Creating Account...");
        progress.show();

        //String userName = _userNameText.getText().toString();
        String firstName = _FirstNameText.getText().toString();
        String lastname = _lastNameText.getText().toString();
        String mobileNo = _mobileNoText.getText().toString();

        String email = _emailText.getText().toString();
        String password = Base64.encodeToString(_passwordText.getText().toString().getBytes(), Base64.DEFAULT).trim();

        call = new ShareACarApiService(getActivity()).getShareACarApi().sendRegisterInfo(password, firstName, lastname, email, mobileNo, "user");
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        result = response.body().string();
                        progress.dismiss();
                        checkRegisterInfo(view);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    TSnackbar snackbar = TSnackbar
                            .make(view, "Can't connect to server", TSnackbar.LENGTH_LONG);
                    snackbar.setActionTextColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                    textView.setTextColor(Color.WHITE);
                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                    snackbar.show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                progress.dismiss();
                TSnackbar snackbar = TSnackbar
                        .make(view, "Please check your connection", TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.WHITE);
                textView.setTypeface(Typeface.DEFAULT_BOLD);
                snackbar.show();
            }
        });
    }

    private void checkRegisterInfo(View view) {
        output = result.split("::");

        if (output[0].equalsIgnoreCase("Success")) {

            LayoutInflater factory = LayoutInflater.from(getActivity());
            final View confirmDialogView = factory.inflate(R.layout.alertbox, null);
            final Dialog confirmDialog = new Dialog(getActivity());
            confirmDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            confirmDialog.setContentView(confirmDialogView);
            TextView message = (TextView) confirmDialogView.findViewById(R.id.message);
            message.setText(output[1]);
            ((TextView) confirmDialogView.findViewById(R.id.confirm)).setText("Success!");
            ((TextView) confirmDialogView.findViewById(R.id.getPro)).setText("Ok");
            ((Button) confirmDialogView.findViewById(R.id.cancel)).setVisibility(View.GONE);
            ((Button) confirmDialogView.findViewById(R.id.ok)).setVisibility(View.GONE);
            confirmDialogView.findViewById(R.id.getPro).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //your business logic
                    confirmDialog.dismiss();

                    _emailText.setText("");
                    _passwordText.setText("");
                    _confirmPasswordText.setText("");
                    _FirstNameText.setText("");
                    _lastNameText.setText("");
                    _mobileNoText.setText("");

                    onSignupSuccess();

                }
            });

            confirmDialog.show();

            /*Snackbar snackbar = Snackbar.make(view, output[1], 2000);
            Snackbar.SnackbarLayout layout = (Snackbar.SnackbarLayout) snackbar.getView();
            //layout.setBackgroundDrawable(getResources().getDrawable(R.drawable.style_toast));
            layout.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) layout.findViewById(android.support.design.R.id.snackbar_text);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {

                            Thread.sleep(2000);
                            // Do some stuff
                            onSignupSuccess();

                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    }
                }).start();*/

        } else if (output[0].equalsIgnoreCase("Failed")) {

            TSnackbar snackbar = TSnackbar
                    .make(view, output[1], TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            onSignupFailed();

        } else {
            TSnackbar snackbar = TSnackbar
                    .make(view, "Please check your connection", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();
        }
    }

    public void onSignupSuccess() {
        _signupButton.setEnabled(true);

        Intent iData = new Intent();
        iData.putExtra("result", output);

        getActivity().setResult(android.app.Activity.RESULT_OK, iData);

        Fragment fragment = getFragmentManager().findFragmentById(R.id.frame);

        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
        ft.hide(fragment);
        ft.add(R.id.frame, new Login());
//                ft.addToBackStack(null);
        ft.commit();

        //..returns us to the parent "MyMainActivity"..
//        finish();

        //  finish();
    }

    public void onSignupFailed() {
        // Toast.makeText(getBaseContext(), "Signup failed", Toast.LENGTH_LONG).show();

        _signupButton.setEnabled(true);
        //setResult(RESULT_CANCELED, null);
    }

    public void hideKeyBoard(View v) {
        InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        }
    }

    public boolean validate(View view) {
        boolean valid = true;

        String firstName = _FirstNameText.getText().toString();
        String lastName = _lastNameText.getText().toString();
        String mobileNo = _mobileNoText.getText().toString();
        String confirmPassword = _confirmPasswordText.getText().toString();
        String email = _emailText.getText().toString();
        String password = _passwordText.getText().toString();


        if (firstName.trim().isEmpty() || firstName.length() < 1) {

            TSnackbar snackbar = TSnackbar
                    .make(view, "Please enter first name", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;

        } else if (lastName.trim().isEmpty() || lastName.length() < 1) {

            TSnackbar snackbar = TSnackbar
                    .make(view, "Please enter last name", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
        } else if (password.isEmpty() || password.length() < 4) {

            TSnackbar snackbar = null;

            if (password.isEmpty()) {
                snackbar = TSnackbar
                        .make(view, "Please enter password", TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);

            } else if (password.length() < 4) {
                snackbar = TSnackbar
                        .make(view, "Password must be atleast 4 characters long", TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
            }

            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
        } else if (confirmPassword.isEmpty() || !confirmPassword.equals(password)) {

            TSnackbar snackbar;

            if (confirmPassword.isEmpty()) {
                snackbar = TSnackbar
                        .make(view, "Please enter confirm password", TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
            } else {
                snackbar = TSnackbar
                        .make(view, "Password and confirm password don't match", TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
            }

            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
        } else if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {

            TSnackbar snackbar;

            if (email.isEmpty()) {
                snackbar = TSnackbar
                        .make(view, "Please enter email", TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
            } else {
                snackbar = TSnackbar
                        .make(view, "Please enter valid email", TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
            }

            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
        } else if (mobileNo.isEmpty()) {

            if (mobileNo.isEmpty()) {
                TSnackbar snackbar = TSnackbar
                        .make(view, "Please enter mobile number", TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.WHITE);
                textView.setTypeface(Typeface.DEFAULT_BOLD);
                snackbar.show();
            }
            valid = false;
        }

        return valid;
    }

    @Override
    public void onResume() {

        textviewTitle = (TextView) getActivity().findViewById(R.id.textviewTitle);
        if (textviewTitle.getVisibility() == View.GONE)
            textviewTitle.setVisibility(View.VISIBLE);
        textviewTitle.setText("Signup");

        header = (ImageView) getActivity().findViewById(R.id.tv_header_title);
        if (header.getVisibility() == View.VISIBLE)
            header.setVisibility(View.GONE);

        super.onResume();
    }

}
