package com.samyak.shareacar.BeforeLogin.Fragments;

import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.samyak.shareacar.R;

public class HomeOut extends Fragment {

    TextView textviewTitle = null;
    ImageView header;

    ImageView imageviewHome, imageviewFindRide, imageviewOfferRide, imageviewLogin;
    LinearLayout linearLayoutHome, linearLayoutLogin, linearLayoutFindRide, linearOfferRide;
    TextView textViewHome, textViewLogin, textViewFindRide, textViewOfferRide;

    public HomeOut() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_home, container, false);
        Button offerRide = (Button) v.findViewById(R.id.btn_offer_a_ride);
        Button findRide = (Button) v.findViewById(R.id.btn_find_a_ride);

        findNavLayouts();

        offerRide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                LayoutInflater factory = LayoutInflater.from(getActivity());
                final View confirmDialogView = factory.inflate(R.layout.alertbox, null);
                final Dialog confirmDialog = new Dialog(getActivity());
                confirmDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                confirmDialog.setContentView(confirmDialogView);
                TextView message = (TextView) confirmDialogView.findViewById(R.id.message);
                message.setText("You need to be authenticated to publish a ride");
                ((TextView) confirmDialogView.findViewById(R.id.confirm)).setText("Almost There!");
                ((TextView) confirmDialogView.findViewById(R.id.getPro)).setText("Log in");
                ((Button) confirmDialogView.findViewById(R.id.cancel)).setVisibility(View.GONE);
                ((Button) confirmDialogView.findViewById(R.id.ok)).setVisibility(View.GONE);
                confirmDialogView.findViewById(R.id.getPro).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //your business logic
                        confirmDialog.dismiss();

                        setOfferRideSelected();

                        Login login = new Login();

                        Bundle args = new Bundle();
                        args.putBoolean("callOfferRide", true);
                        login.setArguments(args);

                        FragmentTransaction ft = getFragmentManager().beginTransaction();
                        ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
                        ft.replace(R.id.frame, login);
                        ft.addToBackStack(null);
                        ft.commit();

                    }
                });

                confirmDialog.show();
                /*autenticateDialogView.findViewById(R.id.signup).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        authenticateDialog.dismiss();
                    }
                });*/

            }
        });

        findRide.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                setFindRideSelected();

                FindRideOut fro = new FindRideOut();

                Bundle args = new Bundle();
                args.putBoolean("callFindRide", true);
                fro.setArguments(args);

                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
                ft.replace(R.id.frame, fro);
                ft.addToBackStack(null);
                ft.commit();

            }
        });

        return v;
    }

    @Override
    public void onResume() {
        textviewTitle = (TextView) getActivity().findViewById(R.id.textviewTitle);
        header = (ImageView) getActivity().findViewById(R.id.tv_header_title);
        if (textviewTitle.getVisibility() == View.VISIBLE)
            textviewTitle.setVisibility(View.GONE);
        if (header.getVisibility() == View.GONE)
            header.setVisibility(View.VISIBLE);
        super.onResume();
    }

    private void findNavLayouts() {
        linearLayoutHome = (LinearLayout) getActivity().findViewById(R.id.linearLayoutHome);
        linearLayoutFindRide = (LinearLayout) getActivity().findViewById(R.id.linearLayoutFindRide);
        linearOfferRide = (LinearLayout) getActivity().findViewById(R.id.linearOfferRide);
        linearLayoutLogin = (LinearLayout) getActivity().findViewById(R.id.linearLayoutLogin);

        imageviewHome = (ImageView) getActivity().findViewById(R.id.imageviewHome);
        imageviewFindRide = (ImageView) getActivity().findViewById(R.id.imageviewFindRide);
        imageviewOfferRide = (ImageView) getActivity().findViewById(R.id.imageviewOfferRide);
        imageviewLogin = (ImageView) getActivity().findViewById(R.id.imageviewLogin);

        textViewHome = (TextView) getActivity().findViewById(R.id.textViewHome);
        textViewFindRide = (TextView) getActivity().findViewById(R.id.textViewFindRide);
        textViewOfferRide = (TextView) getActivity().findViewById(R.id.textViewOfferRide);
        textViewLogin = (TextView) getActivity().findViewById(R.id.textViewLogin);
    }

    private void setFindRideSelected() {
        linearLayoutHome.setBackgroundColor(ContextCompat.getColor(getActivity(), android.R.color.transparent));
        textViewHome.setTextColor(ContextCompat.getColor(getActivity(), android.R.color.black));
        imageviewHome.setImageResource(R.drawable.ic_nav_home_black);

        linearLayoutFindRide.setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.primary));
        textViewFindRide.setTextColor(ContextCompat.getColor(getActivity(), android.R.color.white));
        imageviewFindRide.setImageResource(R.drawable.ic_nav_find_white);

        linearOfferRide.setBackgroundColor(ContextCompat.getColor(getActivity(), android.R.color.transparent));
        textViewOfferRide.setTextColor(ContextCompat.getColor(getActivity(), android.R.color.black));
        imageviewOfferRide.setImageResource(R.drawable.ic_nav_offer_black);

        linearLayoutLogin.setBackgroundColor(ContextCompat.getColor(getActivity(), android.R.color.transparent));
        textViewLogin.setTextColor(ContextCompat.getColor(getActivity(), android.R.color.black));
        imageviewLogin.setImageResource(R.drawable.ic_action_login_black);
    }

    private void setOfferRideSelected() {
        linearLayoutHome.setBackgroundColor(ContextCompat.getColor(getActivity(), android.R.color.transparent));
        textViewHome.setTextColor(ContextCompat.getColor(getActivity(), android.R.color.black));
        imageviewHome.setImageResource(R.drawable.ic_nav_home_black);

        linearLayoutFindRide.setBackgroundColor(ContextCompat.getColor(getActivity(), android.R.color.transparent));
        textViewFindRide.setTextColor(ContextCompat.getColor(getActivity(), android.R.color.black));
        imageviewFindRide.setImageResource(R.drawable.ic_nav_find_black);

        linearOfferRide.setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.primary));
        textViewOfferRide.setTextColor(ContextCompat.getColor(getActivity(), android.R.color.white));
        imageviewOfferRide.setImageResource(R.drawable.ic_nav_offer_white);

        linearLayoutLogin.setBackgroundColor(ContextCompat.getColor(getActivity(), android.R.color.transparent));
        textViewLogin.setTextColor(ContextCompat.getColor(getActivity(), android.R.color.black));
        imageviewLogin.setImageResource(R.drawable.ic_action_login_black);
    }


}
