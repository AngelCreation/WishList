package com.samyak.shareacar.BeforeLogin.Fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.androidadvance.topsnackbar.TSnackbar;
import com.samyak.shareacar.HomePage;
import com.samyak.shareacar.R;
import com.samyak.shareacar.RetrofitApi.ShareACarApiService;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.Context.MODE_PRIVATE;

public class Login extends Fragment {

    private static final int REQUEST_SIGNUP = 0;
    public static boolean goTOFindRideOut = false;
    TextView textviewTitle;
    ImageView header;
    String userName;
    String email, password;
    String result = "";
    Call<ResponseBody> call;
    EditText _emailText, _passwordText;
    Button _loginButton;
    TextView _signupLink, _forgotPasswordLink;
    private String LOG = "LoginActivity";
    private ProgressDialog progress;

    public Login() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_login, container, false);

//        ButterKnife.inject(getActivity());
        _emailText = (EditText) view.findViewById(R.id.input_email);
        _passwordText = (EditText) view.findViewById(R.id.input_password);
        _loginButton = (Button) view.findViewById(R.id.btn_login);
        _signupLink = (TextView) view.findViewById(R.id.link_signup);
        _forgotPasswordLink = (TextView) view.findViewById(R.id.link_forgotPassword);

        _emailText.setText("");
        _passwordText.setText("");

        Bundle bundle = this.getArguments();

        if (bundle != null) {
            if (bundle.containsKey("callFindRide")) {
                goTOFindRideOut = true;
            }
        }

        _loginButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
//                new Crashlytics().crash();
                try {
                    //close keyboard
                    hideKeyBoard(v);
                    login(v);


                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        _signupLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                _emailText.setText("");
                _passwordText.setText("");
                // Start the Signup activity
                /*Intent intent = new Intent(getActivity().getApplicationContext(), SignupActivity.class);
                startActivityForResult(intent, REQUEST_SIGNUP);
                getActivity().overridePendingTransition(R.anim.slide_in, R.anim.slide_out);*/
                Fragment fragment = getFragmentManager().findFragmentById(R.id.frame);
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
                ft.hide(fragment);
                ft.add(R.id.frame, new SignUp());
                ft.addToBackStack(null);
                ft.commit();
            }
        });
        _forgotPasswordLink.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                _emailText.setText("");
                _passwordText.setText("");
                // Start the Signup activity
                /*Intent intent = new Intent(getActivity().getApplicationContext(), ForgotPassword.class);
                startActivity(intent);
                getActivity().overridePendingTransition(R.anim.slide_in, R.anim.slide_out);*/
                Fragment fragment = getFragmentManager().findFragmentById(R.id.frame);
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
                ft.hide(fragment);
                ft.add(R.id.frame, new com.samyak.shareacar.BeforeLogin.Fragments.ForgotPassword());
                ft.addToBackStack(null);
                ft.commit();
            }
        });

        _passwordText.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_UP) {
                    hideKeyBoard(v);
                    try {
                        login(v);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                return false;
            }
        });
        return view;
    }

    public void hideKeyBoard(View v) {
        InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        }
    }

    public void login(final View view) throws ExecutionException, InterruptedException {
        if (!validate(view)) {
            return;
        }

        progress = new ProgressDialog(getActivity(), R.style.appThemeDialogue);
        progress.setMessage("Loading...");
//        progress.setMessage("Authenticating...");
        progress.show();

        email = _emailText.getText().toString();
        password = Base64.encodeToString(_passwordText.getText().toString().getBytes(), Base64.DEFAULT).trim();

        call = new ShareACarApiService(getActivity()).getShareACarApi().sendLoginInfo(email, password, "user");
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if ((progress != null) && progress.isShowing()) {
                    progress.dismiss();
                }
                if (response.code() == 200) {
                    try {
//                    Log.e(LOG, "result" + result);
                        result = response.body().string();
                        checkLoginInfo(view);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    TSnackbar snackbar = TSnackbar
                            .make(view, "Can't connect to server", TSnackbar.LENGTH_LONG);
                    snackbar.setActionTextColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                    textView.setTextColor(Color.WHITE);
                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                    snackbar.show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                if ((progress != null) && progress.isShowing()) {
                    progress.dismiss();
                }
                TSnackbar snackbar = TSnackbar
                        .make(view, "Please check your connection", TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.WHITE);
                textView.setTypeface(Typeface.DEFAULT_BOLD);
                snackbar.show();
            }
        });
    }

    private void checkLoginInfo(View view) {
        String output[] = result.split("::");
        String userId;
        String carId;
        String contactNo;
        String emailId;

        if (output[0].equalsIgnoreCase("Success")) {
            userId = output[1];
            Log.e("insert user id", "" + userId);

            if (userId.equalsIgnoreCase("NotActivated")) {
                TSnackbar snackbar = TSnackbar
                        .make(view, "Account is not activated", TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.WHITE);
                textView.setTypeface(Typeface.DEFAULT_BOLD);
                snackbar.show();

                _loginButton.setEnabled(true);

            } else {
                carId = output[2];
                contactNo = output[3];
                emailId = output[4];
                userName = output[5];

                SQLiteDatabase mydatabase = getActivity().openOrCreateDatabase("shareACar", MODE_PRIVATE, null);
                mydatabase.execSQL("CREATE TABLE IF NOT EXISTS loginInfo(userId INTEGER ,carId INTEGER , contactNo TEXT , emailId TEXT, userName TEXT);");
                mydatabase.execSQL("INSERT INTO loginInfo VALUES(" + userId + "," + carId + ",'" + contactNo + "','" + emailId + "','" + userName + "');");
                onLoginSuccess();
            }

        } else if (output[0].equalsIgnoreCase("Failed")) {
            TSnackbar snackbar = TSnackbar.make(view, output[1], TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            onLoginFailed();

        } else {
            TSnackbar snackbar = TSnackbar
                    .make(view, "Please check your connection", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            onLoginFailed();
        }
    }

    public void onLoginSuccess() {

        _loginButton.setEnabled(true);
        email = "";
        password = "";

        Intent intent = new Intent(getActivity(), HomePage.class);

        Bundle bundle = this.getArguments();
//        UserRideInfoBean ridebean = bundle.getParcelable("rideBean");
//        Log.e("bean","" + ridebean.toString());

        if (bundle != null) {
            /*if(bundle.containsKey("callOfferRide")) {
                intent.putExtra("callOfferRide", true);
            } else if(bundle.containsKey("callFindRide")) {
                intent.putExtra("callFindRide", true);
                intent.putExtra("rideBean",bundle.getParcelable("rideBean"));
            }*/
            intent.putExtras(bundle);
        }
        startActivity(intent);
        getActivity().finish();
    }

    public void onLoginFailed() {
        _loginButton.setEnabled(true);
    }

    public boolean validate(View view) {
        boolean valid = true;

        String email = _emailText.getText().toString();
        String password = _passwordText.getText().toString();

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {

            TSnackbar snackbar;

            if (email.isEmpty()) {
                snackbar = TSnackbar
                        .make(view, "Please enter email", TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);

            } else {
                snackbar = TSnackbar
                        .make(view, "Please enter valid email", TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
            }

            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
        } else if (password.isEmpty()) {

            TSnackbar snackbar = TSnackbar
                    .make(view, "Please enter password", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
        }
        return valid;
    }

    @Override
    public void onResume() {
        textviewTitle = (TextView) getActivity().findViewById(R.id.textviewTitle);
        if (textviewTitle.getVisibility() == View.GONE)
            textviewTitle.setVisibility(View.VISIBLE);
        textviewTitle.setText("Login");

        header = (ImageView) getActivity().findViewById(R.id.tv_header_title);
        if (header.getVisibility() == View.VISIBLE)
            header.setVisibility(View.GONE);

        super.onResume();
    }
}
