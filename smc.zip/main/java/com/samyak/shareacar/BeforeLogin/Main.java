package com.samyak.shareacar.BeforeLogin;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.samyak.shareacar.BeforeLogin.Fragments.FindRideOut;
import com.samyak.shareacar.BeforeLogin.Fragments.ForgotPassword;
import com.samyak.shareacar.BeforeLogin.Fragments.HomeOut;
import com.samyak.shareacar.BeforeLogin.Fragments.Login;
import com.samyak.shareacar.BeforeLogin.Fragments.RideListOut;
import com.samyak.shareacar.BeforeLogin.Fragments.SignUp;
import com.samyak.shareacar.HomePage;
import com.samyak.shareacar.Models.UserRideInfoBean;
import com.samyak.shareacar.R;

import java.util.List;

public class Main extends AppCompatActivity {

    DrawerLayout drawerLayout;
    ImageView imageViewLogo, imageviewHome, imageviewFindRide, imageviewOfferRide, imageviewLogin;
    LinearLayout linearLayoutHome, linearLayoutLogin, linearLayoutFindRide, linearOfferRide, linearLayoutRefer;
    TextView textViewHome, textViewLogin, textViewFindRide, textViewOfferRide;
    TextView textviewTitle;
    ImageView header;
//    String filePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        AdView mAdView = (AdView) findViewById(R.id.adView);
        // AdRequest adRequest = new AdRequest.Builder().build();
        AdRequest adRequest = new AdRequest.Builder()
//                .addTestDevice("E675ADF3D213DB10C8CA35617B0D0014")  //asus
//                .addTestDevice("D9F9B07C3F3A43A479C2F2DA15A68146")  //micromax
//               .addTestDevice("C790F88E883449C92A6735BD1F6B610C") //samsung
                .build();
        mAdView.loadAd(adRequest);

        linearLayoutHome = (LinearLayout) findViewById(R.id.linearLayoutHome);
        linearLayoutFindRide = (LinearLayout) findViewById(R.id.linearLayoutFindRide);
        linearOfferRide = (LinearLayout) findViewById(R.id.linearOfferRide);
        linearLayoutLogin = (LinearLayout) findViewById(R.id.linearLayoutLogin);
        linearLayoutRefer = (LinearLayout) findViewById(R.id.linearLayoutRefer);

        imageviewHome = (ImageView) findViewById(R.id.imageviewHome);
        imageviewFindRide = (ImageView) findViewById(R.id.imageviewFindRide);
        imageviewOfferRide = (ImageView) findViewById(R.id.imageviewOfferRide);
        imageviewLogin = (ImageView) findViewById(R.id.imageviewLogin);

        textViewHome = (TextView) findViewById(R.id.textViewHome);
        textViewFindRide = (TextView) findViewById(R.id.textViewFindRide);
        textViewOfferRide = (TextView) findViewById(R.id.textViewOfferRide);
        textViewLogin = (TextView) findViewById(R.id.textViewLogin);

        setNavigationDrawer();

//        makeFileToShare();

        setHomeSelected();

        if (getIntent().getExtras() != null) {
            if (getIntent().getExtras().containsKey("Logout")) {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame, new Login());
                transaction.addToBackStack(null);
                transaction.commit();
            }
        } else {
            imageviewHome.setImageResource(R.drawable.ic_nav_home_white);
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.frame, new HomeOut());
            transaction.addToBackStack(null);
            transaction.commit();
        }
    }

    private void setNavigationDrawer() {

        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout1);

        drawerLayout.setDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                hideKeyBoard(drawerView);
            }

            @Override
            public void onDrawerOpened(View drawerView) {
            }

            @Override
            public void onDrawerClosed(View drawerView) {
            }

            @Override
            public void onDrawerStateChanged(int newState) {
            }
        });

        imageViewLogo = (ImageView) findViewById(R.id.drawer_logo);

        imageViewLogo.requestFocus();

        imageViewLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(Gravity.LEFT);
                hideKeyBoard(view);
            }
        });

        linearLayoutHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                setHomeSelected();

                drawerLayout.closeDrawers();

                Intent it = new Intent(getApplicationContext(), HomePage.class);
                finish();
                startActivity(it);

                overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
            }
        });

        linearLayoutFindRide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                setFindRideSelected();

                drawerLayout.closeDrawers();

                FindRideOut fro = new FindRideOut();
                Bundle args = new Bundle();
                args.putBoolean("callFindRide", true);
                fro.setArguments(args);

                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
                ft.replace(R.id.frame, fro);
//                ft.addToBackStack(null);
                ft.commit();
            }
        });

        linearOfferRide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                LayoutInflater factory = LayoutInflater.from(Main.this);
                final View confirmDialogView = factory.inflate(R.layout.alertbox, null);
                final Dialog confirmDialog = new Dialog(Main.this);
                confirmDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                confirmDialog.setContentView(confirmDialogView);
                TextView message = (TextView) confirmDialogView.findViewById(R.id.message);
                message.setText("You need to be authenticated to publish a ride");
                ((TextView) confirmDialogView.findViewById(R.id.confirm)).setText("Almost There!");
                ((TextView) confirmDialogView.findViewById(R.id.getPro)).setText("Log in");
                ((Button) confirmDialogView.findViewById(R.id.cancel)).setVisibility(View.GONE);
                ((Button) confirmDialogView.findViewById(R.id.ok)).setVisibility(View.GONE);
                confirmDialogView.findViewById(R.id.getPro).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //your business logic
                        confirmDialog.dismiss();

                        setOfferRideSelected();

                        drawerLayout.closeDrawers();

                        Login login = new Login();

                        Bundle args = new Bundle();
                        args.putBoolean("callOfferRide", true);
                        login.setArguments(args);

                        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                        ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
                        ft.replace(R.id.frame, login);
                        ft.addToBackStack(null);
                        ft.commit();
                    }
                });
                confirmDialog.show();
            }
        });

        linearLayoutLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                setLogInSelected();

                drawerLayout.closeDrawers();

                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
                ft.replace(R.id.frame, new Login());
                ft.addToBackStack(null);
                ft.commit();
            }
        });

        linearLayoutRefer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                drawerLayout.closeDrawers();
//                setReferSelected();

//                ApplicationInfo app = getApplicationContext().getApplicationInfo();
//                filePath = getExternalFilesDir(null).getPath() + File.separator + "shareurcar.txt";

//                onShareClick(view);

                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                try {
                    sendIntent.putExtra(Intent.EXTRA_TEXT,
                            "Hey I came across this awsome App! Download Now. https://play.google.com/store/apps/details?id=com.samyak.shareurcar&hl=en");
                } catch (Exception e) {
                    e.printStackTrace();
                }
//                sendIntent.setType("*/*");
                sendIntent.setType("text/plain");

                PackageManager pm = getPackageManager();
                List<ResolveInfo> resInfo = pm.queryIntentActivities(sendIntent, 0);

                for (int i = 0; i < resInfo.size(); i++) {
                    ResolveInfo ri = resInfo.get(i);
                    String packageName = ri.activityInfo.packageName;

                    if (packageName.contains("android.email") || packageName.contains("android.gm")) {
                        sendIntent.putExtra(Intent.EXTRA_SUBJECT, "ShareUrCar Application");
                    } else if (packageName.contains("xender")) {
//                        sendIntent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new File(filePath)));
                    }
                }
                startActivity(sendIntent);
            }
        });
    }

    private void setHomeSelected() {

        linearLayoutHome.setBackgroundColor(ContextCompat.getColor(Main.this, R.color.primary));
        textViewHome.setTextColor(ContextCompat.getColor(Main.this, android.R.color.white));
        imageviewHome.setImageResource(R.drawable.ic_nav_home_white);

        linearLayoutFindRide.setBackgroundColor(ContextCompat.getColor(Main.this, android.R.color.transparent));
        textViewFindRide.setTextColor(ContextCompat.getColor(Main.this, android.R.color.black));
        imageviewFindRide.setImageResource(R.drawable.ic_nav_find_black);

        linearOfferRide.setBackgroundColor(ContextCompat.getColor(Main.this, android.R.color.transparent));
        textViewOfferRide.setTextColor(ContextCompat.getColor(Main.this, android.R.color.black));
        imageviewOfferRide.setImageResource(R.drawable.ic_nav_offer_black);

        linearLayoutLogin.setBackgroundColor(ContextCompat.getColor(Main.this, android.R.color.transparent));
        textViewLogin.setTextColor(ContextCompat.getColor(Main.this, android.R.color.black));
        imageviewLogin.setImageResource(R.drawable.ic_action_login_black);

    }

    private void setFindRideSelected() {

        linearLayoutHome.setBackgroundColor(ContextCompat.getColor(Main.this, android.R.color.transparent));
        textViewHome.setTextColor(ContextCompat.getColor(Main.this, android.R.color.black));
        imageviewHome.setImageResource(R.drawable.ic_nav_home_black);

        linearLayoutFindRide.setBackgroundColor(ContextCompat.getColor(Main.this, R.color.primary));
        textViewFindRide.setTextColor(ContextCompat.getColor(Main.this, android.R.color.white));
        imageviewFindRide.setImageResource(R.drawable.ic_nav_find_white);

        linearOfferRide.setBackgroundColor(ContextCompat.getColor(Main.this, android.R.color.transparent));
        textViewOfferRide.setTextColor(ContextCompat.getColor(Main.this, android.R.color.black));
        imageviewOfferRide.setImageResource(R.drawable.ic_nav_offer_black);

        linearLayoutLogin.setBackgroundColor(ContextCompat.getColor(Main.this, android.R.color.transparent));
        textViewLogin.setTextColor(ContextCompat.getColor(Main.this, android.R.color.black));
        imageviewLogin.setImageResource(R.drawable.ic_action_login_black);
    }

    private void setOfferRideSelected() {

        linearLayoutHome.setBackgroundColor(ContextCompat.getColor(Main.this, android.R.color.transparent));
        textViewHome.setTextColor(ContextCompat.getColor(Main.this, android.R.color.black));
        imageviewHome.setImageResource(R.drawable.ic_nav_home_black);

        linearLayoutFindRide.setBackgroundColor(ContextCompat.getColor(Main.this, android.R.color.transparent));
        textViewFindRide.setTextColor(ContextCompat.getColor(Main.this, android.R.color.black));
        imageviewFindRide.setImageResource(R.drawable.ic_nav_find_black);

        linearOfferRide.setBackgroundColor(ContextCompat.getColor(Main.this, R.color.primary));
        textViewOfferRide.setTextColor(ContextCompat.getColor(Main.this, android.R.color.white));
        imageviewOfferRide.setImageResource(R.drawable.ic_nav_offer_white);

        linearLayoutLogin.setBackgroundColor(ContextCompat.getColor(Main.this, android.R.color.transparent));
        textViewLogin.setTextColor(ContextCompat.getColor(Main.this, android.R.color.black));
        imageviewLogin.setImageResource(R.drawable.ic_action_login_black);
    }

    private void setLogInSelected() {

        linearLayoutHome.setBackgroundColor(ContextCompat.getColor(Main.this, android.R.color.transparent));
        textViewHome.setTextColor(ContextCompat.getColor(Main.this, android.R.color.black));
        imageviewHome.setImageResource(R.drawable.ic_nav_home_black);

        linearLayoutFindRide.setBackgroundColor(ContextCompat.getColor(Main.this, android.R.color.transparent));
        textViewFindRide.setTextColor(ContextCompat.getColor(Main.this, android.R.color.black));
        imageviewFindRide.setImageResource(R.drawable.ic_nav_find_black);

        linearOfferRide.setBackgroundColor(ContextCompat.getColor(Main.this, android.R.color.transparent));
        textViewOfferRide.setTextColor(ContextCompat.getColor(Main.this, android.R.color.black));
        imageviewOfferRide.setImageResource(R.drawable.ic_nav_offer_black);

        linearLayoutLogin.setBackgroundColor(ContextCompat.getColor(Main.this, R.color.primary));
        textViewLogin.setTextColor(ContextCompat.getColor(Main.this, android.R.color.white));
        imageviewLogin.setImageResource(R.drawable.ic_action_login_white);
    }

    public void moveToRideInfo(UserRideInfoBean rideBean) {

        Login login = new Login();

        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.frame);

        Bundle args = new Bundle();
        args.putBoolean("callFindRide", true);
        args.putParcelable("rideBean", rideBean);
        login.setArguments(args);

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
        ft.hide(fragment);
        ft.add(R.id.frame, login);
        ft.addToBackStack(null);
        ft.commit();
    }

    private void hideKeyBoard(View view) {
        //close keyboard
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }


    @Override
    public void onBackPressed() {

        /*FragmentManager fragmentManager = this.getSupportFragmentManager();
        List<Fragment> fragments = fragmentManager.getFragments();
        if (fragments != null) {
            for (android.support.v4.app.Fragment fragment : fragments) {
                if (fragment != null && fragment.isVisible()) {

                    if (fragment.getClass().equals(FindRideOut.class)) {    //main
                            *//*setHomeSelected();
                            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                            ft.replace(R.id.frame, new HomeFragment());
                            ft.addToBackStack(null);
                            ft.commit();*//*

                        Intent it = new Intent(getApplicationContext(), Main.class);
                        finish();
                        startActivity(it);
                        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);

                    } else if (fragment.getClass().equals(RideListOut.class)) {
                        setTitle("Find Ride");
                        getSupportFragmentManager().popBackStackImmediate();

                    }  else if (fragment.getClass().equals(SignUp.class)) {
                        setTitle("Login");
                        getSupportFragmentManager().popBackStackImmediate();

                    } else if (fragment.getClass().equals(ForgotPassword.class)) {
                        setTitle("Login");
                        getSupportFragmentManager().popBackStackImmediate();

                    } else if (fragment.getClass().equals(Login.class)) {

                        if(Login.goTOFindRideOut) {
                            Login.goTOFindRideOut = false;
                            getSupportFragmentManager().popBackStackImmediate();
                        } else {
                            Intent it = new Intent(getApplicationContext(), Main.class);
                            finish();
                            startActivity(it);
                            overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                        }

                    }
                    else if (fragment.getClass().equals(HomeOut.class)) {

                        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(Main.this);
                        builder.setMessage(Html.fromHtml("Do you want to exit?"))
                                .setCancelable(false)
                                .setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();
                                        return;
                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                        android.app.AlertDialog alert = builder.create();
                        alert.show();
                    }
                    else {
                        super.onBackPressed();
                    }*/
//                }
//            }
//        }

        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.frame);

        if (drawerLayout.isDrawerOpen(Gravity.LEFT)) {
            drawerLayout.closeDrawers();
        } else if (fragment instanceof FindRideOut) {
            Intent it = new Intent(getApplicationContext(), Main.class);
            finish();
            startActivity(it);
            overridePendingTransition(R.anim.slide_in, R.anim.slide_out);

        } else if (fragment instanceof RideListOut) {
            setTitle("Find Ride");
            getSupportFragmentManager().popBackStackImmediate();

        } else if (fragment instanceof SignUp) {
            setTitle("Login");
            getSupportFragmentManager().popBackStackImmediate();

        } else if (fragment instanceof ForgotPassword) {
            setTitle("Login");
            getSupportFragmentManager().popBackStackImmediate();
        } else if (fragment instanceof Login) {
            if (Login.goTOFindRideOut) {
                Login.goTOFindRideOut = false;

                if (getIntent().getExtras() != null) {
                    if (getIntent().getExtras().containsKey("Logout")) {
                        Intent it = new Intent(getApplicationContext(), Main.class);
                        finish();
                        startActivity(it);
                        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                    }
                } else {
                    getSupportFragmentManager().popBackStackImmediate();
                }
            } else {
                Intent it = new Intent(getApplicationContext(), Main.class);
                finish();
                startActivity(it);
                overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
            }

        } else if (fragment instanceof HomeOut) {

            LayoutInflater factory = LayoutInflater.from(Main.this);
            final View confirmDialogView = factory.inflate(R.layout.alertbox, null);
            final Dialog confirmDialog = new Dialog(Main.this);
            confirmDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            confirmDialog.setContentView(confirmDialogView);
            TextView message = (TextView) confirmDialogView.findViewById(R.id.message);
            message.setText("Do You Want To Exit From Appplication ?");
            ((TextView) confirmDialogView.findViewById(R.id.confirm)).setText("Please Confirm!");
            ((TextView) confirmDialogView.findViewById(R.id.getPro)).setVisibility(View.GONE);
            ((Button) confirmDialogView.findViewById(R.id.cancel)).setText("Cancel");
            ((Button) confirmDialogView.findViewById(R.id.ok)).setText("Exit");

            confirmDialogView.findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    confirmDialog.dismiss();
                }
            });
            confirmDialogView.findViewById(R.id.ok).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    confirmDialog.dismiss();
                    finish();
                    return;
                }
            });
            confirmDialog.show();
        } else {
            super.onBackPressed();
        }

    }

    /*private void makeFileToShare() {

        try {
            //Whatever the file path is.
            File statText = new File(getExternalFilesDir(null).getPath() + File.separator + "shareurcar.txt");
            FileOutputStream is = new FileOutputStream(statText);
            OutputStreamWriter osw = new OutputStreamWriter(is);
            Writer w = new BufferedWriter(osw);
            w.write("Hey I came across this awsome App! Download Now. https://play.google.com/store/apps/details?id=com.samyak.shareurcar&hl=en");
            w.close();
        } catch (IOException e) {
            System.err.println("Problem writing to the file statsTest.txt");
        }

    }*/

    private void setTitle(String text) {
        textviewTitle = (TextView) findViewById(R.id.textviewTitle);
        if (textviewTitle.getVisibility() == View.GONE)
            textviewTitle.setVisibility(View.VISIBLE);
        textviewTitle.setText(text);

        header = (ImageView) findViewById(R.id.tv_header_title);
        if (header.getVisibility() == View.VISIBLE)
            header.setVisibility(View.GONE);
    }
}
