package com.samyak.shareacar.Adapters;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.samyak.shareacar.Helpers.ViewHolder.rideInfoHandler;
import com.samyak.shareacar.Models.UserRideInfoBean;
import com.samyak.shareacar.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class rideAdapter extends RecyclerView.Adapter<rideInfoHandler> {
    boolean callFInd;
    UserRideInfoBean ci;
    Context context;
    Date date1 = null, date2 = null, date3 = null;
    String time[] = null;
    String dateTime[] = null;
    SimpleDateFormat df1, df2;
    View itemView;
    private List<UserRideInfoBean> rideList;

    public rideAdapter(List<UserRideInfoBean> rideList, boolean b, Context context) {
        this.rideList = rideList;
        callFInd = b;
        this.context = context;
    }

    @Override
    public int getItemCount() {
        return rideList.size();
    }

    @Override
    public rideInfoHandler onCreateViewHolder(ViewGroup viewGroup, int i) {
        ci = rideList.get(i);
        //different call for different ride type
        if (ci.getRideViewType().equalsIgnoreCase("daily")) {
            itemView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.card_view_daily, viewGroup, false);
        } else {
            itemView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.card_view, viewGroup, false);
        }
        return new rideInfoHandler(itemView, context);
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public void onBindViewHolder(rideInfoHandler rideInfoHandler, int i) {
//        String months[] = {"Jan", "Feb", "Mar", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        ci = rideList.get(i);

        if (ci.getRideViewType().equalsIgnoreCase("daily")) {

            rideInfoHandler.rideBean = ci;

            df1 = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

            try {
                date1 = df1.parse(ci.getDatetimeOfDeparture());
                date2 = df1.parse(ci.getDatetimeOfArival());
            } catch (ParseException e) {
                e.printStackTrace();
            }

            df2 = new SimpleDateFormat("HH:mm:ss", Locale.US);
            try {
                date3 = df2.parse(ci.getTimeDaily());
            } catch (ParseException e) {
                e.printStackTrace();
            }

            //set values
            try {
                rideInfoHandler.rideFromDailyDate.setText(new SimpleDateFormat("dd MMM yyyy", Locale.US).format(date1));
                rideInfoHandler.rideToDailyDate.setText(new SimpleDateFormat("dd MMM yyyy", Locale.US).format(date2));
                rideInfoHandler.rideTimeDaily.setText("At " + new SimpleDateFormat("HH:mm", Locale.US).format(date3));
                rideInfoHandler.journeyDetails.setText(ci.getFromCity() + " - " + ci.getToCity());
                rideInfoHandler.callFind = callFInd;
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else {

            dateTime = ci.getDatetimeOfDeparture().split(" ");
//            String date[] = dateTime[0].split("-");
//            String finalDate = date[2] + "-" + date[1] + "-" + date[0];
            rideInfoHandler.rideBean = ci;

            df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
            try {
                date1 = df1.parse(ci.getDatetimeOfDeparture());
                time = dateTime[1].split(":");
                rideInfoHandler.rideDateTime.setText(new SimpleDateFormat("EEE dd MMM yyyy", Locale.US).format(date1));
                rideInfoHandler.rideTime.setText(time[0] + ":" + time[1]);

                rideInfoHandler.journeyDetails.setText(ci.getFromCity() + " - " + ci.getToCity());
            } catch (ParseException e) {
                e.printStackTrace();
            }

            rideInfoHandler.callFind = callFInd;
        }

//        if (ci.getRideViewType().equalsIgnoreCase("myride")) {

        if (ci.getStatus() > 0) {
            rideInfoHandler.expired.setText("Status: Active");
            rideInfoHandler.expired.setTextColor(Color.parseColor("#008000"));
        } else {
            rideInfoHandler.expired.setText("Status: Pending for Approval");
            rideInfoHandler.expired.setTextColor(Color.parseColor("#000000"));
        }

        if (ci.getIsDeleted() > 0) {
            rideInfoHandler.expired.setText("Status: Deleted");
            rideInfoHandler.expired.setTextColor(Color.parseColor("#FF0000"));
        }

    }

}