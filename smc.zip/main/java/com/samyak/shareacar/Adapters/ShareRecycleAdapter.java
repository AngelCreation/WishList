package com.samyak.shareacar.Adapters;

import android.content.Context;
import android.content.pm.ResolveInfo;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.samyak.shareacar.R;

import java.util.List;

/**
 * Created by admin on 1/23/17.
 */

public class ShareRecycleAdapter extends RecyclerView.Adapter<ShareRecycleAdapter.ShareHolder> implements View.OnClickListener {
    List<ResolveInfo> items;
    Context context;
    OnLlClickListner onLlClickListner;
    private LayoutInflater mInflater;

    public ShareRecycleAdapter(Context context, List<ResolveInfo> items) {
        this.mInflater = LayoutInflater.from(context);
        this.items = items;
        this.context = context;
    }

    @Override
    public ShareRecycleAdapter.ShareHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View lv = LayoutInflater.from(context).inflate(R.layout.custom_share_list, parent, false);
        return new ShareHolder(lv);
    }

    @Override
    public void onBindViewHolder(ShareRecycleAdapter.ShareHolder holder, int position) {
        ResolveInfo obj = items.get(position);
        holder.name.setText(obj.activityInfo.applicationInfo.loadLabel(context.getPackageManager()).toString());
//        holder.name.setText(obj.loadLabel(context.getPackageManager()).toString());
        holder.logo.setImageDrawable(obj.activityInfo.applicationInfo.loadIcon(context.getPackageManager()));
//        holder.logo.setImageDrawable(obj.loadIcon(context.getPackageManager()));

        holder.llView.setOnClickListener(this);
        holder.llView.setTag(R.string.app_name, position);

    }

    @Override
    public void onClick(View view) {
        LinearLayout ll = (LinearLayout) view;
        int i = (int) ll.getTag(R.string.app_name);

        onLlClickListner.OnLlClicked(view, i, items);

    }

    public void setOnLlClickListner(OnLlClickListner onLlClickListner) {
        this.onLlClickListner = onLlClickListner;
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public interface OnLlClickListner {
        void OnLlClicked(View view, int position, List<ResolveInfo> list);
    }

    public class ShareHolder extends RecyclerView.ViewHolder {

        TextView name;
        ImageView logo;
        LinearLayout llView;

        public ShareHolder(View convertView) {
            super(convertView);

            name = (TextView) convertView.findViewById(R.id.tv_share_adapter);
            logo = (ImageView) convertView.findViewById(R.id.applogo);
            llView = (LinearLayout) convertView.findViewById(R.id.llView);


        }
    }
}
