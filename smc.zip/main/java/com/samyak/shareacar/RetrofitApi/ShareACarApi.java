package com.samyak.shareacar.RetrofitApi;

import com.samyak.shareacar.Models.CarInfoBean;
import com.samyak.shareacar.Models.PostRideBean;
import com.samyak.shareacar.Models.UpdateDailyRideBean;
import com.samyak.shareacar.Models.UserInfoBean;
import com.samyak.shareacar.Models.UserRideInfoBean;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ShareACarApi {

    @FormUrlEncoded
    @POST("entities.userinfo/login")
    Call<ResponseBody> sendLoginInfo(@Field("email") String first,
                                     @Field("password") String last,
                                     @Field("userType") String user);

    @FormUrlEncoded
    @POST("entities.userinfo/register")
    Call<ResponseBody> sendRegisterInfo(@Field("password") String first,
                                        @Field("firstName") String firstName,
                                        @Field("lastName") String lastName,
                                        @Field("email") String email,
                                        @Field("mobileNo") String mobileNo,
                                        @Field("userType") String user);

    @FormUrlEncoded
    @POST("entities.userinfo/forgotPassword")
    Call<ResponseBody> forgotPass(@Field("email") String first);

    @POST("entities.userinfo/getRate")
    Call<ResponseBody> getRate();

    @FormUrlEncoded
    @POST("entities.userinfo/addUpdateCarInfo")
    Call<ResponseBody> addUpdateCarInfo(@Field("userId") String userId,
                                        @Field("carName") String carName,
                                        @Field("carCompany") String carCompany,
                                        @Field("carYear") String carYear,
                                        @Field("carType") String carType,
                                        @Field("fuelType") String fuelType);

    @FormUrlEncoded
    @POST("entities.userinfo/updatePassword")
    Call<ResponseBody> updatePassword(@Field("userId") String userId,
                                      @Field("curPassword") String curPassword,
                                      @Field("newPassword") String newPassword);

    @FormUrlEncoded
    @POST("entities.userinfo/findRide")
    Call<List<UserRideInfoBean>> findRide(@Field("userId") String userId,
                                          @Field("startCity") String startCity,
                                          @Field("destCity") String destCity,
                                          @Field("rideDate") String rideDate);

    @FormUrlEncoded
    @POST("entities.userinfo/getUserRide1")
    Call<List<UserRideInfoBean>> getUserRide(@Field("userId") String userId);

    @FormUrlEncoded
    @POST("entities.userinfo/updateUserInfo")
    Call<ResponseBody> updateUserInfo(@Field("userId") String userId,
                                      @Field("firstName") String firstName,
                                      @Field("lastName") String lastName,
                                      @Field("email") String email,
                                      @Field("mobileNo") String mobileNo);

    @FormUrlEncoded
    @POST("entities.userinfo/getCarInfo")
    Call<CarInfoBean> getCarInfo(@Field("userId") String userId);

    @POST("entities.userinfo/postRide1")
    Call<ResponseBody> addRide(@Body PostRideBean rideInfo);

    @POST("entities.userinfo/postRideDaily")
    Call<ResponseBody> postRideDaily(@Body PostRideBean rideInfo);

    @FormUrlEncoded
    @POST("entities.userinfo/getUserInfo")
    Call<UserInfoBean> getUserInfo(@Field("userId") String userId);

    @FormUrlEncoded
    @POST("entities.userinfo/updateRide")
    Call<ResponseBody> updateRide(@Field("rideId") String rideId,
                                  @Field("date") String date,
                                  @Field("time") String time,
                                  @Field("pricePerPerson") String pricePerPerson,
                                  @Field("noOfPersonAvailable") String noOfPersonAvailable,
                                  @Field("rideMessage") String rideMessage,
                                  @Field("finalRates") String finalRates);

    @POST("entities.userinfo/updateDailyRide")
    Call<ResponseBody> updateDailyRide(@Body UpdateDailyRideBean dailyRideBean);

    @FormUrlEncoded
    @POST("entities.userinfo/deleteRide")
    Call<ResponseBody> deleteRide(@Field("rideId") String rideId);

    @FormUrlEncoded
    @POST("entities.userinfo/deleteDailyRide")
    Call<ResponseBody> deleteDailyRide(@Field("dailyRideId") String rideId);

    @FormUrlEncoded
    @POST("entities.userinfo/deleteStopage")
    Call<ResponseBody> deleteStopage(@Field("stopageId") String stopageId);

    @FormUrlEncoded
    @POST("entities.userinfo/deleteStopageDaily")
    Call<ResponseBody> deleteStopageDaily(@Field("stopageId") String stopageId);

}
