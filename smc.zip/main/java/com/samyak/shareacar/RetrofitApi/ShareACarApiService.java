package com.samyak.shareacar.RetrofitApi;

import android.content.Context;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.jackson.JacksonConverterFactory;

public class ShareACarApiService {

    ShareACarApi shareACarApi;
    Context context;
        String BASE_URL = "http://glrinfo.com:6090/ShareMyCarWebService/webresources/";       //live
//    String BASE_URL = "http://10.100.112.91:6090/ShareMyCarWebService/webresources/";    //Kushal Pc

    public ShareACarApiService(Context context) {
        this.context = context;
        OkHttpClient client = null;

        client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(120, TimeUnit.SECONDS)
//                .addNetworkInterceptor(new StethoInterceptor()) //stetho
                .build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(JacksonConverterFactory.create())
                .client(client)
                .build();
        shareACarApi = retrofit.create(ShareACarApi.class);
    }

    public ShareACarApi getShareACarApi() {
        return shareACarApi;
    }
}