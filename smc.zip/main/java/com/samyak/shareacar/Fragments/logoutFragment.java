package com.samyak.shareacar.Fragments;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.samyak.shareacar.BeforeLogin.Main;
import com.samyak.shareacar.R;

public class logoutFragment extends Fragment {

    TextView textviewTitle = null;
    ImageView header, shareRide;

    public logoutFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_logout, container, false);
        String db[] = getActivity().databaseList();
        findRideFragment.City[0] = "";
        findRideFragment.City[1] = "";

        SQLiteDatabase mydatabase = getActivity().openOrCreateDatabase(db[0], Context.MODE_PRIVATE, null);
        mydatabase.execSQL("CREATE TABLE IF NOT EXISTS loginInfo(userId INTEGER ,carId INTEGER , contactNo TEXT , emailId TEXT, userName TEXT);");
        mydatabase.execSQL("DELETE FROM loginInfo;");
        mydatabase.close();

        /*HomeFragment hf = new HomeFragment();
        Bundle bundle = new Bundle();
        bundle.putBoolean("Logout",true);
        hf.setArguments(bundle);

        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame, hf);
        transaction.addToBackStack(null);
        transaction.commit();*/

        Intent it = new Intent(getActivity(), Main.class);
        it.putExtra("Logout", true);
        getActivity().finish();
        startActivity(it);
        getActivity().overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
        return v;
    }

    @Override
    public void onResume() {
        textviewTitle = (TextView) getActivity().findViewById(R.id.textviewTitle);
        if (textviewTitle.getVisibility() == View.GONE)
            textviewTitle.setVisibility(View.VISIBLE);
        textviewTitle.setText("Log Out");

        header = (ImageView) getActivity().findViewById(R.id.tv_header_title);
        if (header.getVisibility() == View.VISIBLE)
            header.setVisibility(View.GONE);

        shareRide = (ImageView) getActivity().findViewById(R.id.shareRide);
        if (shareRide.getVisibility() == View.VISIBLE)
            shareRide.setVisibility(View.GONE);
        super.onResume();
    }

}
