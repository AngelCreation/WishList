package com.samyak.shareacar.Fragments;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.androidadvance.topsnackbar.TSnackbar;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.AutocompleteFilter;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceSelectionListener;
import com.google.android.gms.maps.model.LatLng;
import com.samyak.shareacar.BeforeLogin.Main;
import com.samyak.shareacar.R;

import java.io.IOException;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class findRideFragment extends Fragment {

    public static String City[] = new String[2];
    private static View view;
    TextView textviewTitle = null;
    ImageView header, shareRide;
    TextView rideDate = null;
    Double lat[] = new Double[2];
    Double longi[] = new Double[2];
    Button Submit = null;
    //    int hours = 0;
    //    int minutes = 0;
    int day = 0;
    int month = 0;
    int year = 0;

    String dateTxt;
    String months[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    int userId = 0;
    String countrySource = "", countryDest = "";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        if (view != null) {
            ViewGroup parent = (ViewGroup) view.getParent();
            if (parent != null)
                parent.removeView(view);
        }
        try {
            view = inflater.inflate(R.layout.fragment_find_ride, container, false);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            String db[] = getActivity().databaseList();

            SQLiteDatabase mydatabase = getActivity().openOrCreateDatabase(db[0], Context.MODE_PRIVATE, null);
            mydatabase.execSQL("CREATE TABLE IF NOT EXISTS loginInfo(userId INTEGER ,carId INTEGER , contactNo TEXT , emailId TEXT, userName TEXT);");
            Cursor c = mydatabase.rawQuery("Select * from loginInfo", null);

            rideDate = (TextView) view.findViewById(R.id.txt_ride_date_find);
            rideDate.setText("");
            Submit = (Button) view.findViewById(R.id.btn_find);
            Submit.setEnabled(false);
            Submit.getBackground().setAlpha(128);
            if (valid()) {
                Submit.setEnabled(true);
                Submit.getBackground().setAlpha(255);
            }
            if (c != null) {
                if (c.moveToFirst()) {
                    do {
                        userId = c.getInt(c.getColumnIndex("userId"));
//                        Log.e("USER ID", "in find ride" + userId);

                    } while (c.moveToNext());
                }
            }

            if (userId == 0) {
                Intent intent = new Intent(getActivity(), Main.class);
                startActivity(intent);
            }
            mydatabase.close();

            Submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Submit.getBackground().setAlpha(255);
                    String startCityFind = City[0];
                    String destCityFind = City[1];
                    String rideDateTxt = dateTxt;

                    if (startCityFind.equals(destCityFind)) {
                        TSnackbar snackbar = TSnackbar
                                .make(getView(), "Please select different destination", TSnackbar.LENGTH_LONG);
                        snackbar.setActionTextColor(Color.WHITE);
                        View snackbarView = snackbar.getView();
                        snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                        textView.setTextColor(Color.WHITE);
                        textView.setTypeface(Typeface.DEFAULT_BOLD);
                        snackbar.show();

                    } else if (!countrySource.equals(countryDest)) {
                        TSnackbar snackbar = TSnackbar
                                .make(getView(), "Cities of different countries", TSnackbar.LENGTH_LONG);
                        snackbar.setActionTextColor(Color.WHITE);
                        View snackbarView = snackbar.getView();
                        snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                        textView.setTextColor(Color.WHITE);
                        textView.setTypeface(Typeface.DEFAULT_BOLD);
                        snackbar.show();

                    } else if (valid()) {
                        rideListFragment rlf = new rideListFragment();
                        rideDate.setText("");
                        Bundle args = new Bundle();
                        args.putString("startCityFind", startCityFind);
                        args.putString("destCityFind", destCityFind);
                        args.putString("rideDateTxt", rideDateTxt);
                        rlf.setArguments(args);
                        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                        // transaction.add(R.id.frame, orf);
                        transaction.replace(R.id.frame, rlf, "RideListFragment");
                        transaction.addToBackStack(null);
                        transaction.commit();
                    } else {
                        TSnackbar snackbar = TSnackbar
                                .make(getView(), "Please check your connection", TSnackbar.LENGTH_LONG);
                        snackbar.setActionTextColor(Color.WHITE);
                        View snackbarView = snackbar.getView();
                        snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                        textView.setTextColor(Color.WHITE);
                        textView.setTypeface(Typeface.DEFAULT_BOLD);
                        snackbar.show();
                    }
                }
            });

            rideDate.setOnTouchListener(new View.OnTouchListener() {
                DatePickerDialog.OnDateSetListener ondate = new DatePickerDialog.OnDateSetListener() {

                    public void onDateSet(DatePicker view, int year1, int monthOfYear, int dayOfMonth) {
                        try {
                            day = dayOfMonth;
                            month = monthOfYear;
                            year = year1;
                            rideDate.setText(String.valueOf(dayOfMonth) + " " + months[monthOfYear]
                                    + " " + String.valueOf(year1));
                            dateTxt = String.valueOf(dayOfMonth) + "-" + String.valueOf(monthOfYear + 1)
                                    + "-" + String.valueOf(year1);
                            if (valid()) {
                                Submit.setEnabled(true);
                                Submit.getBackground().setAlpha(255);
                            } else {
                                Submit.setEnabled(false);
                                Submit.getBackground().setAlpha(128);
                            }
                        } catch (Exception e1) {
                            e1.printStackTrace();
                        }
                    }
                };

                @Override
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                        try {
                            //close keyboard
                            InputMethodManager imm = (InputMethodManager) view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                            if (imm != null) {
                                imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                            }
                            if (valid()) {
                                Submit.setEnabled(true);
                                Submit.getBackground().setAlpha(255);
                            } else {
                                Submit.setEnabled(false);
                                Submit.getBackground().setAlpha(128);
                            }
                            DatePickerFragment date = new DatePickerFragment();
                            Calendar calender = Calendar.getInstance();
                            Bundle args = new Bundle();
                            int thisDay = day;
                            int thisYear = year;
                            int thisMonth = month;
                            if (thisDay == 0)
                                thisDay = calender.get(Calendar.DAY_OF_MONTH);
                            if (thisYear == 0)
                                thisYear = calender.get(Calendar.YEAR);
                            if (thisMonth == 0)
                                thisMonth = calender.get(Calendar.MONTH);
                            args.putInt("year", thisYear);
                            args.putInt("month", thisMonth);
                            args.putInt("day", thisDay);

                            args.putLong("minDate", calender.getTimeInMillis());
                            calender.add(Calendar.DAY_OF_MONTH, 30);
                            args.putLong("maxDate", calender.getTimeInMillis());
                            date.setArguments(args);

                            date.setCallBack(ondate);
                            date.show(getFragmentManager(), "Date Picker");
                        } catch (Exception e1) {
                            e1.printStackTrace();
                        }
                    }
                    return true;
                }
            });

            final CustomPlaceAutoCompleteFragment autocompleteFragment = (CustomPlaceAutoCompleteFragment)
                    getActivity().getFragmentManager().findFragmentById(R.id.place_autocomplete_fragment_find);
            final CustomPlaceAutoCompleteFragment autocompleteFragmentDest = (CustomPlaceAutoCompleteFragment)
                    getActivity().getFragmentManager().findFragmentById(R.id.place_autocomplete_fragment_destination_find);
            AutocompleteFilter typeFilter = new AutocompleteFilter.Builder()
                    .setTypeFilter(AutocompleteFilter.TYPE_FILTER_GEOCODE)
                    .build();
            autocompleteFragment.setFilter(typeFilter);
            autocompleteFragmentDest.setFilter(typeFilter);

            final CustomPlaceAutoCompleteFragment finalAutocompleteFragment = autocompleteFragment;
            ((EditText) finalAutocompleteFragment.getView().findViewById(R.id.editWorkLocation)).setHint("From");
            ((ImageView) finalAutocompleteFragment.getView().findViewById(R.id.set_img)).setImageResource(R.drawable.ic_from);
            autocompleteFragment.getView().findViewById(R.id.place_autocomplete_clear_button).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        Submit.setEnabled(false);
                        Submit.getBackground().setAlpha(128);
                        ((EditText) finalAutocompleteFragment.getView().findViewById(R.id.editWorkLocation)).setText("");
                        view.setVisibility(View.GONE);
                        City[0] = null;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            final CustomPlaceAutoCompleteFragment finalAutocompleteFragmentDest = autocompleteFragmentDest;
            ((EditText) finalAutocompleteFragmentDest.getView().findViewById(R.id.editWorkLocation)).setHint("To");
            ((ImageView) finalAutocompleteFragmentDest.getView().findViewById(R.id.set_img)).setImageResource(R.drawable.ic_to);

            autocompleteFragmentDest.getView().findViewById(R.id.place_autocomplete_clear_button).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Submit.setEnabled(false);
                    Submit.getBackground().setAlpha(128);
                    try {
                        ((EditText) finalAutocompleteFragmentDest.getView().findViewById(R.id.editWorkLocation)).setText("");
                        view.setVisibility(View.GONE);
                        City[1] = null;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            //clear data when co
            autocompleteFragment.getView().findViewById(R.id.place_autocomplete_clear_button).performClick();
            autocompleteFragmentDest.getView().findViewById(R.id.place_autocomplete_clear_button).performClick();
            autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
                @Override
                public void onPlaceSelected(Place place) {
                    autocompleteFragment.getView().findViewById(R.id.place_autocomplete_clear_button).setVisibility(View.VISIBLE);
                    // TODO: Get info about the selected place.
                    //Log.i(TAG, "Place: " + place.getName());//get place details here

                    LatLng coordinates = place.getLatLng(); // Get the coordinates from your place
                    Geocoder geocoder = new Geocoder(getActivity(), Locale.getDefault());

                    List<Address> addresses = null; // Only retrieve 1 address
                    try {
                        addresses = geocoder.getFromLocation(
                                coordinates.latitude,
                                coordinates.longitude,
                                1);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Address address1 = addresses.get(0);
                    countrySource = address1.getCountryCode();

                    City[0] = place.getName().toString();
                    Geocoder coder = new Geocoder(getActivity().getApplicationContext());
                    List<Address> address;
                    LatLng p1 = null;

                    try {
                        address = coder.getFromLocationName(City[0], 5);
                        if (address == null) {
                            //return null;
                        }
                        Address location = address.get(0);
                        lat[0] = location.getLatitude();
                        longi[0] = location.getLongitude();

                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                    if (valid()) {
                        Submit.setEnabled(true);
                        Submit.getBackground().setAlpha(255);
                    } else {
                        Submit.setEnabled(false);
                        Submit.getBackground().setAlpha(128);
                    }
                }

                @Override
                public void onError(Status status) {
                    // TODO: Handle the error.
//                    Log.i("MAP", "An error occurred: " + status);
                }
            });
            autocompleteFragmentDest.setOnPlaceSelectedListener(new PlaceSelectionListener() {
                @Override
                public void onPlaceSelected(Place place) {
                    autocompleteFragmentDest.getView().findViewById(R.id.place_autocomplete_clear_button).setVisibility(View.VISIBLE);
                    // TODO: Get info about the selected place.
                    //Log.i(TAG, "Place: " + place.getName());//get place details here

                    LatLng coordinates = place.getLatLng(); // Get the coordinates from your place
                    Geocoder geocoder = new Geocoder(getActivity(), Locale.getDefault());

                    List<Address> addresses = null; // Only retrieve 1 address
                    try {
                        addresses = geocoder.getFromLocation(
                                coordinates.latitude,
                                coordinates.longitude,
                                1);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Address address1 = addresses.get(0);
                    countryDest = address1.getCountryCode();

                    City[1] = place.getName().toString();
                    Geocoder coder = new Geocoder(getActivity().getApplicationContext());
                    List<Address> address;
                    LatLng p1 = null;

                    try {
                        address = coder.getFromLocationName(City[1], 5);
                        if (address == null) {
                            //return null;
                        }
                        Address location = address.get(0);
                        lat[1] = location.getLatitude();
                        longi[1] = location.getLongitude();

                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }

                    if (valid()) {
                        Submit.setEnabled(true);
                        Submit.getBackground().setAlpha(255);
                    } else {
                        Submit.setEnabled(false);
                        Submit.getBackground().setAlpha(128);
                    }
                }

                @Override
                public void onError(Status status) {
//                    Log.i("MAP", "An error occurred: " + status);
                }
            });
            //return v;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return view;
    }

    public boolean valid() {
        boolean valid = true;
        String startCityFind = City[0];
        String destCityFind = City[1];
        String rideDateTxt = dateTxt;
        if (startCityFind == null || startCityFind.isEmpty()) {
            valid = false;
        }
        if (destCityFind == null || destCityFind.isEmpty()) {
            //newPassword.setError("at least 5 characters");
            valid = false;
        }
        if (rideDateTxt == null || rideDateTxt.isEmpty()) {
            //rideDate.setError("Please select ride date");
            valid = false;
        }
        return valid;
    }

    /*private void turnOnLocation(){
        //check location is off? ask to turn on
        int off = 0;
        try {
            off = Settings.Secure.getInt(getActivity().getContentResolver(), Settings.Secure.LOCATION_MODE);
        } catch (Settings.SettingNotFoundException e) {
            e.printStackTrace();
        }
        if(off==0){
            AlertDialog.Builder builder1 = new AlertDialog.Builder(getActivity());
            builder1.setMessage("For best results, let your device turn on location using Google's location service.");
            builder1.setCancelable(true);

            builder1.setPositiveButton(
                    "Ok",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                            Intent onGPS = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                            startActivity(onGPS);
                        }
                    });

            builder1.setNegativeButton(
                    "Cancel",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });

            AlertDialog alert11 = builder1.create();
            alert11.show();

        }

    }*/
    @Override
    public void onResume() {
        textviewTitle = (TextView) getActivity().findViewById(R.id.textviewTitle);
        if (textviewTitle.getVisibility() == View.GONE)
            textviewTitle.setVisibility(View.VISIBLE);
        textviewTitle.setText("Find Ride");

        header = (ImageView) getActivity().findViewById(R.id.tv_header_title);
        if (header.getVisibility() == View.VISIBLE)
            header.setVisibility(View.GONE);

        shareRide = (ImageView) getActivity().findViewById(R.id.shareRide);
        if (shareRide.getVisibility() == View.VISIBLE)
            shareRide.setVisibility(View.GONE);

        super.onResume();
    }
}
