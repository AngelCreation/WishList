package com.samyak.shareacar.Fragments;

//import android.app.DialogFragment;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.TimePicker;

import com.androidadvance.topsnackbar.TSnackbar;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.AutocompleteFilter;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceSelectionListener;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.samyak.shareacar.Helpers.DirectionsJSONParser;
import com.samyak.shareacar.Helpers.ExpandableLayout;
import com.samyak.shareacar.Helpers.SingleShotLocationProvider;
import com.samyak.shareacar.Helpers.util;
import com.samyak.shareacar.HomePage;
import com.samyak.shareacar.Models.PostRideBean;
import com.samyak.shareacar.R;
import com.samyak.shareacar.RetrofitApi.ShareACarApiService;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.Context.LOCATION_SERVICE;

public class offerRide extends Fragment {

    final static String[] startCity = new String[2];
    private static View view;

    //    private static final String PLACES_SEARCH_URL = "https://maps.googleapis.com/maps/api/place/search/json?rankBy=distance&";
    private static boolean connectionProb = false;
    private static boolean sourceProb = false;
    private static boolean destProb = false;
    final double[] latSource = new double[2];
    final double[] longiSource = new double[2];
    final double[] stopLat = new double[5];
    final double[] stopLong = new double[5];
    public ArrayList<String> distance = new ArrayList<String>(Collections.nCopies(6, ""));
    public ArrayList<String> time = new ArrayList<String>(Collections.nCopies(6, ""));
    public ArrayList<String> stops = new ArrayList<String>(Collections.nCopies(5, ""));
    TextView textviewTitle = null;
    ImageView header, shareRide;
    Button offerRide1;
    String rate = "2";
    GoogleMap map;
    TextView rideDate, rideTime, fromDaily, toDaily, timeDaily;
    int hours = -1;
    int minutes = -1;
    int day = 0;
    int month = 0;
    int year = 0;
    LinearLayout stop1, stop2, stop3, stop4, stop5;
    LinearLayout llDateTime;
    String dateTxt, fromDailyTxt, toDailyTxt, fromDay, toDay;

    //    Calendar  calFromDaily,calToDaily;
    String months[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    Polyline polyline = null;
    Marker sourceMarker = null;
    Marker destMarker = null;
    Marker stop1Marker = null;
    Marker stop2Marker = null;
    Marker stop3Marker = null;
    Marker stop4Marker = null;
    Marker stop5Marker = null;
    ArrayList<LatLng> markerPoints;
    ExpandableLayout expandableLayout;
    CheckBox checkboxDaily, checkboxSun, checkboxMon, checkboxWed, checkboxTue, checkboxThr, checkboxFri, checkboxSat;
    ArrayList days = new ArrayList();
    ScrollView ScrollView01;
    CustomPlaceAutoCompleteFragment1 autocompleteFragment = null;
    CustomPlaceAutoCompleteFragment autocompleteFragmentDest = null;
    CustomPlaceAutoCompleteFragment stop_1 = null, stop_2 = null, stop_3 = null, stop_4 = null, stop_5 = null;
    Call<ResponseBody> call;
    String countrySource = "", countryDest = "";
    double latitude = 0.0; // latitude
    double longitude = 0.0; // longitude
    TextView ttMon, ttTue, ttWed, ttThr, ttFri, ttSat, ttSun;
    private ProgressDialog progress;
    private SupportMapFragment mMapFragment;
    private boolean isRideDaily = false;
    private LatLng sourceCoordinates, destCoordinates;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        startCity[0] = null;
        startCity[1] = null;

        mMapFragment = (SupportMapFragment) this.getChildFragmentManager().findFragmentById(R.id.map);
    }

    public View onCreateView(final LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {

        int userId, carId;

        call = new ShareACarApiService(getActivity()).getShareACarApi().getRate();
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    if (response.code() == 200) {
                        rate = response.body().string();
                    }
                } catch (Exception e) {
                    rate = "2";
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                TSnackbar snackbar = TSnackbar
                        .make(getView(), "Please check your connection", TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.WHITE);
                textView.setTypeface(Typeface.DEFAULT_BOLD);
                snackbar.show();
            }
        });

        SQLiteDatabase mydatabase = getActivity().openOrCreateDatabase("shareACar", getActivity().MODE_PRIVATE, null);
        mydatabase.execSQL("CREATE TABLE IF NOT EXISTS loginInfo(userId INTEGER ,carId INTEGER , contactNo TEXT , emailId TEXT, userName TEXT);");
        Cursor c = mydatabase.rawQuery("Select * from loginInfo", null);
        if (c != null) {
            if (c.moveToFirst()) {
                do {
                    userId = c.getInt(c.getColumnIndex("userId"));
                    carId = c.getInt(c.getColumnIndex("carId"));
                } while (c.moveToNext());
            }
        }

        if (view != null) {
            ViewGroup parent = (ViewGroup) view.getParent();
            if (parent != null)
                parent.removeView(view);
        }

        try {
            view = inflater.inflate(R.layout.fragment_offer_ride, container, false);
        } catch (Exception e) {
            e.printStackTrace();
        }
        //valid();

        mMapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        stop1 = (LinearLayout) view.findViewById(R.id.layout_stop_1);
        stop2 = (LinearLayout) view.findViewById(R.id.layout_stop_2);
        stop3 = (LinearLayout) view.findViewById(R.id.layout_stop_3);
        stop4 = (LinearLayout) view.findViewById(R.id.layout_stop_4);
        stop5 = (LinearLayout) view.findViewById(R.id.layout_stop_5);

        llDateTime = (LinearLayout) view.findViewById(R.id.llDateTime);

        ScrollView01 = (ScrollView) view.findViewById(R.id.ScrollView01);
//        getAddress = (Button) view.findViewById(R.id.getAddress);

        expandableLayout = (ExpandableLayout) view.findViewById(R.id.expandablelayout);

        checkboxDaily = (CheckBox) view.findViewById(R.id.checkboxDaily);
        checkboxSun = (CheckBox) view.findViewById(R.id.checkboxSun);
        checkboxMon = (CheckBox) view.findViewById(R.id.checkboxMon);
        checkboxTue = (CheckBox) view.findViewById(R.id.checkboxTue);
        checkboxWed = (CheckBox) view.findViewById(R.id.checkboxWed);
        checkboxThr = (CheckBox) view.findViewById(R.id.checkboxThr);
        checkboxFri = (CheckBox) view.findViewById(R.id.checkboxFri);
        checkboxSat = (CheckBox) view.findViewById(R.id.checkboxSat);

        ttMon = (TextView) view.findViewById(R.id.ttMon);
        ttTue = (TextView) view.findViewById(R.id.ttTue);
        ttWed = (TextView) view.findViewById(R.id.ttWed);
        ttThr = (TextView) view.findViewById(R.id.ttThr);
        ttFri = (TextView) view.findViewById(R.id.ttFri);
        ttSat = (TextView) view.findViewById(R.id.ttSat);
        ttSun = (TextView) view.findViewById(R.id.ttSun);

        checkboxDaily.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (rideDate.getText().toString() != null || rideDate.getText().toString() != "") {
                            fromDaily.setText(rideDate.getText().toString());
                        }

                        if (rideTime.getText().toString() != null || rideTime.getText().toString() != "") {
                            timeDaily.setText(rideTime.getText().toString());
                        }

                        if (checkboxDaily.isChecked()) {
                            visibleAllDays();
                            llDateTime.setVisibility(View.GONE);
                            isRideDaily = true;
                        } else {
                            clearDailyData();
                            llDateTime.setVisibility(View.VISIBLE);
                            isRideDaily = false;
                        }
                        expandableLayout.toggleExpansion();
                    }
                });


//        turnOnLocation("For best results, let your device turn on location using Google's location service.");

        FragmentManager fragmentManager = getChildFragmentManager();
//        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
//        mMapFragment.;
//        fragmentTransaction.replace(R.id.map, mMapFragment).commit();

        try {

            //map = ((SupportMapFragment) this.getChildFragmentManager().findFragmentById(R.id.map)).getMap();
//                if (map == null) {
//                    map = ((SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map)).getMap();
            map = mMapFragment.getMap();
//                }

        } catch (Exception e) {
            e.printStackTrace();
        }
        // Getting Map for the SupportMapFragment
        offerRide1 = (Button) view.findViewById(R.id.btn_offer_ride_1);
        offerRide1.getBackground().setAlpha(128);
//        final LocationManager[] locationManager = {(LocationManager) getActivity().getSystemService(LOCATION_SERVICE)};
//        Criteria criteria = new Criteria();

        if (map != null) {
            if (startCity[1] == null && startCity[0] == null) {

                LatLngBounds.Builder builder = new LatLngBounds.Builder();
                builder.include(new LatLng(25.82, 30.84));
                builder.include(new LatLng(26.29, 135.09));
                LatLngBounds bounds = builder.build();

                map.moveCamera(CameraUpdateFactory.newLatLngZoom(
                        bounds.getCenter(), 3));

//                        new LatLng(finalloc.getLatitude(), finalloc.getLongitude()), 13));
                map.setMyLocationEnabled(false);
                map.getUiSettings().setZoomGesturesEnabled(false);
                map.getUiSettings().setMapToolbarEnabled(false);
                map.getUiSettings().setScrollGesturesEnabled(true);
                map.getUiSettings().setZoomControlsEnabled(true);
               /* CameraPosition cameraPosition = new CameraPosition.Builder()
                        .target(new LatLng(23.74,79.36))      // Sets the center of the map to location user
                        .zoom(17)                   // Sets the zoom
                        //.bearing(90)                // Sets the orientation of the camera to east
                        //.tilt(40)                   // Sets the tilt of the camera to 30 degrees
                        .build();                   // Creates a CameraPosition from the builder
                map.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));*/
            }
        }

        try {
            autocompleteFragment = (CustomPlaceAutoCompleteFragment1)
                    getActivity().getFragmentManager().findFragmentById(R.id.place_autocomplete_fragment);
            autocompleteFragmentDest = (CustomPlaceAutoCompleteFragment)
                    getActivity().getFragmentManager().findFragmentById(R.id.place_autocomplete_fragment_destination);
            stop_1 = (CustomPlaceAutoCompleteFragment)
                    getActivity().getFragmentManager().findFragmentById(R.id.place_autocomplete_stop_1);
            stop_2 = (CustomPlaceAutoCompleteFragment)
                    getActivity().getFragmentManager().findFragmentById(R.id.place_autocomplete_stop_2);
            stop_3 = (CustomPlaceAutoCompleteFragment)
                    getActivity().getFragmentManager().findFragmentById(R.id.place_autocomplete_stop_3);
            stop_4 = (CustomPlaceAutoCompleteFragment)
                    getActivity().getFragmentManager().findFragmentById(R.id.place_autocomplete_stop_4);
            stop_5 = (CustomPlaceAutoCompleteFragment)
                    getActivity().getFragmentManager().findFragmentById(R.id.place_autocomplete_stop_5);
            if (stops.get(1) == null || stops.get(1).equals(""))
                stop2.setVisibility(View.GONE);
            if (stops.get(2) == null || stops.get(2).equals(""))
                stop3.setVisibility(View.GONE);
            if (stops.get(3) == null || stops.get(3).equals(""))
                stop4.setVisibility(View.GONE);
            if (stops.get(4) == null || stops.get(4).equals(""))
                stop5.setVisibility(View.GONE);
            AutocompleteFilter typeFilter = new AutocompleteFilter.Builder()
                    .setTypeFilter(AutocompleteFilter.TYPE_FILTER_GEOCODE)
//                    .setTypeFilter(AutocompleteFilter.TYPE_FILTER_CITIES)
                    .build();
//            autocompleteFragment.setHint("From");
//            autocompleteFragmentDest.setHint("To");
//            stop_1.setHint("Ride Stop 1");
//            stop_2.setHint("Ride Stop 2");
//            stop_3.setHint("Ride Stop 3");
//            stop_4.setHint("Ride Stop 4");
//            stop_5.setHint("Ride Stop 5");
            autocompleteFragment.setFilter(typeFilter);
            autocompleteFragmentDest.setFilter(typeFilter);
            stop_1.setFilter(typeFilter);
            stop_2.setFilter(typeFilter);
            stop_3.setFilter(typeFilter);
            stop_4.setFilter(typeFilter);
            stop_5.setFilter(typeFilter);
            valid();
        } catch (Exception e) {
            e.printStackTrace();
        }

        ((EditText) autocompleteFragment.getView().findViewById(R.id.editWorkLocation)).setHint("From");
        ((ImageView) autocompleteFragment.getView().findViewById(R.id.set_img)).setImageResource(R.drawable.ic_from);

        ((EditText) autocompleteFragment.getView().findViewById(R.id.editWorkLocation)).setText("");

        autocompleteFragment.getView().findViewById(R.id.place_autocomplete_clear).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                offerRide1.setEnabled(false);
                offerRide1.getBackground().setAlpha(128);

                //old clear data code
                /*if (sourceMarker != null) {
                    sourceMarker.remove();
                }

                if (polyline != null) {
                    polyline.remove();
                }
                ((EditText) autocompleteFragment.getView().findViewById(R.id.editWorkLocation)).setText("");
                view.setVisibility(View.INVISIBLE);
                startCity[0] = null;*/

                int off1 = 0;

                try {
                    off1 = Settings.Secure.getInt(getActivity().getContentResolver(), Settings.Secure.LOCATION_MODE);
                } catch (Settings.SettingNotFoundException e) {
                    e.printStackTrace();
                }

                if (off1 != 0) {
                    progress = new ProgressDialog(getActivity(), R.style.appThemeDialogue);

                    progress.setIndeterminate(true);
                    progress.setMessage("Getting Location...");
                    progress.show();

                    /*if (locationManager1 != null) {
                        location = locationManager1
                                .getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                        if (location != null) {
                            latitude = location.getLatitude();
                            longitude = location.getLongitude();
                        }
                    }*/

                    SingleShotLocationProvider.requestSingleUpdate(getActivity(),
                            new SingleShotLocationProvider.LocationCallback() {
                                @Override
                                public void onNewLocationAvailable(SingleShotLocationProvider.GPSCoordinates location) {
                                    progress.dismiss();
                                    latitude = location.latitude;
                                    longitude = location.longitude;

                                    String s = getCompleteAddressString(latitude, longitude);
                                    if (s != "") {
                                        ((EditText) autocompleteFragment.getView().findViewById(R.id.editWorkLocation)).setText(s);
                                    }

                                    latSource[0] = latitude;
                                    longiSource[0] = longitude;

                                    sourceCoordinates = new LatLng(latitude, longitude);

                                    Geocoder geocoder = new Geocoder(getActivity(), Locale.getDefault());

                                    List<Address> addresses = null; // Only retrieve 1 address
                                    try {
                                        addresses = geocoder.getFromLocation(
                                                sourceCoordinates.latitude,
                                                sourceCoordinates.longitude,
                                                1);
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    try {
                                        Address address1 = addresses.get(0);
                                        countrySource = address1.getCountryCode();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                    startCity[0] = getCityname(latitude, longitude);

                                    valid();

                                    if (startCity[1] != null) {
                                        new Thread(new Runnable() {
                                            @Override
                                            public void run() {
                                                plotRoute();
                                            }
                                        }).start();
                                    }
                                }
                            });
                } else {
                    turnOnLocation("Please switch on your device's location service to get your current location");
                }
            }
        });

        ((EditText) autocompleteFragmentDest.getView().findViewById(R.id.editWorkLocation)).setHint("To");
        ((ImageView) autocompleteFragmentDest.getView().findViewById(R.id.set_img)).setImageResource(R.drawable.ic_to);
        autocompleteFragmentDest.getView().findViewById(R.id.place_autocomplete_clear_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                offerRide1.setEnabled(false);
                offerRide1.getBackground().setAlpha(128);
                if (destMarker != null) {
                    destMarker.remove();
                }
                if (polyline != null) {
                    polyline.remove();
                }
                ((EditText) autocompleteFragmentDest.getView().findViewById(R.id.editWorkLocation)).setText("");
                view.setVisibility(View.INVISIBLE);
                startCity[1] = null;
            }
        });

        ((EditText) stop_1.getView().findViewById(R.id.editWorkLocation)).setHint("Ride Stop 1");
        ((ImageView) stop_1.getView().findViewById(R.id.set_img)).setImageResource(R.drawable.ic_stop);
        stop_1.getView().findViewById(R.id.place_autocomplete_clear_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //offerRide1.setEnabled(false);
                ((EditText) stop_1.getView().findViewById(R.id.editWorkLocation)).setText("");
                view.setVisibility(View.INVISIBLE);
                if (stop1Marker != null) {
                    stop1Marker.remove();
                }
//                stops[0] = "";
                stops.set(0, "");
                stopLong[0] = 0;
                stopLat[0] = 0;
                distance.set(1, null);
                stop1Marker = null;

                if (startCity[1] != null && startCity[0] != null) {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            plotRoute();
                        }
                    }).start();


                }
            }
        });

        ((EditText) stop_2.getView().findViewById(R.id.editWorkLocation)).setHint("Ride Stop 2");
        ((ImageView) stop_2.getView().findViewById(R.id.set_img)).setImageResource(R.drawable.ic_stop);
        stop_2.getView().findViewById(R.id.place_autocomplete_clear_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ((EditText) stop_2.getView().findViewById(R.id.editWorkLocation)).setText("");
                view.setVisibility(View.INVISIBLE);
                if (stop2Marker != null) {
                    stop2Marker.remove();
                }
                stops.set(1, "");
                stopLong[1] = 0;
                stopLat[1] = 0;
                distance.set(2, null);
                stop2Marker = null;
                if (startCity[1] != null && startCity[0] != null) {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            plotRoute();
                        }
                    }).start();
                }
            }
        });

        ((EditText) stop_3.getView().findViewById(R.id.editWorkLocation)).setHint("Ride Stop 3");
        ((ImageView) stop_3.getView().findViewById(R.id.set_img)).setImageResource(R.drawable.ic_stop);
        stop_3.getView().findViewById(R.id.place_autocomplete_clear_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ((EditText) stop_3.getView().findViewById(R.id.editWorkLocation)).setText("");
                view.setVisibility(View.INVISIBLE);
                if (stop3Marker != null) {
                    stop3Marker.remove();
                }
                stops.set(2, "");
                stopLong[2] = 0;
                stopLat[2] = 0;
                distance.set(3, null);

                stop3Marker = null;
                if (startCity[1] != null && startCity[0] != null) {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            plotRoute();
                        }
                    }).start();
                }
            }
        });

        ((EditText) stop_4.getView().findViewById(R.id.editWorkLocation)).setHint("Ride Stop 4");
        ((ImageView) stop_4.getView().findViewById(R.id.set_img)).setImageResource(R.drawable.ic_stop);
        stop_4.getView().findViewById(R.id.place_autocomplete_clear_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ((EditText) stop_4.getView().findViewById(R.id.editWorkLocation)).setText("");
                view.setVisibility(View.INVISIBLE);
                if (stop4Marker != null) {
                    stop4Marker.remove();
                }
                stops.set(3, "");
                stopLong[3] = 0;
                stopLat[3] = 0;
                distance.set(4, null);

                stop4Marker = null;
                if (startCity[1] != null && startCity[0] != null) {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            plotRoute();
                        }
                    }).start();
                }
            }
        });

        ((EditText) stop_5.getView().findViewById(R.id.editWorkLocation)).setHint("Ride Stop 5");
        ((ImageView) stop_5.getView().findViewById(R.id.set_img)).setImageResource(R.drawable.ic_stop);
        stop_5.getView().findViewById(R.id.place_autocomplete_clear_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ((EditText) stop_5.getView().findViewById(R.id.editWorkLocation)).setText("");
                view.setVisibility(View.INVISIBLE);
                if (stop5Marker != null) {
                    stop5Marker.remove();
                }
                stops.set(4, "");
                stopLong[4] = 0;
                stopLat[4] = 0;
                distance.set(5, null);

                stop5Marker = null;
                if (startCity[1] != null && startCity[0] != null) {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            plotRoute();
                        }
                    }).start();
                }
            }
        });

//        autocompleteFragment.getView().findViewById(R.id.place_autocomplete_clear_button).performClick();
        autocompleteFragmentDest.getView().findViewById(R.id.place_autocomplete_clear_button).performClick();

        if (autocompleteFragment != null) {
            autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
                @Override
                public void onPlaceSelected(Place place) {
//                    autocompleteFragment.getView().findViewById(R.id.place_autocomplete_clear_button).setVisibility(View.VISIBLE);

                    sourceCoordinates = place.getLatLng(); // Get the coordinates from your place

                    Geocoder geocoder = new Geocoder(getActivity(), Locale.getDefault());

                    List<Address> addresses = null; // Only retrieve 1 address
                    try {
                        addresses = geocoder.getFromLocation(
                                sourceCoordinates.latitude,
                                sourceCoordinates.longitude,
                                1);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    try {
                        Address address1 = addresses.get(0);
                        countrySource = address1.getCountryCode();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    startCity[0] = place.getName().toString();

                    Geocoder coder = new Geocoder(getActivity().getApplicationContext());
                    List<Address> address;
                    LatLng p1 = null;

                    try {
                        address = coder.getFromLocationName(startCity[0], 5);
                        if (address == null) {
                            //return null;
                        }
                        Address location = address.get(0);
                        latSource[0] = location.getLatitude();
                        longiSource[0] = location.getLongitude();

                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                    valid();
                    if (startCity[1] != null) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                plotRoute();
                            }
                        }).start();
                    }
                }

                @Override
                public void onError(Status status) {
//                    Log.i("MAP", "An error occurred: " + status);
                }
            });
        }
        if (autocompleteFragmentDest != null) {
            autocompleteFragmentDest.setOnPlaceSelectedListener(new PlaceSelectionListener() {
                @Override
                public void onPlaceSelected(Place place) {
                    autocompleteFragmentDest.getView().findViewById(R.id.place_autocomplete_clear_button).setVisibility(View.VISIBLE);

                    destCoordinates = place.getLatLng(); // Get the coordinates from your place

//                    filterFlag = true;
//                    CustomPlaceAutoCompleteFragment.getSourceDestBounds(new LatLngBounds(sourceCoordinates,destCoordinates));

                    Geocoder geocoder = new Geocoder(getActivity(), Locale.getDefault());

                    List<Address> addresses = null; // Only retrieve 1 address
                    try {
                        addresses = geocoder.getFromLocation(
                                destCoordinates.latitude,
                                destCoordinates.longitude,
                                1);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    try {
                        Address address1 = addresses.get(0);
                        countryDest = address1.getCountryCode();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    startCity[1] = place.getName().toString();
                    Geocoder coder = new Geocoder(getActivity().getApplicationContext());
                    List<Address> address;
                    LatLng p1 = null;

                    try {
                        address = coder.getFromLocationName(startCity[1], 5);
                        if (address == null) {
                            //return null;
                        }
                        Address location = address.get(0);
                        latSource[1] = location.getLatitude();
                        longiSource[1] = location.getLongitude();

                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                    valid();
                    if (startCity[0] != null) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                plotRoute();
                            }
                        }).start();
                    }
                }

                @Override
                public void onError(Status status) {
                    // TODO: Handle the error.
//                    Log.i("MAP", "An error occurred: " + status);
                }
            });
        }

        if (stop_1 != null) {
            stop_1.setOnPlaceSelectedListener(new PlaceSelectionListener() {
                @Override
                public void onPlaceSelected(Place place) {
                    stop_1.getView().findViewById(R.id.place_autocomplete_clear_button).setVisibility(View.VISIBLE);

                    Geocoder coder = new Geocoder(getActivity().getApplicationContext());
                    List<Address> address;
                    LatLng p1 = null;
                    stop2.setVisibility(View.VISIBLE);

//                    stops[0] = place.getName().toString();
                    stops.set(0, place.getName().toString());
                    try {
                        address = coder.getFromLocationName(stops.get(0), 5);
                        if (address == null) {
                            //return null;
                        }
                        Address location = address.get(0);
                        stopLat[0] = location.getLatitude();
                        stopLong[0] = location.getLongitude();

                    } catch (Exception ex) {

                        ex.printStackTrace();
                    }
                    valid();
                    if (startCity[1] != null && startCity[0] != null && stops.get(0) != null) {
//                        if (HomePage.connectionFlag && util.checkConnection(getActivity()))
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                plotRoute();
                            }
                        }).start();
                       /* else {
                            mapNotLoaded(view);
                        }*/
                    }
                }

                @Override
                public void onError(Status status) {
                    // TODO: Handle the error.
//                    Log.i("MAP", "An error occurred: " + status);
                }
            });
        }
        if (stop_2 != null) {
            stop_2.setOnPlaceSelectedListener(new PlaceSelectionListener() {
                @Override
                public void onPlaceSelected(Place place) {
                    stop_2.getView().findViewById(R.id.place_autocomplete_clear_button).setVisibility(View.VISIBLE);

                    Geocoder coder = new Geocoder(getActivity().getApplicationContext());
                    List<Address> address;
                    LatLng p1 = null;
                    stop3.setVisibility(View.VISIBLE);
//                    stops[1] = place.getName().toString();
                    stops.set(1, place.getName().toString());
                    try {
                        address = coder.getFromLocationName(stops.get(1), 5);
                        if (address == null) {
                            //return null;
                        }
                        Address location = address.get(0);
                        stopLat[1] = location.getLatitude();
                        stopLong[1] = location.getLongitude();

                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }

                    valid();

                    if (startCity[1] != null && startCity[0] != null && stops.get(1) != null) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                plotRoute();
                            }
                        }).start();
                    }
                }

                @Override
                public void onError(Status status) {
//                    Log.i("MAP", "An error occurred: " + status);
                }
            });
        }
        if (stop_3 != null) {
            stop_3.setOnPlaceSelectedListener(new PlaceSelectionListener() {
                @Override
                public void onPlaceSelected(Place place) {
                    stop_3.getView().findViewById(R.id.place_autocomplete_clear_button).setVisibility(View.VISIBLE);

                    // startCity[0] = place.getName().toString();
                    Geocoder coder = new Geocoder(getActivity().getApplicationContext());
                    List<Address> address;
                    LatLng p1 = null;
                    stop4.setVisibility(View.VISIBLE);
//                    stops[2] = place.getName().toString();
                    stops.set(2, place.getName().toString());
                    try {
                        address = coder.getFromLocationName(stops.get(2), 5);
                        if (address == null) {
                            //return null;
                        }
                        Address location = address.get(0);
                        stopLat[2] = location.getLatitude();
                        stopLong[2] = location.getLongitude();


                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                    valid();
                    if (startCity[1] != null && startCity[0] != null && stops.get(2) != null) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                plotRoute();
                            }
                        }).start();
                    }
                }

                @Override
                public void onError(Status status) {
//                    Log.i("MAP", "An error occurred: " + status);
                }
            });
        }
        if (stop_4 != null) {
            stop_4.setOnPlaceSelectedListener(new PlaceSelectionListener() {
                @Override
                public void onPlaceSelected(Place place) {
                    stop_4.getView().findViewById(R.id.place_autocomplete_clear_button).setVisibility(View.VISIBLE);

                    Geocoder coder = new Geocoder(getActivity().getApplicationContext());
                    List<Address> address;
                    LatLng p1 = null;
                    stop5.setVisibility(View.VISIBLE);
//                    stops[3] = place.getName().toString();
                    stops.set(3, place.getName().toString());
                    try {
                        address = coder.getFromLocationName(stops.get(3), 5);
                        if (address == null) {
                            //return null;
                        }
                        Address location = address.get(0);
                        stopLat[3] = location.getLatitude();
                        stopLong[3] = location.getLongitude();

                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }

                    valid();
                    if (startCity[1] != null && startCity[0] != null && stops.get(3) != null) {
                        if (HomePage.connectionFlag && util.checkConnection(getActivity()))
                            new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    plotRoute();
                                }
                            }).start();
                    }
                }

                @Override
                public void onError(Status status) {
                    // TODO: Handle the error.
//                    Log.i("MAP", "An error occurred: " + status);
                }
            });
        }
        if (stop_5 != null) {

            stop_5.setOnPlaceSelectedListener(new PlaceSelectionListener() {
                @Override
                public void onPlaceSelected(Place place) {
                    stop_5.getView().findViewById(R.id.place_autocomplete_clear_button).setVisibility(View.VISIBLE);

                    Geocoder coder = new Geocoder(getActivity().getApplicationContext());
                    List<Address> address;
                    LatLng p1 = null;
                    //stop2.setVisibility(View.VISIBLE);
//                    stops[4] = place.getName().toString();
                    stops.set(4, place.getName().toString());
                    try {
                        address = coder.getFromLocationName(stops.get(4), 5);
                        if (address == null) {
                            //return null;
                        }
                        Address location = address.get(0);
                        stopLat[4] = location.getLatitude();
                        stopLong[4] = location.getLongitude();


                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }

                    valid();
                    if (startCity[1] != null && startCity[0] != null && stops.get(4) != null) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                plotRoute();
                            }
                        }).start();
                    }
                }

                @Override
                public void onError(Status status) {
//                    Log.i("MAP", "An error occurred: " + status);
                }
            });
        }

        rideDate = (TextView) view.findViewById(R.id.txt_ride_date);
        rideTime = (TextView) view.findViewById(R.id.txt_ride_time);
        rideDate.setText("");
        rideTime.setText("");

        fromDaily = (TextView) view.findViewById(R.id.fromDaily);
        toDaily = (TextView) view.findViewById(R.id.toDaily);
        timeDaily = (TextView) view.findViewById(R.id.timeDaily);
        fromDaily.setText("");
        toDaily.setText("");
        timeDaily.setText("");

        setDailyDates();
        setDailyTime();

        rideDate.setOnTouchListener(new View.OnTouchListener() {
            DatePickerDialog.OnDateSetListener ondate = new DatePickerDialog.OnDateSetListener() {

                public void onDateSet(DatePicker view, int year1, int monthOfYear,
                                      int dayOfMonth) {
                    try {
                        day = dayOfMonth;
                        month = monthOfYear;
                        year = year1;
                        rideDate.setText(String.valueOf(dayOfMonth) + " " + months[monthOfYear]
                                + " " + String.valueOf(year1));
                        dateTxt = String.valueOf(dayOfMonth) + "-" + String.valueOf(monthOfYear + 1)
                                + "-" + String.valueOf(year1);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    valid();
                }
            };

            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    try {
                        //close keyboard
                        InputMethodManager imm = (InputMethodManager) view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                        if (imm != null) {
                            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                        }
                        DatePickerFragment date = new DatePickerFragment();
                        Calendar calender = Calendar.getInstance();
                        Bundle args = new Bundle();
                        int thisDay = day;
                        int thisYear = year;
                        int thisMonth = month;
                        if (thisDay == 0)
                            thisDay = calender.get(Calendar.DAY_OF_MONTH);
                        if (thisYear == 0)
                            thisYear = calender.get(Calendar.YEAR);
                        if (thisMonth == 0)
                            thisMonth = calender.get(Calendar.MONTH);
                        args.putInt("year", thisYear);
                        args.putInt("month", thisMonth);
                        args.putInt("day", thisDay);

                        args.putLong("minDate", calender.getTimeInMillis());
                        calender.add(Calendar.DAY_OF_MONTH, 30);
                        args.putLong("maxDate", calender.getTimeInMillis());
                        date.setArguments(args);

                        date.setCallBack(ondate);
                        date.show(getFragmentManager(), "Date Picker");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                return true;
            }
        });

        rideTime.setOnTouchListener(new View.OnTouchListener() {
            TimePickerDialog.OnTimeSetListener onTimeSet = new TimePickerDialog.OnTimeSetListener() {

                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    hours = hourOfDay;
                    minutes = minute;
                    rideTime.setText(String.format("%02d", hourOfDay) + ":" + String.format("%02d", minute));
                    valid();
                }
            };

            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    //close keyboard
                    InputMethodManager imm = (InputMethodManager) view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) {
                        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                    }

                    try {
                        TimerPickerFragment newFragment = new TimerPickerFragment();
                        Bundle args = new Bundle();
                        args.putInt("hours", hours);
                        args.putInt("minutes", minutes);
                        newFragment.setArguments(args);
                        newFragment.setCallBack(onTimeSet);
                        newFragment.show(getFragmentManager(), "timePicker");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                return true;
            }
        });

        offerRide1.setEnabled(false);
        offerRide1.getBackground().setAlpha(128);
        offerRide1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                connectionProb = false;

                setDaysListToSend();

                Date from = null;
                DateFormat df = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
                String fromDailyText = "", toDailyText = "";
                try {
                    from = new SimpleDateFormat("dd MMM yyyy", Locale.US).parse(fromDaily.getText().toString());
                    fromDailyText = df.format(from);
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                Date to = null;
                try {
                    to = new SimpleDateFormat("dd MMM yyyy", Locale.US).parse(toDaily.getText().toString());
                    toDailyText = df.format(to);
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.US);
                Date d = null;
                try {
                    d = sdf.parse(dateTxt + " " + rideTime.getText().toString() + ":00");
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                Date fDate = null;
                try {
                    fDate = sdf.parse(fromDailyText + " " + timeDaily.getText().toString() + ":00");
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                Date todayDate = new Date();
                Date todayDateTime = null;
                Calendar cal = Calendar.getInstance();
                cal.add(Calendar.HOUR_OF_DAY, 5);

                try {
                    todayDateTime = sdf.parse(sdf.format(cal.getTime()));
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                if (startCity[0].equals(startCity[1])) {
                    TSnackbar snackbar = TSnackbar
                            .make(getView(), "Please select different destination", TSnackbar.LENGTH_LONG);
                    snackbar.setActionTextColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                    textView.setTextColor(Color.WHITE);
                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                    snackbar.show();

                } else if ((fromDailyText == "" || fromDailyText == null) && (llDateTime.getVisibility() == View.GONE)) {
                    TSnackbar snackbar = TSnackbar
                            .make(getView(), "Please select start sate", TSnackbar.LENGTH_LONG);
                    snackbar.setActionTextColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                    textView.setTextColor(Color.WHITE);
                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                    snackbar.show();
                } else if ((toDailyText == "" || toDailyText == null) && (llDateTime.getVisibility() == View.GONE)) {
                    TSnackbar snackbar = TSnackbar
                            .make(getView(), "Please select end date", TSnackbar.LENGTH_LONG);
                    snackbar.setActionTextColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                    textView.setTextColor(Color.WHITE);
                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                    snackbar.show();
                } else if (((fromDailyText != null) && (fDate != null) && (fDate.before(todayDateTime))) && (llDateTime.getVisibility() == View.GONE)) {
                    TSnackbar snackbar = TSnackbar
                            .make(getView(), "Please select future date and time", TSnackbar.LENGTH_LONG);
                    snackbar.setActionTextColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                    textView.setTextColor(Color.WHITE);
                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                    snackbar.show();

                } /*else if (toDailyTxt != null && d != null && d.before(todayDateTime)) {
                        TSnackbar snackbar = TSnackbar
                                .make(getView(), "Please Select Future Date and Time", TSnackbar.LENGTH_LONG);
                        snackbar.setActionTextColor(Color.WHITE);
                        View snackbarView = snackbar.getView();
                        snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                        textView.setTextColor(Color.WHITE);
                        textView.setTypeface(Typeface.DEFAULT_BOLD);
                        snackbar.show();

                    }*/

                    /*else if((fromDailyText != null  && toDailyText != null) && (fromDailyText.equals(toDailyText))  && (llDateTime.getVisibility() == View.GONE)) {
                        TSnackbar snackbar = TSnackbar
                                .make(getView(), "Please Select Different Dates", TSnackbar.LENGTH_LONG);
                        snackbar.setActionTextColor(Color.WHITE);
                        View snackbarView = snackbar.getView();
                        snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                        textView.setTextColor(Color.WHITE);
                        textView.setTypeface(Typeface.DEFAULT_BOLD);
                        snackbar.show();
                    }*/
                else if ((days.size() == 0) && (llDateTime.getVisibility() == View.GONE)) {
                    TSnackbar snackbar = TSnackbar
                            .make(getView(), "Please select atleast one day of a week", TSnackbar.LENGTH_LONG);
                    snackbar.setActionTextColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                    textView.setTextColor(Color.WHITE);
                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                    snackbar.show();
                } else if (dateTxt != null && d != null && d.before(todayDateTime)) {
                    TSnackbar snackbar = TSnackbar
                            .make(getView(), "Please select future date and time", TSnackbar.LENGTH_LONG);
                    snackbar.setActionTextColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                    textView.setTextColor(Color.WHITE);
                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                    snackbar.show();
                } else if (!countrySource.equals(countryDest)) {
                    if (countrySource == "" || countryDest == "") {
                        if (countrySource == "") {
                            sourceProb = true;
                            mapNotLoaded(view);
                        } else if (countryDest == "") {
                            destProb = true;
                            mapNotLoaded(view);
                        }
                    } else {
                        TSnackbar snackbar = TSnackbar
                                .make(getView(), "Your search appears to be outside our coverage area of driving", TSnackbar.LENGTH_LONG);
                        snackbar.setActionTextColor(Color.WHITE);
                        View snackbarView = snackbar.getView();
                        snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                        textView.setTextColor(Color.WHITE);
                        textView.setTypeface(Typeface.DEFAULT_BOLD);
                        snackbar.show();
                    }
                } else {
                    ArrayList<Integer> km = new ArrayList<Integer>(Collections.nCopies(6, 0));
                    ArrayList<Integer> proposedRate = new ArrayList<Integer>(Collections.nCopies(6, 0));
                    offerRideFinal orf = new offerRideFinal();
                    try {
                        for (int i = 0; i < distance.size(); i++) {
                            if (distance.get(i) != null && distance.get(1) != "0") {
                                String array[] = distance.get(i).split(" ");
                                array[0] = array[0].replace(",", "");
//                                km[i] =(int) Float.parseFloat(array[0]);
//                                proposedRate[i] = Integer.parseInt(rate) * km[i];
                                km.set(i, (int) Float.parseFloat(array[0]));
                                proposedRate.set(i, Integer.parseInt(rate) * km.get(i));
//                                Log.e("","parse float rate " + proposedRate.size());
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    int stopsRealSize = 0;
                    for (int i = 0; i < stops.size(); i++) {
                        if (stops.get(i) != "" && stops.get(i) != null) {
                            stopsRealSize++;
                        }
                    }

                    for (int i = 0; i < 2; i++) {
                        switch (i) {
                            case 0:
                                if (latSource[0] == 0.0 || longiSource[0] == 0.0) {

                                    offerRide1.setEnabled(false);
                                    offerRide1.getBackground().setAlpha(128);

                                    if (sourceMarker != null) {
                                        sourceMarker.remove();
                                    }

                                    if (polyline != null) {
                                        polyline.remove();
                                    }
                                    ((EditText) autocompleteFragment.getView().findViewById(R.id.editWorkLocation)).setText("");
                                    startCity[0] = null;

                                    sourceProb = true;
                                    connectionProb = true;
                                }
                                break;
                            case 1:
                                if (latSource[1] == 0.0 || longiSource[1] == 0.0) {
                                    autocompleteFragmentDest.getView().findViewById(R.id.place_autocomplete_clear_button).performClick();
                                    destProb = true;
                                    connectionProb = true;
                                }
                                break;
                        }
                    }

                    for (int i = 0; i < stopsRealSize; i++) {
                        switch (i) {
                            case 0:
                                if ((stopLat[0] == 0.0 || stopLong[0] == 0.0 || distance.get(i) == "" || distance.get(i) == "0") && (stops.get(0) != "")) {
                                    stop_1.getView().findViewById(R.id.place_autocomplete_clear_button).performClick();
                                    connectionProb = true;
                                }
                                break;
                            case 1:
                                if ((stopLat[1] == 0.0 || stopLong[1] == 0.0 || distance.get(i) == "" || distance.get(i) == "0") && (stops.get(1) != "")) {
                                    stop_2.getView().findViewById(R.id.place_autocomplete_clear_button).performClick();
                                    connectionProb = true;
                                }
                                break;
                            case 2:
                                if ((stopLat[2] == 0.0 || stopLong[2] == 0.0 || distance.get(i) == "" || distance.get(i) == "0") && (stops.get(2) != "")) {
                                    stop_3.getView().findViewById(R.id.place_autocomplete_clear_button).performClick();
                                    connectionProb = true;
                                }
                                break;
                            case 3:
                                if ((stopLat[3] == 0.0 || stopLong[3] == 0.0 || distance.get(i) == "" || distance.get(i) == "0") && (stops.get(3) != "")) {
                                    stop_4.getView().findViewById(R.id.place_autocomplete_clear_button).performClick();
                                    connectionProb = true;
                                }
                                break;
                            case 4:
                                if ((stopLat[4] == 0.0 || stopLong[4] == 0.0 || distance.get(i) == "" || distance.get(i) == "0") && (stops.get(4) != "")) {
                                    stop_5.getView().findViewById(R.id.place_autocomplete_clear_button).performClick();
                                    connectionProb = true;
                                }
                                break;
                        }
                    }
                    if (!connectionProb) {
                        PostRideBean postRideBean = new PostRideBean();
                        postRideBean.setDateRide(dateTxt);  //regular
                        postRideBean.setTimeRide(rideTime.getText().toString());    //regular
                        postRideBean.setFromCity(startCity[0]);
                        postRideBean.setToCity(startCity[1]);
                        postRideBean.setFromLat(latSource[0]);
                        postRideBean.setToLat(latSource[1]);
                        postRideBean.setFromLong(longiSource[0]);
                        postRideBean.setToLong(longiSource[1]);
                        postRideBean.setPricePerPerson(proposedRate);
                        postRideBean.setDistance(km);
                        postRideBean.setRideTime(time);
                        postRideBean.setStops(stops);
                        postRideBean.setIsRideDaily(isRideDaily);   //daily
                        postRideBean.setFromDailyDate(fromDailyTxt);  //daily
                        postRideBean.setToDailyDate(toDailyTxt);    //daily
                        postRideBean.setTimeDaily(timeDaily.getText().toString());  //daily
                        postRideBean.setDaysList(days); //daily

                        Bundle args = new Bundle();
                        args.putParcelable("postRideBean", postRideBean);

                        /*try {
                            Log.e("response", "offerride" + new ObjectMapper().writeValueAsString(postRideBean));
                        } catch (JsonProcessingException e) {
                            e.printStackTrace();
                        }*/
                        orf.setArguments(args);

                        Fragment fragment = getFragmentManager().findFragmentById(R.id.frame);//
                        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                        // transaction.add(R.id.frame, orf);
                        transaction.hide(fragment);
                        transaction.add(R.id.frame, orf);
                        transaction.addToBackStack(null);
                        transaction.commit();
                    } else {
                        if (polyline != null) {
                            polyline.remove();
                        }
                        mapNotLoaded(v);//
                    }
                }
            }
        });
        return view;
    }

    private void plotRoute() {

        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                progress = new ProgressDialog(getActivity(), R.style.appThemeDialogue);
                progress.setIndeterminate(true);
                progress.setMessage("Plotting Map..");
                progress.show();
            }
        });

        final Double startCityLat = latSource[0];
        final Double startCityLong = longiSource[0];
        final Double DestCityLat = latSource[1];
        final Double DestCityLong = longiSource[1];
        final Double stop1CityLat = stopLat[0];
        final Double stop1CityLong = stopLong[0];
        final Double stop2CityLat = stopLat[1];
        final Double stop2CityLong = stopLong[1];
        final Double stop3CityLat = stopLat[2];
        final Double stop3CityLong = stopLong[2];
        final Double stop4CityLat = stopLat[3];
        final Double stop4CityLong = stopLong[3];
        final Double stop5CityLat = stopLat[4];
        final Double stop5CityLong = stopLong[4];
        final String stop1CityName = stops.get(0);
        final String stop2CityName = stops.get(1);
        final String stop3CityName = stops.get(2);
        final String stop4CityName = stops.get(3);
        final String stop5CityName = stops.get(4);

        String url = getDirectionsUrlFromCity(startCityLat, startCityLong, DestCityLong, DestCityLat);
        DownloadTask downloadTask = new DownloadTask();

        // Start downloading json data from Google Directions API
        downloadTask.execute(url);

        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // Initializing
                if (sourceMarker != null)
                    sourceMarker.remove();
                if (destMarker != null)
                    destMarker.remove();
                if (stop1Marker != null && stop1CityName == null) {
                    stop1Marker.remove();
                    stop1Marker = null;
                }
                if (stop2Marker != null && stop2CityName == null) {
                    stop2Marker.remove();
                    stop2Marker = null;
                }
                if (stop3Marker != null && stop3CityName == null) {
                    stop3Marker.remove();
                    stop3Marker = null;
                }
                if (stop4Marker != null && stop4CityName == null) {
                    stop4Marker.remove();
                    stop4Marker = null;
                }
                if (stop5Marker != null && stop5CityName == null) {
                    stop5Marker.remove();
                    stop5Marker = null;
                }

                markerPoints = new ArrayList<LatLng>();
                if (map != null) {

                    // Enable MyLocation Button in the Map

                    map.setMyLocationEnabled(false);
                    sourceMarker = map.addMarker(new MarkerOptions()
                                    .position(new LatLng(startCityLat, startCityLong))
                                    .title("Start position")
                            // .icon(BitmapDescriptorFactory.fromBitmap(bmp))
                    );
                    destMarker = map.addMarker(new MarkerOptions()
                            .position(new LatLng(DestCityLat, DestCityLong))
                            .title("Destination"));
//            int i = 1;
                    if (stop1CityLat != 0 && stop1CityLong != 0 && stop1CityName != null && stop1Marker == null) {
//                Log.e(LOG,"marker 1 added");
                        stop1Marker = map.addMarker(new MarkerOptions()
                                .position(new LatLng(stop1CityLat, stop1CityLong))
                                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE))
                                .title("Stop " + "1"));
                    }
                    if (stop2CityLat != 0 && stop2CityLong != 0 && stop2CityName != null && stop2Marker == null) {
                        stop2Marker = map.addMarker(new MarkerOptions()
                                .position(new LatLng(stop2CityLat, stop2CityLong))
                                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE))
                                .title("Stop " + "2"));
                    }
                    if (stop3CityLat != 0 && stop3CityLong != 0 && stop3CityName != null && stop3Marker == null) {
                        stop3Marker = map.addMarker(new MarkerOptions()
                                .position(new LatLng(stop3CityLat, stop3CityLong))
                                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE))
                                .title("Stop " + "3"));
                    }
                    if (stop4CityLat != 0 && stop4CityLong != 0 && stop4CityName != null && stop4Marker == null) {
                        stop4Marker = map.addMarker(new MarkerOptions()
                                .position(new LatLng(stop4CityLat, stop4CityLong))
                                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE))
                                .title("Stop " + "4"));
                    }
                    if (stop5CityLat != 0 && stop5CityLong != 0 && stop5CityName != null && stop5Marker == null) {
                        stop5Marker = map.addMarker(new MarkerOptions()
                                .position(new LatLng(stop5CityLat, stop5CityLong))
                                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE))
                                .title("Stop " + "5"));
                    }
                    if (polyline != null) {
                        polyline.remove();
                    }

                    LatLng source = new LatLng(startCityLat, startCityLong);
                    LatLng dest = new LatLng(DestCityLat, DestCityLong);
                    LatLngBounds.Builder builder = new LatLngBounds.Builder();

                    builder.include(source);
                    builder.include(dest);
//                    int padding = 0;
                    LatLngBounds bounds = builder.build();
                    CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, 250, 250, 5);
                    map.moveCamera(cu);
                    map.animateCamera(cu);
                }
            }
        });
    }

    private void clearDailyData() {
        fromDaily.setText("");
        toDaily.setText("");
        timeDaily.setText("");
        rideDate.setText("");
        rideTime.setText("");
        checkboxSun.setChecked(false);
        checkboxMon.setChecked(false);
        checkboxTue.setChecked(false);
        checkboxWed.setChecked(false);
        checkboxThr.setChecked(false);
        checkboxFri.setChecked(false);
        checkboxSat.setChecked(false);
    }

    private void setDailyDates() {
        fromDaily.setOnTouchListener(new View.OnTouchListener() {
            DatePickerDialog.OnDateSetListener ondate = new DatePickerDialog.OnDateSetListener() {

                public void onDateSet(DatePicker view, int year1, int monthOfYear,
                                      int dayOfMonth) {
                    try {
                        day = dayOfMonth;
                        month = monthOfYear;
                        year = year1;
                        fromDaily.setText(String.valueOf(dayOfMonth) + " " + months[monthOfYear]
                                + " " + String.valueOf(year1));
                        /*fromDailyTxt = String.valueOf(dayOfMonth) + "-" + String.valueOf(monthOfYear + 1)
                                + "-" + String.valueOf(year1);*/

/*
                        calFromDaily = Calendar.getInstance();
                        calFromDaily.set(Calendar.DAY_OF_MONTH, day); // day
                        calFromDaily.set(Calendar.MONTH, month); // month
                        calFromDaily.set(Calendar.YEAR, year); // year*/

                        fromDay = getDayName(year, month, day);

                        setDays();

                        /*if((toDate !=  null || toDate != "")&&(fromDate != null || fromDate != "" )){
                            setDays();
                        }*/

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    valid();
                }
            };

            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    try {
                        //close keyboard
                        InputMethodManager imm = (InputMethodManager) view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                        if (imm != null) {
                            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                        }
                        DatePickerFragment date = new DatePickerFragment();
                        Calendar calendar = Calendar.getInstance();
                        Bundle args = new Bundle();
                        int thisDay = day;
                        int thisYear = year;
                        int thisMonth = month;
                        if (thisDay == 0)
                            thisDay = calendar.get(Calendar.DAY_OF_MONTH);
                        if (thisYear == 0)
                            thisYear = calendar.get(Calendar.YEAR);
                        if (thisMonth == 0)
                            thisMonth = calendar.get(Calendar.MONTH);
                        args.putInt("year", thisYear);
                        args.putInt("month", thisMonth);
                        args.putInt("day", thisDay);

                        args.putLong("minDate", calendar.getTimeInMillis());
                        calendar.add(Calendar.DAY_OF_MONTH, 30);
                        args.putLong("maxDate", calendar.getTimeInMillis());

                        if (!toDaily.getText().toString().matches("")) {
                            Date from = null;
                            try {
                                from = new SimpleDateFormat("dd MMM yyyy", Locale.US).parse(toDaily.getText().toString());
                                Calendar calendar1 = Calendar.getInstance();
                                calendar1.setTime(from);
                                if (calendar1.getTimeInMillis() < calendar.getTimeInMillis()) {
                                    args.putLong("maxDate", calendar1.getTimeInMillis());
                                } else {
                                    args.putLong("maxDate", calendar.getTimeInMillis());
                                }
                            } catch (ParseException e) {
                                e.printStackTrace();
                                calendar.add(Calendar.DAY_OF_MONTH, 30);
                                args.putLong("maxDate", calendar.getTimeInMillis());
                            }
                        } /*else {
                            calendar.add(Calendar.DAY_OF_MONTH, 30);
                            args.putLong("maxDate", calendar.getTimeInMillis());
                        }*/
                        date.setArguments(args);

                        date.setCallBack(ondate);
                        date.show(getFragmentManager(), "Date Picker");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                return true;
            }
        });

        toDaily.setOnTouchListener(new View.OnTouchListener() {
            DatePickerDialog.OnDateSetListener ondate = new DatePickerDialog.OnDateSetListener() {

                public void onDateSet(DatePicker view, int year1, int monthOfYear,
                                      int dayOfMonth) {
                    try {
                        day = dayOfMonth;
                        month = monthOfYear;
                        year = year1;
                        toDaily.setText(String.valueOf(dayOfMonth) + " " + months[monthOfYear]
                                + " " + String.valueOf(year1));
                        toDailyTxt = String.valueOf(dayOfMonth) + "-" + String.valueOf(monthOfYear + 1)
                                + "-" + String.valueOf(year1);

                      /*calToDaily = Calendar.getInstance();
                        calToDaily.set(Calendar.DAY_OF_MONTH, day); // day
                        calToDaily.set(Calendar.MONTH, month); // month
                        calToDaily.set(Calendar.YEAR, year); // year*/

                        toDay = getDayName(year, month, day);

                        setDays();

                        /*if((toDate !=  null || toDate != "")&&(fromDate != null || fromDate != "" )){
                            setDays();
                        }*/

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    valid();
                }
            };

            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    try {
                        //close keyboard
                        InputMethodManager imm = (InputMethodManager) view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                        if (imm != null) {
                            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                        }
                        DatePickerFragment date = new DatePickerFragment();
                        Calendar calendar = Calendar.getInstance();
                        Bundle args = new Bundle();
                        int thisDay = day;
                        int thisYear = year;
                        int thisMonth = month;
                        if (thisDay == 0)
                            thisDay = calendar.get(Calendar.DAY_OF_MONTH);
                        if (thisYear == 0)
                            thisYear = calendar.get(Calendar.YEAR);
                        if (thisMonth == 0)
                            thisMonth = calendar.get(Calendar.MONTH);
                        args.putInt("year", thisYear);
                        args.putInt("month", thisMonth);
                        args.putInt("day", thisDay);

//                        calender.add(Calendar.DAY_OF_MONTH,7);
                        if (!fromDaily.getText().toString().matches("")) {
                            Date from = null;
                            try {
                                from = new SimpleDateFormat("dd MMM yyyy", Locale.US).parse(fromDaily.getText().toString());
                                Calendar calendar1 = Calendar.getInstance();
                                calendar1.setTime(from);
                                calendar1.add(Calendar.DAY_OF_MONTH, 1);
                                args.putLong("minDate", calendar1.getTimeInMillis());
                            } catch (ParseException e) {
                                e.printStackTrace();
                                args.putLong("minDate", calendar.getTimeInMillis());
                            }
                        } else {
                            args.putLong("minDate", calendar.getTimeInMillis());
                        }
//                        args.putLong("minDate", calendar.getTimeInMillis());

                        calendar.add(Calendar.YEAR, 1);
                        args.putLong("maxDate", calendar.getTimeInMillis());
                        date.setArguments(args);

                        date.setCallBack(ondate);
                        date.show(getFragmentManager(), "Date Picker");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                return true;
            }
        });
    }

    private void setDailyTime() {
        timeDaily.setOnTouchListener(new View.OnTouchListener() {
            TimePickerDialog.OnTimeSetListener onTimeSet = new TimePickerDialog.OnTimeSetListener() {

                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    hours = hourOfDay;
                    minutes = minute;
                    timeDaily.setText(String.format("%02d", hourOfDay) + ":" + String.format("%02d", minute));
                    valid();
                }
            };

            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    //close keyboard
                    InputMethodManager imm = (InputMethodManager) view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) {
                        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                    }

                    try {
                        TimerPickerFragment newFragment = new TimerPickerFragment();
                        Bundle args = new Bundle();
                        args.putInt("hours", hours);
                        args.putInt("minutes", minutes);
                        newFragment.setArguments(args);
                        newFragment.setCallBack(onTimeSet);
                        newFragment.show(getFragmentManager(), "timePicker");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                return true;
            }
        });
    }

    private String getDayName(int year, int month, int day) {
        // First convert to Date. This is one of the many ways.
        String dateString = String.format("%d-%d-%d", year, month + 1, day);
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyy-M-d", Locale.US).parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String dayOfWeek = new SimpleDateFormat("EEEE", Locale.US).format(date);

        return dayOfWeek;
    }

    private void setDays() {

        String fromDate = fromDaily.getText().toString();
        String toDate = toDaily.getText().toString();

        Date from = null;
        try {
            from = new SimpleDateFormat("dd MMM yyyy", Locale.US).parse(fromDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        Date to = null;
        try {
            to = new SimpleDateFormat("dd MMM yyyy", Locale.US).parse(toDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        DateFormat df = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
        fromDailyTxt = df.format(from);

        Calendar calObjFrom = Calendar.getInstance();
        calObjFrom.setTime(from);

        Calendar calObjTo = Calendar.getInstance();
        calObjTo.setTime(to);

        int daysBetween = daysBetween(calObjFrom, calObjTo) - 1;

//                Calendar c1 = (Calendar) calFromDaily.clone(), c2 = (Calendar) calToDaily.clone();

        if (daysBetween <= 5) {

            String[] days = new String[]{"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
            ArrayList<String> daysSelected = new ArrayList();

            int fd = 0;
            if (fromDay == null) {
                daysSelected.add(new SimpleDateFormat("EEEE", Locale.US).format(from));
                fd = Arrays.asList(days).indexOf(new SimpleDateFormat("EEEE", Locale.US).format(from));
            } else {
                daysSelected.add(fromDay);
                fd = Arrays.asList(days).indexOf(fromDay);
            }

            daysSelected.add(toDay);

            int td = Arrays.asList(days).indexOf(toDay);

            if (fd > td) {
                for (int z = 0; z < days.length; z++) {
                    if (z > fd) {
                        daysSelected.add(days[z]);
                    }
                }
                for (int z = 0; z < td; z++) {
                    daysSelected.add(days[z]);
                }
            } else {
                for (int i = fd + 1; i < td; i++) {
                    daysSelected.add(days[i]);
                }
            }

            goneAllDays();

            for (int i = 0; i < daysSelected.size(); i++) {
                switch (daysSelected.get(i)) {
                    case "Monday":
                        ttMon.setVisibility(View.VISIBLE);
                        checkboxMon.setVisibility(View.VISIBLE);
                        break;
                    case "Tuesday":
                        ttTue.setVisibility(View.VISIBLE);
                        checkboxTue.setVisibility(View.VISIBLE);
                        break;
                    case "Wednesday":
                        ttWed.setVisibility(View.VISIBLE);
                        checkboxWed.setVisibility(View.VISIBLE);
                        break;
                    case "Thursday":
                        ttThr.setVisibility(View.VISIBLE);
                        checkboxThr.setVisibility(View.VISIBLE);
                        break;
                    case "Friday":
                        ttFri.setVisibility(View.VISIBLE);
                        checkboxFri.setVisibility(View.VISIBLE);
                        break;
                    case "Saturday":
                        ttSat.setVisibility(View.VISIBLE);
                        checkboxSat.setVisibility(View.VISIBLE);
                        break;
                    case "Sunday":
                        ttSun.setVisibility(View.VISIBLE);
                        checkboxSun.setVisibility(View.VISIBLE);
                        break;
                }
            }
        } else {
            visibleAllDays();
        }
//        setDaysList();
    }

    public static int daysBetween(Calendar day1, Calendar day2) {
        Calendar dayOne = (Calendar) day1.clone(),
                dayTwo = (Calendar) day2.clone();

        if (dayOne.get(Calendar.YEAR) == dayTwo.get(Calendar.YEAR)) {
            return Math.abs(dayOne.get(Calendar.DAY_OF_YEAR) - dayTwo.get(Calendar.DAY_OF_YEAR));
        } else {
            if (dayTwo.get(Calendar.YEAR) > dayOne.get(Calendar.YEAR)) {
                //swap them
                Calendar temp = dayOne;
                dayOne = dayTwo;
                dayTwo = temp;
            }
            int extraDays = 0;

            int dayOneOriginalYearDays = dayOne.get(Calendar.DAY_OF_YEAR);

            while (dayOne.get(Calendar.YEAR) > dayTwo.get(Calendar.YEAR)) {
                dayOne.add(Calendar.YEAR, -1);
                // getActualMaximum() important for leap years
                extraDays += dayOne.getActualMaximum(Calendar.DAY_OF_YEAR);
            }
            return extraDays - dayTwo.get(Calendar.DAY_OF_YEAR) + dayOneOriginalYearDays;
        }
    }

    private String getDirectionsUrlFromCity(Double startCityLat, Double startCityLong, Double destiationCityLong, Double destniationCityLat) {

        // Origin of route
//        String str_origin = "origin="+startCity;
        String str_origin = "origin=" + startCityLat + "," + startCityLong;
        // Destination of route
//        String str_dest = "destination="+destniationCity;
        String str_dest = "destination=" + destniationCityLat + "," + destiationCityLong;
        // Sensor enabled
        String sensor = "sensor=true";
        int stopCount = 0;
        String waypoints = "waypoints=";
        for (int i = 0; i < stopLat.length; i++) {
            if (stopLat[i] != 0 && stopLong[i] != 0) {

                if (stopCount > 0) {
                    waypoints = waypoints + "|";
                }
                waypoints = waypoints + stopLat[i] + "," + stopLong[i];
//                Log.e("waypoints","" + waypoints);
                stopCount++;
            }
        }
        // Building the parameters to the web service
        String parameters = str_origin + "&" + str_dest + "&" + waypoints + "&" + sensor;

        // Output format
        String output = "json";

        // Building the url to the web service
        String url = "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters;
        Log.e("url", "" + url);
        return url;
    }

    /*public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }*/

    private String downloadUrl(String strUrl) throws IOException, JSONException {
        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(strUrl);

            // Creating an http connection to communicate with url
            urlConnection = (HttpURLConnection) url.openConnection();

            // Connecting to url
            urlConnection.connect();

            // Reading data from url
            iStream = urlConnection.getInputStream();

            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));

            StringBuffer sb = new StringBuffer();

            String line = "";
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }

            data = sb.toString();

            br.close();

        } catch (Exception e) {
//            Log.d("Exception downloading", e.toString());
        } finally {
            iStream.close();
            urlConnection.disconnect();
        }

        final JSONObject json = new JSONObject(data);
        JSONArray routeArray = json.getJSONArray("routes");
        JSONObject routes = routeArray.getJSONObject(0);

        JSONArray newTempARr = routes.getJSONArray("legs");
        for (int i = 0; i < newTempARr.length(); i++) {
            JSONObject newDisTimeOb = newTempARr.getJSONObject(i);

            JSONObject distOb = newDisTimeOb.getJSONObject("distance");
            JSONObject timeOb = newDisTimeOb.getJSONObject("duration");

//            Log.e("offerride","Distance Objects" + distOb);
//            Log.e("offerride","Time Objects" + timeOb);

//            distance[i] = distOb.getString("text");
//            time[i] = timeOb.getString("text");

            distance.set(i, distOb.getString("text"));
            time.set(i, timeOb.getString("text"));
        }
        return data;
    }

    private String getCompleteAddressString(double LATITUDE, double LONGITUDE) {
        String strAdd = "";
        Geocoder geocoder = new Geocoder(getActivity(), Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(LATITUDE, LONGITUDE, 1);
            if (addresses != null) {
                Address returnedAddress = addresses.get(0);
                StringBuilder strReturnedAddress = new StringBuilder("");

                for (int i = 0; i < returnedAddress.getMaxAddressLineIndex(); i++) {
                    strReturnedAddress.append(returnedAddress.getAddressLine(i)).append("\n");
                }
                strAdd = strReturnedAddress.toString();
            } else {
                //                Log.w("My Current loction address", "No Address returned!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return strAdd;
    }

    private String getCityname(double LATITUDE, double LONGITUDE) {
        String strAdd = "";
        Geocoder gcd = new Geocoder(getActivity(), Locale.getDefault());
        List<Address> addresses = null;
        try {
            addresses = gcd.getFromLocation(LATITUDE, LONGITUDE, 1);
            if (addresses.size() > 0) {
//            return addresses.get(0).getSubLocality();
                return addresses.get(0).getLocality();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

  /*@Override
    public void onDestroyView() {

      *//*Fragment offerRide = getFragmentManager().findFragmentByTag("offerRide");
      getFragmentManager().beginTransaction().detach(offerRide).attach(offerRide).commit();*//*

        if (!nextClicked && !carInfloflag) {
            Intent it = new Intent(getActivity().getApplicationContext(), HomePage.class);
            getActivity().finish();
            startActivity(it);
        }

//        Fragment fragment = (getFragmentManager().findFragmentById(R.id.map));
//        FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
//        ft.remove(fragment);
//        ft.commit();strAdd
//        Fragment fragment = (getFragmentManager().findFragmentById(R.id.place_autocomplete_fragment));
//        FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
//        ft.remove(fragment);
//        ft.commit();
//
//        fragment = (getFragmentManager().findFragmentById(R.id.place_autocomplete_fragment_destination));
//        ft = getActivity().getSupportFragmentManager().beginTransaction();
//        ft.remove(fragment);
//        ft.commit();

        super.onDestroyView();

        *//*if (map != null) {

//            getActivity().getSupportFragmentManager().beginTransaction()
//                    .remove(( this.getChildFragmentManager().findFragmentById(R.id.map)))
//                    .commit();
        }
*//*
//      map = null;
    }*/

    public void valid() {
        String fromCity = startCity[0];
        String toCity = startCity[1];
        String rideDateTxt = dateTxt;
        String fromDate = fromDaily.getText().toString();
        String toDate = toDailyTxt;
        String rideTImeTxt = rideTime.getText().toString();
        String rideDailyTime = timeDaily.getText().toString();
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.US);
        Date d = null;
        try {
            d = sdf.parse(rideDateTxt + " " + rideTImeTxt + ":00");
        } catch (ParseException e) {
            e.printStackTrace();
        }
//        Date todayDate = new Date();
        Date todayDateTime = null;
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.HOUR_OF_DAY, 5);

        try {
            todayDateTime = sdf.parse(sdf.format(cal.getTime()));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        boolean errorFlag = false;

        if (fromCity == null || fromCity.isEmpty())
            errorFlag = true;
        if (toCity == null || toCity.isEmpty())
            errorFlag = true;

        if (llDateTime.getVisibility() == View.GONE) {
            //daily is visible
            if (fromDate == null || fromDate.isEmpty())
                errorFlag = true;
            if (toDate == null || toDate.isEmpty())
                errorFlag = true;
            if (rideDailyTime == null || rideDailyTime.isEmpty())
                errorFlag = true;
        } else {
            if (rideDateTxt == null || rideDateTxt.isEmpty())
                errorFlag = true;
            if (rideTImeTxt == null || rideTImeTxt.isEmpty())
                errorFlag = true;
        }
        if (!errorFlag) {
            offerRide1.setEnabled(true);
            offerRide1.getBackground().setAlpha(255);
        }
    }

    private void mapNotLoaded(View view) {
        ScrollView01.fullScroll(ScrollView.FOCUS_UP);

        TSnackbar snackbar;

        if (sourceProb) {
            sourceProb = false;
            snackbar = TSnackbar
                    .make(view, "Could not fetch Source properly \nPlease check your connection", TSnackbar.LENGTH_LONG);
        } else if (destProb) {
            destProb = false;
            snackbar = TSnackbar
                    .make(view, "Could not fetch Destinaion properly \nPlease check your connection", TSnackbar.LENGTH_LONG);
        } else {
            snackbar = TSnackbar
                    .make(view, "Could not fetch stops correctly \nPlease check your connection", TSnackbar.LENGTH_LONG);
        }

        snackbar.setActionTextColor(Color.WHITE);
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
        textView.setTextColor(Color.WHITE);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        snackbar.show();
    }

    private boolean turnOnLocation(String message) {
        //check location is off? ask to turn on
        int off = 0;
        try {
            off = Settings.Secure.getInt(getActivity().getContentResolver(), Settings.Secure.LOCATION_MODE);
        } catch (Settings.SettingNotFoundException e) {
            e.printStackTrace();
        }
        if (off == 0) {
            AlertDialog.Builder builder1 = new AlertDialog.Builder(getActivity());
            builder1.setMessage(message);
            builder1.setCancelable(true);

            builder1.setPositiveButton(
                    "Settings",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                            Intent onGPS = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                            startActivity(onGPS);
                        }
                    });
            builder1.setNegativeButton(
                    "Cancel",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });

            AlertDialog alert11 = builder1.create();
            alert11.show();
        }
        return true;
    }

    private void goneAllDays() {
        ttMon.setVisibility(View.GONE);
        checkboxMon.setVisibility(View.GONE);
        ttTue.setVisibility(View.GONE);
        checkboxTue.setVisibility(View.GONE);
        ttWed.setVisibility(View.GONE);
        checkboxWed.setVisibility(View.GONE);
        ttThr.setVisibility(View.GONE);
        checkboxThr.setVisibility(View.GONE);
        ttFri.setVisibility(View.GONE);
        checkboxFri.setVisibility(View.GONE);
        ttSat.setVisibility(View.GONE);
        checkboxSat.setVisibility(View.GONE);
        ttSun.setVisibility(View.GONE);
        checkboxSun.setVisibility(View.GONE);
    }

    private void visibleAllDays() {
        ttMon.setVisibility(View.VISIBLE);
        checkboxMon.setVisibility(View.VISIBLE);
        ttTue.setVisibility(View.VISIBLE);
        checkboxTue.setVisibility(View.VISIBLE);
        ttWed.setVisibility(View.VISIBLE);
        checkboxWed.setVisibility(View.VISIBLE);
        ttThr.setVisibility(View.VISIBLE);
        checkboxThr.setVisibility(View.VISIBLE);
        ttFri.setVisibility(View.VISIBLE);
        checkboxFri.setVisibility(View.VISIBLE);
        ttSat.setVisibility(View.VISIBLE);
        checkboxSat.setVisibility(View.VISIBLE);
        ttSun.setVisibility(View.VISIBLE);
        checkboxSun.setVisibility(View.VISIBLE);
    }

    private void setDaysListToSend() {
        if (checkboxSun.getVisibility() == View.VISIBLE && checkboxSun.isChecked()) {
            days.add("sun");
        }

        if (checkboxMon.getVisibility() == View.VISIBLE && checkboxMon.isChecked()) {
            days.add("mon");
        }

        if (checkboxTue.getVisibility() == View.VISIBLE && checkboxTue.isChecked()) {
            days.add("tue");
        }

        if (checkboxWed.getVisibility() == View.VISIBLE && checkboxWed.isChecked()) {
            days.add("wed");
        }

        if (checkboxThr.getVisibility() == View.VISIBLE && checkboxThr.isChecked()) {
            days.add("thu");
        }

        if (checkboxFri.getVisibility() == View.VISIBLE && checkboxFri.isChecked()) {
            days.add("fri");
        }

        if (checkboxSat.getVisibility() == View.VISIBLE && checkboxSat.isChecked()) {
            days.add("sat");
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        textviewTitle = (TextView) getActivity().findViewById(R.id.textviewTitle);
        if (textviewTitle.getVisibility() == View.GONE)
            textviewTitle.setVisibility(View.VISIBLE);
        textviewTitle.setText("Offer Ride");

        header = (ImageView) getActivity().findViewById(R.id.tv_header_title);
        if (header.getVisibility() == View.VISIBLE)
            header.setVisibility(View.GONE);

        shareRide = (ImageView) getActivity().findViewById(R.id.shareRide);
        if (shareRide.getVisibility() == View.VISIBLE)
            shareRide.setVisibility(View.GONE);

        valid();
    }

    private class DownloadTask extends AsyncTask<String, Void, String> {

        // Downloading data in non-ui thread
        @Override
        protected String doInBackground(String... url) {

            // For storing data from web service
            String data = "";

            try {
                // Fetching the data from web service
                data = downloadUrl(url[0]);
            } catch (Exception e) {
//                Log.d("Background Task", e.toString());
            }
            return data;
        }

        // Executes in UI thread, after the execution of
        // doInBackground()
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            ParserTask parserTask = new ParserTask();

            // Invokes the thread for parsing the JSON data
            parserTask.execute(result);
        }
    }

    /**
     * A class to parse the Google Places in JSON format
     */
    private class ParserTask extends AsyncTask<String, Integer,PolylineOptions> {

        // Parsing the data in non-ui thread
        @Override
        protected PolylineOptions doInBackground(String... jsonData) {

            JSONObject jObject;
            List<List<HashMap<String, String>>> routes = null;

            try {
                jObject = new JSONObject(jsonData[0]);
                DirectionsJSONParser parser = new DirectionsJSONParser();

                // Starts parsing data
                routes = parser.parse(jObject);
            } catch (Exception e) {
                e.printStackTrace();
            }

            ArrayList<LatLng> points = null;

            PolylineOptions lineOptions = null;
            MarkerOptions markerOptions = new MarkerOptions();
            try {
                // Traversing through all the routes
                for (int i = 0; i < routes.size(); i++) {
                    points = new ArrayList<LatLng>();
                    lineOptions = new PolylineOptions();

                    // Fetching i-th route
                    List<HashMap<String, String>> path = routes.get(0);

                    // Fetching all the points in i-th route
                    int k = 0;
                    for (int j = 0; j < path.size(); j++) {
                        HashMap<String, String> point = path.get(j);

                        double lat = Double.parseDouble(point.get("lat"));
                        double lng = Double.parseDouble(point.get("lng"));
                        LatLng position = new LatLng(lat, lng);

                        points.add(position);
//                    Geocoder gc = new Geocoder(getActivity());
//                    k = j +1;
//                    if (k % 50 == 0 ) {
//                        List Geocoded = null;
//                        try {
//                            Geocoded = gc.getFromLocation(lat, lng, 1);
//                        } catch (IOException e) {
//                            e.printStackTrace();
//                        }
//
//                        if (Geocoded != null) {
//                            Address address = (Address) Geocoded.get(0);
//                            String city = address.getLocality();
//                            System.out.println("City ::::::  :: : : : : : :  :" + city);
//                            if (!citynames.isEmpty()) {
//                                //if (!citynames.get(citynames.size() - 1).contains(city)) {
//                                    citynames.add(city);
//                                //}
//                            } else {
//                                citynames.add(city);
//                            }
//                        }
//                       // k = k + 100;
                    }
                }
                // Adding all the points in the route to LineOptions
                lineOptions.addAll(points);
                lineOptions.width(2);
                lineOptions.color(Color.BLUE);

            } catch (Exception e) {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if(progress.isShowing() && progress != null){
                            progress.dismiss();
                        }
                    }
                });
                e.printStackTrace();
            }
            return lineOptions;
        }

        // Executes in UI thread, after the parsing process
        @Override
        protected void onPostExecute(PolylineOptions lineOptions) {
                // Drawing polyline in the Google Map for the i-th route

                polyline = map.addPolyline(lineOptions);
                if(progress.isShowing() && progress != null){
                    progress.dismiss();
                }
            }
        }
    }


