package com.samyak.shareacar.Fragments;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.text.Html;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import com.androidadvance.topsnackbar.TSnackbar;
import com.samyak.shareacar.BeforeLogin.Main;
import com.samyak.shareacar.Helpers.ExpandableLayout;
import com.samyak.shareacar.Models.StopageInformation;
import com.samyak.shareacar.Models.UserRideInfoBean;
import com.samyak.shareacar.R;
import com.samyak.shareacar.RetrofitApi.ShareACarApiService;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class rideInfoFragment extends Fragment {

    public static boolean refresh = false;
    private static String finalDate;
    ImageView header;
    ImageView shareRide;
    String LOG = "rideinfoFragment";
    TextView FromCity, ToCity;
    TextView carName, journeyDate, journeyTime, journeyMessage;
    TextView textviewPricePerTraveller;
    LinearLayout dateTimeLayout, pricePerPerson, availableSeats, rideListButton, myRideButton, rideMessage,
            llDynaSeatPrice, stopageLayoutDiv, layout_ride_time_details;
    LinearLayout llStaticSeatPrice, setDyna, llPrice, llText, llTitle, spinnerLayout, llStoppageInfo, rlPrice;
    LinearLayout[] stopageInformationLayouts = new LinearLayout[6];
    TextView textviewTitle, txtRideDate, txtPriceperPerson, txtAvailableseats, txtJourneyMessage, txtDistance, lblPrice, dummy, lblDelete;
    TextView stopageCityNames[] = new TextView[6];
    TextView stopageCityPrice[] = new TextView[6];
    Button stopageDeleteButton[] = new Button[6];
    Button editRide, deleteRide, callRideOwner, emailRideOwner;
    int stopageCityUpdatedRates[] = new int[6];
    RelativeLayout rlPrice1, rlPrice2, rlPrice3, rlPrice4, rlPrice5, rlPrice6;
    LinearLayout.LayoutParams loparams;
    int hours = 0;
    int minutes = 0;
    int day = 0;
    int month = 0;
    int year = 0;
    List<StopageInformation> stopageInformationBeanArrayList;
    String months[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    String dateTxt, rideId;
    Call<ResponseBody> call;
    String result;
    UserRideInfoBean rideBean;
    ExpandableLayout expandableLayout;
    View view;
    SimpleDateFormat sdf;
    String time[] = null;
    String dateTime[] = null;
    String filePath;
    private ImageView imageviewMinusPrice1, imageviewPlusPrice1;
    private ImageView imageviewMinusPrice2, imageviewPlusPrice2;
    private ImageView imageviewMinusPrice3, imageviewPlusPrice3;
    private ImageView imageviewMinusPrice4, imageviewPlusPrice4;
    private ImageView imageviewMinusPrice5, imageviewPlusPrice5;
    private ImageView imageviewMinusPrice6, imageviewPlusPrice6;
    private ImageView imageviewPlusPrice, imageviewMinusPrice;
    private TextView textviewPrice, textViewPriceTitle, textviewCityNameTitle, textviewNoofSeats;
    private ImageView imageviewPlus, imageviewMinus;
    private ImageView calander;
    private ProgressDialog progress;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_ride_info, container, false);

        Log.e("Ride Info ", " Called");

        Bundle args = getArguments();
        rideBean = args.getParcelable("rideBean");

        rideId = rideBean.getRideId();
        shareRide = (ImageView) getActivity().findViewById(R.id.shareRide);
        FromCity = (TextView) view.findViewById(R.id.FromCity);
        ToCity = (TextView) view.findViewById(R.id.ToCity);
        dateTimeLayout = (LinearLayout) view.findViewById(R.id.layout_date_time);
        pricePerPerson = (LinearLayout) view.findViewById(R.id.layout_price_per_person);
        availableSeats = (LinearLayout) view.findViewById(R.id.layout_available_seats);
        llStaticSeatPrice = (LinearLayout) view.findViewById(R.id.llStaticSeatPrice);
        llTitle = (LinearLayout) view.findViewById(R.id.llTitle);
        llDynaSeatPrice = (LinearLayout) view.findViewById(R.id.llDynaSeatPrice);
        llStoppageInfo = (LinearLayout) view.findViewById(R.id.llStoppageInfo);
        setDyna = (LinearLayout) view.findViewById(R.id.setDyna);
        llPrice = (LinearLayout) view.findViewById(R.id.layout_ride_price_details);
        layout_ride_time_details = (LinearLayout) view.findViewById(R.id.layout_ride_time_details);
        llText = (LinearLayout) view.findViewById(R.id.llText);
        carName = (TextView) view.findViewById(R.id.car_name);
        journeyDate = (TextView) view.findViewById(R.id.input_ride_date);
        journeyTime = (TextView) view.findViewById(R.id.input_ride_time);
        lblPrice = (TextView) view.findViewById(R.id.lbl_price);
        textviewTitle = (TextView) view.findViewById(R.id.textviewTitle);
        txtRideDate = (TextView) view.findViewById(R.id.lbl_ride_date_time);
        textviewPricePerTraveller = (TextView) view.findViewById(R.id.textviewPricePerTraveller);
        txtPriceperPerson = (TextView) view.findViewById(R.id.lbl_price_per_person);
        txtAvailableseats = (TextView) view.findViewById(R.id.lbl_available_seats);
        deleteRide = (Button) view.findViewById(R.id.btn_delete_ride);
        rideListButton = (LinearLayout) view.findViewById(R.id.layout_button);
        myRideButton = (LinearLayout) view.findViewById(R.id.layout_view_ride_button);
        rideMessage = (LinearLayout) view.findViewById(R.id.layout_ride_message);
        journeyMessage = (TextView) view.findViewById(R.id.lbl_ride_message);
        txtJourneyMessage = (TextView) view.findViewById(R.id.txt_message);
        txtDistance = (TextView) view.findViewById(R.id.lbl_distance);
        callRideOwner = (Button) view.findViewById(R.id.btn_call_ride_owner);
        emailRideOwner = (Button) view.findViewById(R.id.btn_email_ride_owner);
        stopageLayoutDiv = (LinearLayout) view.findViewById(R.id.layout_stopage_information);
        lblDelete = (TextView) view.findViewById(R.id.lbl_delete);
        stopageInformationLayouts[0] = (LinearLayout) view.findViewById(R.id.layout_stopage_info_1);
        stopageInformationLayouts[1] = (LinearLayout) view.findViewById(R.id.layout_stopage_info_2);
        stopageInformationLayouts[2] = (LinearLayout) view.findViewById(R.id.layout_stopage_info_3);
        stopageInformationLayouts[3] = (LinearLayout) view.findViewById(R.id.layout_stopage_info_4);
        stopageInformationLayouts[4] = (LinearLayout) view.findViewById(R.id.layout_stopage_info_5);
        stopageInformationLayouts[5] = (LinearLayout) view.findViewById(R.id.layout_stopage_info_6);
        rlPrice1 = (RelativeLayout) view.findViewById(R.id.rlPrice1);
        rlPrice2 = (RelativeLayout) view.findViewById(R.id.rlPrice2);
        rlPrice3 = (RelativeLayout) view.findViewById(R.id.rlPrice3);
        rlPrice4 = (RelativeLayout) view.findViewById(R.id.rlPrice4);
        rlPrice5 = (RelativeLayout) view.findViewById(R.id.rlPrice5);
        rlPrice6 = (RelativeLayout) view.findViewById(R.id.rlPrice6);
        stopageCityNames[0] = (TextView) view.findViewById(R.id.input_stopage_1);
        stopageCityNames[1] = (TextView) view.findViewById(R.id.input_stopage_2);
        stopageCityNames[2] = (TextView) view.findViewById(R.id.input_stopage_3);
        stopageCityNames[3] = (TextView) view.findViewById(R.id.input_stopage_4);
        stopageCityNames[4] = (TextView) view.findViewById(R.id.input_stopage_5);
        stopageCityNames[5] = (TextView) view.findViewById(R.id.input_stopage_6);
        stopageCityPrice[0] = (TextView) view.findViewById(R.id.input_price_stopage_1);
        stopageCityPrice[1] = (TextView) view.findViewById(R.id.input_price_stopage_2);
        stopageCityPrice[2] = (TextView) view.findViewById(R.id.input_price_stopage_3);
        stopageCityPrice[3] = (TextView) view.findViewById(R.id.input_price_stopage_4);
        stopageCityPrice[4] = (TextView) view.findViewById(R.id.input_price_stopage_5);
        stopageCityPrice[5] = (TextView) view.findViewById(R.id.input_price_stopage_6);
        dummy = (TextView) view.findViewById(R.id.dummy);
        stopageDeleteButton[0] = (Button) view.findViewById(R.id.btn_delete_stop_1);
        stopageDeleteButton[1] = (Button) view.findViewById(R.id.btn_delete_stop_2);
        stopageDeleteButton[2] = (Button) view.findViewById(R.id.btn_delete_stop_3);
        stopageDeleteButton[3] = (Button) view.findViewById(R.id.btn_delete_stop_4);
        stopageDeleteButton[4] = (Button) view.findViewById(R.id.btn_delete_stop_5);
        stopageDeleteButton[5] = (Button) view.findViewById(R.id.btn_delete_stop_6);
        spinnerLayout = (LinearLayout) view.findViewById(R.id.spinnerLayout);

        calander = (ImageView) view.findViewById(R.id.calander);

        imageviewPlus = (ImageView) view.findViewById(R.id.imageviewPlus);
        imageviewMinus = (ImageView) view.findViewById(R.id.imageviewMinus);
        textviewNoofSeats = (TextView) view.findViewById(R.id.textviewNoofSeats);

        rlPrice = (LinearLayout) view.findViewById(R.id.rlPrice);

        imageviewPlusPrice = (ImageView) view.findViewById(R.id.imageviewPlusPrice);
        imageviewMinusPrice = (ImageView) view.findViewById(R.id.imageviewMinusPrice);
        textviewPrice = (TextView) view.findViewById(R.id.textviewPrice);
        textViewPriceTitle = (TextView) view.findViewById(R.id.textViewPriceTitle);
        textviewCityNameTitle = (TextView) view.findViewById(R.id.textviewCityNameTitle);

        imageviewPlusPrice1 = (ImageView) view.findViewById(R.id.imageviewPlusPrice1);
        imageviewPlusPrice2 = (ImageView) view.findViewById(R.id.imageviewPlusPrice2);
        imageviewPlusPrice3 = (ImageView) view.findViewById(R.id.imageviewPlusPrice3);
        imageviewPlusPrice4 = (ImageView) view.findViewById(R.id.imageviewPlusPrice4);
        imageviewPlusPrice5 = (ImageView) view.findViewById(R.id.imageviewPlusPrice5);
        imageviewPlusPrice6 = (ImageView) view.findViewById(R.id.imageviewPlusPrice6);

        imageviewMinusPrice1 = (ImageView) view.findViewById(R.id.imageviewMinusPrice1);
        imageviewMinusPrice2 = (ImageView) view.findViewById(R.id.imageviewMinusPrice2);
        imageviewMinusPrice3 = (ImageView) view.findViewById(R.id.imageviewMinusPrice3);
        imageviewMinusPrice4 = (ImageView) view.findViewById(R.id.imageviewMinusPrice4);
        imageviewMinusPrice5 = (ImageView) view.findViewById(R.id.imageviewMinusPrice5);
        imageviewMinusPrice6 = (ImageView) view.findViewById(R.id.imageviewMinusPrice6);

        expandableLayout = (ExpandableLayout) view.findViewById(R.id.expandablelayout);

        view.findViewById(R.id.expandMe).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        expandableLayout.toggleExpansion();
                    }
                });

        int carId, userId = 0;
        String contactNo = null;
        String emailId = null;
        String userName = null;

        SQLiteDatabase mydatabase = getActivity().openOrCreateDatabase("shareACar", getActivity().MODE_PRIVATE, null);
        mydatabase.execSQL("CREATE TABLE IF NOT EXISTS loginInfo(userId INTEGER ,carId INTEGER , contactNo TEXT , emailId TEXT, userName TEXT);");
        Cursor c = mydatabase.rawQuery("Select * from loginInfo", null);
        if (c != null) {
            if (c.moveToFirst()) {
                do {
                    userId = c.getInt(c.getColumnIndex("userId"));
                    carId = c.getInt(c.getColumnIndex("carId"));
                    contactNo = c.getString(c.getColumnIndex("contactNo"));
                    emailId = c.getString(c.getColumnIndex("emailId"));
                    userName = c.getString(c.getColumnIndex("userName"));
                } while (c.moveToNext());
            }
        } else {
            Intent intent = new Intent(getActivity(), Main.class);
            startActivity(intent);
        }
        if (userId == 0) {
            Intent intent = new Intent(getActivity(), Main.class);
            startActivity(intent);
        }
        final String finalContactNo = contactNo;
        final String finalEmailId = emailId;
        final String finalUserName = userName;
        editRide = (Button) view.findViewById(R.id.btn_edit_ride);

        if (rideBean.getStatus() == 1) {    //if approved
            disappearButtons();
            textviewTitle.setText("Active");
            layout_ride_time_details.setVisibility(View.GONE);
            calander.setVisibility(View.GONE);
            rlPrice.setVisibility(View.GONE);
            journeyDate.setVisibility(View.GONE);
            journeyTime.setVisibility(View.GONE);
            availableSeats.setVisibility(View.GONE);

            llPrice.setOrientation(LinearLayout.HORIZONTAL);
            loparams = (LinearLayout.LayoutParams) textviewPricePerTraveller.getLayoutParams();
            loparams.weight = 1;
            textviewPricePerTraveller.setLayoutParams(loparams);
            loparams = (LinearLayout.LayoutParams) rlPrice.getLayoutParams();
            loparams.weight = 1;
//            Bundle args = getArguments();
//            rideBean = (RideData) args.getSerializable("rideBean");

            if (shareRide.getVisibility() == View.GONE)
                shareRide.setVisibility(View.VISIBLE);

            txtPriceperPerson.setLayoutParams(loparams);

//            txtJourneyMessage.setVisibility(View.GONE);
            llText.setVisibility(View.GONE);
            lblPrice.setVisibility(View.GONE);
        } else if (rideBean.getIsDeleted() != 1 && !rideBean.getRideViewType().equalsIgnoreCase("rideList") && !rideBean.getIsExpired()) {
            llTitle.setBackgroundColor(getResources().getColor(R.color.yellow));
            textviewTitle.setText("Pending for Approval");
            dateTimeLayout.setVisibility(View.GONE);
            rideMessage.setVisibility(View.GONE);
            llStaticSeatPrice.setVisibility(View.GONE);
            dateTimeLayout.removeAllViews();
            pricePerPerson.removeAllViews();
            availableSeats.removeAllViews();
            rideMessage.removeAllViews();

            if (shareRide.getVisibility() == View.VISIBLE)
                shareRide.setVisibility(View.GONE);

            textviewCityNameTitle.setGravity(Gravity.CENTER);
            for (int i = 0; i < 6; i++) {
                stopageCityNames[i].setGravity(Gravity.CENTER);
            }

            /*for(int i = 0; i < 6; i++) {
                LinearLayout.LayoutParams loparams = (LinearLayout.LayoutParams) stopageCityNames[i].getLayoutParams();
                loparams.gravity = Gravity.FILL;
                stopageCityNames[i].setLayoutParams(loparams);
            }*/
        }
        if (rideBean.getIsDeleted() == 1) {
            llTitle.setBackgroundColor(Color.RED);
            textviewTitle.setText("Deleted");
            setDyna.setVisibility(View.GONE);
//            journeyPricePerPerson.setVisibility(View.GONE);
            layout_ride_time_details.setVisibility(View.GONE);
            llDynaSeatPrice.setVisibility(View.GONE);
            disappearButtons();
            calander.setVisibility(View.GONE);
            rlPrice.setVisibility(View.GONE);
            journeyDate.setVisibility(View.GONE);
            journeyTime.setVisibility(View.GONE);
            spinnerLayout.setVisibility(View.GONE);

            if (shareRide.getVisibility() == View.VISIBLE) {
                shareRide.setVisibility(View.GONE);
            }
//            txtJourneyMessage.setVisibility(View.GONE);
            llText.setVisibility(View.GONE);
            dateTimeLayout.setVisibility(View.VISIBLE);
            availableSeats.setVisibility(View.VISIBLE);
            pricePerPerson.setVisibility(View.VISIBLE);
            lblPrice.setVisibility(View.GONE);

            view.findViewById(R.id.lbl_no_available_seats_1).setVisibility(View.GONE);
            editRide.setVisibility(View.GONE);

            //show single button in center
            LinearLayout.LayoutParams loparams = (LinearLayout.LayoutParams) dummy.getLayoutParams();
            loparams.weight = 0;
            dummy.setLayoutParams(loparams);

            deleteRide.setText("Put Back");
        }
        if (rideBean.getIsExpired()) {
            llText.setVisibility(View.GONE);
            llTitle.setBackgroundColor(Color.RED);
            textviewTitle.setText("Expired");
            layout_ride_time_details.setVisibility(View.GONE);
            llDynaSeatPrice.setVisibility(View.GONE);
            calander.setVisibility(View.GONE);
            setDyna.setVisibility(View.GONE);
//            journeyPricePerPerson.setVisibility(View.GONE);
            rlPrice.setVisibility(View.GONE);
            journeyDate.setVisibility(View.GONE);
            journeyTime.setVisibility(View.GONE);
            txtJourneyMessage.setVisibility(View.GONE);
            lblPrice.setVisibility(View.GONE);
            spinnerLayout.setVisibility(View.GONE);

            if (shareRide.getVisibility() == View.VISIBLE)
                shareRide.setVisibility(View.GONE);
//            materialBetterSpinner.setVisibility(View.GONE);
            dateTimeLayout.setVisibility(View.VISIBLE);
            availableSeats.setVisibility(View.VISIBLE);
            pricePerPerson.setVisibility(View.VISIBLE);

            view.findViewById(R.id.lbl_no_available_seats_1).setVisibility(View.GONE);
            disappearButtons();     //disappeare plus and minus buttons
            //deleteRide.setText("Put Back");
//            editRide.setEnabled(false);
            editRide.setVisibility(View.GONE);
            deleteRide.setVisibility(View.GONE);//changed
        }
        if (rideBean.getRideViewType().equalsIgnoreCase("findride")) {
            disappearButtons();
            llTitle.setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.green));
            textviewTitle.setText("Have your seat booked");
            llStoppageInfo.setVisibility(View.GONE);
            setDyna.setVisibility(View.GONE);
            calander.setVisibility(View.GONE);
            rideListButton.setVisibility(View.GONE);
//            journeyPricePerPerson.setVisibility(View.GONE);
            rlPrice.setVisibility(View.GONE);
            journeyDate.setVisibility(View.GONE);
            journeyTime.setVisibility(View.GONE);
            spinnerLayout.setVisibility(View.GONE);

            if (shareRide.getVisibility() == View.GONE)
                shareRide.setVisibility(View.VISIBLE);
//            txtJourneyMessage.setVisibility(View.GONE);
            llText.setVisibility(View.GONE);
            dateTimeLayout.setVisibility(View.VISIBLE);
            availableSeats.setVisibility(View.VISIBLE);
            pricePerPerson.setVisibility(View.VISIBLE);
            view.findViewById(R.id.lbl_no_available_seats_1).setVisibility(View.GONE);
        } else {
            myRideButton.setVisibility(View.GONE);
            stopageLayoutDiv.setVisibility(View.GONE);
        }

        stopageInformationBeanArrayList = rideBean.getStopageInformation();

        if (Integer.parseInt(rideBean.getNoOfStops()) == 0) {
            llStoppageInfo.setVisibility(View.GONE);
        }

        if (Integer.parseInt(rideBean.getNoOfStops()) > 0 && !rideBean.getRideViewType().equalsIgnoreCase("findride")
                ) {
            stopageLayoutDiv.setVisibility(View.VISIBLE);

            for (int i = 0; i <= Integer.parseInt(rideBean.getNoOfStops()); i++) {

                stopageInformationLayouts[i].setVisibility(View.VISIBLE);
                stopageCityNames[i].setText(stopageInformationBeanArrayList.get(i).getStopageFromPlaceName() + " - " +
                        stopageInformationBeanArrayList.get(i).getStopageToPlaceName());
                stopageCityPrice[i].setText("\u20B9" + stopageInformationBeanArrayList.get(i).getPricePerPerson());
//                        String.format("%.0f", Float.parseFloat(stopageInformationBeanArrayList.get(i).getPriocePerPerson())));
                final int finalI = i;
                stopageDeleteButton[i].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        progress = new ProgressDialog(getActivity(), R.style.appThemeDialogue);
                        progress.setMessage("Please Wait...");
                        progress.show();
                        deleteStopage(stopageInformationBeanArrayList.get(finalI).getStopageId());
                    }
                });
                if (rideBean.getStatus() == 1 || rideBean.getIsDeleted() == 1 || rideBean.getIsExpired()) {
//                    System.out.println("In if condition");
                    stopageCityPrice[i].setEnabled(false);
                    stopageDeleteButton[i].setVisibility(View.GONE);
                    lblDelete.setVisibility(View.GONE);

                    loparams = (LinearLayout.LayoutParams) textviewCityNameTitle.getLayoutParams();
                    loparams.weight = 2f;
                    loparams = (LinearLayout.LayoutParams) stopageCityNames[0].getLayoutParams();
                    loparams.weight = 2f;
                    loparams = (LinearLayout.LayoutParams) stopageCityNames[1].getLayoutParams();
                    loparams.weight = 2f;
                    loparams = (LinearLayout.LayoutParams) stopageCityNames[2].getLayoutParams();
                    loparams.weight = 2f;
                    loparams = (LinearLayout.LayoutParams) stopageCityNames[3].getLayoutParams();
                    loparams.weight = 2f;
                    loparams = (LinearLayout.LayoutParams) stopageCityNames[4].getLayoutParams();
                    loparams.weight = 2f;
                    loparams = (LinearLayout.LayoutParams) stopageCityNames[5].getLayoutParams();
                    loparams.weight = 2f;

                    loparams = (LinearLayout.LayoutParams) textViewPriceTitle.getLayoutParams();
                    loparams.weight = 1f;
                    loparams = (LinearLayout.LayoutParams) rlPrice1.getLayoutParams();
                    loparams.weight = 1f;
                    loparams = (LinearLayout.LayoutParams) rlPrice2.getLayoutParams();
                    loparams.weight = 1f;
                    loparams = (LinearLayout.LayoutParams) rlPrice3.getLayoutParams();
                    loparams.weight = 1f;
                    loparams = (LinearLayout.LayoutParams) rlPrice4.getLayoutParams();
                    loparams.weight = 1f;
                    loparams = (LinearLayout.LayoutParams) rlPrice5.getLayoutParams();
                    loparams.weight = 1f;
                    loparams = (LinearLayout.LayoutParams) rlPrice6.getLayoutParams();
                    loparams.weight = 1f;
                }
            }

            for (int i = Integer.parseInt(rideBean.getNoOfStops()) + 1; i < 6; i++) {
                stopageInformationLayouts[i].setVisibility(View.GONE);
            }
        } else if (Integer.parseInt(rideBean.getNoOfStops()) == 0 || rideBean.getRideViewType().equalsIgnoreCase("rideList")) {
            stopageLayoutDiv.setVisibility(View.GONE);
        }

        txtDistance.setText(rideBean.getDistance() + " km");
//        txtDistance.setText(String.format("%.0f", Float.parseFloat(rideBean.getDistance())) + " km");
        journeyMessage.setText(rideBean.getRideMessage());
        txtJourneyMessage.setText(rideBean.getRideMessage());
        carName.setText(rideBean.getCarName());

        FromCity.setText(rideBean.getFromCity());
        ToCity.setText(rideBean.getToCity());


//        journeyPricePerPerson.setText("\u20B9" + String.format("%.0f",Float.parseFloat(rideBean.getPriceOfPerson())));
        textviewPrice.setText("\u20B9" + rideBean.getPricePerPerson());
//        textviewPrice.setText("\u20B9" + String.format("%.0f", Float.parseFloat(rideBean.getPriceOfPerson())));

        String dateTime[] = rideBean.getDatetimeOfDeparture().split(" ");
        String date[] = dateTime[0].split("-");
        finalDate = date[2] + " " + months[Integer.parseInt(date[1]) - 1] + " " + date[0];
        time = dateTime[1].split(":");

        sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.US);

        hours = Integer.parseInt(time[0]);
        minutes = Integer.parseInt(time[1]);
        day = Integer.parseInt(date[2]);
        month = Integer.parseInt(date[1]) - 1;
        year = Integer.parseInt(date[0]);

        dateTxt = date[2] + "-" + date[1] + "-" + date[0];

        journeyDate.setText(finalDate); //
        journeyTime.setText(time[0] + ":" + time[1]);   //
        txtRideDate.setText(finalDate + " - " + time[0] + ":" + time[1]);   //


        txtPriceperPerson.setText("\u20B9" + rideBean.getPricePerPerson() + "/Seat");
//        txtPriceperPerson.setText("\u20B9" + String.format("%.0f", Float.parseFloat(rideBean.getPriceOfPerson())));

        txtAvailableseats.setText(Integer.toString(rideBean.getNoOfSeatsAvailable()));
//        materialBetterSpinner.setSelection(Arrays.asList(SPINNER_DATA).indexOf(Integer.toString(rideBean.getNoOfSeatsAvailable())));

        textviewNoofSeats.setText(Integer.toString(rideBean.getNoOfSeatsAvailable()));

        if (Integer.parseInt(textviewNoofSeats.getText().toString()) <= 1) {
            imageviewMinus.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinus.setEnabled(false);
        }

        if (Integer.parseInt(textviewNoofSeats.getText().toString()) > 1) {
            imageviewMinus.setImageResource(R.drawable.ic_minus);
            imageviewMinus.setEnabled(true);
        }

        imageviewPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = Integer.parseInt(textviewNoofSeats.getText().toString());
                textviewNoofSeats.setText("" + (i + 1));

                updateRates();

                if (Integer.parseInt(textviewNoofSeats.getText().toString()) > 1) {
                    imageviewMinus.setImageResource(R.drawable.ic_minus);
                    imageviewMinus.setEnabled(true);
                }

                if (Integer.parseInt(textviewNoofSeats.getText().toString()) >= 8) {
                    imageviewPlus.setImageResource(R.drawable.ic_plus_disable);
                    imageviewPlus.setEnabled(false);
                }
            }
        });

        imageviewMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = Integer.parseInt(textviewNoofSeats.getText().toString());
                textviewNoofSeats.setText("" + (i - 1));

                updateRates();

                if (Integer.parseInt(textviewNoofSeats.getText().toString()) < 8) {
                    imageviewPlus.setImageResource(R.drawable.ic_plus);
                    imageviewPlus.setEnabled(true);
                }

                if (Integer.parseInt(textviewNoofSeats.getText().toString()) <= 1) {
                    imageviewMinus.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinus.setEnabled(false);
                }
            }
        });

        //total price per co-traveller

        if (Integer.parseInt(textviewPrice.getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice.setEnabled(true);
        }

        if (Integer.parseInt(textviewPrice.getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice.setEnabled(false);
        }

        imageviewPlusPrice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*int i = Integer.parseInt(textviewPrice.getText().toString().replace("\u20B9", ""));
                int j = i / 10;
                int rounded = j * 10;
                textviewPrice.setText("\u20B9" + (rounded + 10));*/
                increaseStopagePrice(textviewPrice);
                updateRates();

                if (Integer.parseInt(textviewPrice.getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*int i = Integer.parseInt(textviewPrice.getText().toString().replace("\u20B9", ""));
                int j = i / 10;
                int rounded = j * 10;
                if(i % 10 == 0) {
                    textviewPrice.setText("\u20B9" + (rounded - 10));
                } else {
                    textviewPrice.setText("\u20B9" + (rounded));
                }*/
                decreaseStopagePrice(textviewPrice);

                updateRates();

                if (Integer.parseInt(textviewPrice.getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice.setEnabled(false);
                }
            }
        });

        setPrices();

        journeyTime.setOnFocusChangeListener(new View.OnFocusChangeListener() {

            TimePickerDialog.OnTimeSetListener onTimeSet = new TimePickerDialog.OnTimeSetListener() {

                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    hours = hourOfDay;
                    minutes = minute;
                    journeyTime.setText(String.format("%02d", hourOfDay)
                            + ":" + String.format("%02d", minute));
                    valid();
                }
            };

            @Override
            public void onFocusChange(View v, boolean e) {
                if (e) {
                    TimerPickerFragment newFragment = new TimerPickerFragment();
                    Bundle args = new Bundle();
                    args.putInt("hours", hours);
                    args.putInt("minutes", minutes);
                    newFragment.setArguments(args);
                    newFragment.setCallBack(onTimeSet);
                    newFragment.show(getFragmentManager(), "timePicker");
                }
            }

        });

        journeyTime.setOnClickListener(new View.OnClickListener() {
            TimePickerDialog.OnTimeSetListener onTimeSet = new TimePickerDialog.OnTimeSetListener() {

                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    hours = hourOfDay;
                    minutes = minute;
                    journeyTime.setText(String.format("%02d", hourOfDay) + ":"
                            + String.format("%02d", minute));
                    valid();
                }
            };

            @Override
            public void onClick(View v) {
                TimerPickerFragment newFragment = new TimerPickerFragment();
                Bundle args = new Bundle();
                args.putInt("hours", hours);
                args.putInt("minutes", minutes);
                newFragment.setArguments(args);
                newFragment.setCallBack(onTimeSet);
                newFragment.show(getFragmentManager(), "timePicker");

            }
        });

        journeyDate.setOnClickListener(new View.OnClickListener() {

            DatePickerDialog.OnDateSetListener ondate = new DatePickerDialog.OnDateSetListener() {

                public void onDateSet(DatePicker view, int year1, int monthOfYear,
                                      int dayOfMonth) {
                    day = dayOfMonth;
                    month = monthOfYear;
                    year = year1;
//                    journeyDate.setText(String.valueOf(dayOfMonth) + "-" + String.valueOf(monthOfYear + 1)
//                            + "-" + String.valueOf(year1));
                    journeyDate.setText(String.valueOf(dayOfMonth) + " " + months[monthOfYear]
                            + " " + String.valueOf(year1));
                    dateTxt = String.valueOf(dayOfMonth) + "-" + String.valueOf(monthOfYear + 1)
                            + "-" + String.valueOf(year1);
                    valid();
                }
            };

            @Override
            public void onClick(View v) {

                DatePickerFragment date = new DatePickerFragment();
                Calendar calender = Calendar.getInstance();
                Bundle args = new Bundle();
                int thisDay = day;
                int thisYear = year;
                int thisMonth = month;
                if (thisDay == 0)
                    thisDay = calender.get(Calendar.DAY_OF_MONTH);
                if (thisYear == 0)
                    thisYear = calender.get(Calendar.YEAR);
                if (thisMonth == 0)
                    thisMonth = calender.get(Calendar.MONTH);
                args.putInt("year", thisYear);
                args.putInt("month", thisMonth);
                args.putInt("day", thisDay);
                args.putLong("minDate", calender.getTimeInMillis());
                calender.add(Calendar.DAY_OF_MONTH, 30);
                args.putLong("maxDate", calender.getTimeInMillis());
                date.setArguments(args);

                date.setCallBack(ondate);
                date.show(getFragmentManager(), "Date Picker");

                updateRates();
            }
        });

        journeyDate.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            DatePickerDialog.OnDateSetListener ondate = new DatePickerDialog.OnDateSetListener() {

                public void onDateSet(DatePicker view, int year1, int monthOfYear,
                                      int dayOfMonth) {
                    day = dayOfMonth;
                    month = monthOfYear;
                    year = year1;
//                    journeyDate.setText(String.valueOf(dayOfMonth) + "-" + String.valueOf(monthOfYear + 1)
//                            + "-" + String.valueOf(year1));
                    journeyDate.setText(String.valueOf(dayOfMonth) + " " + months[monthOfYear - 1]
                            + " " + String.valueOf(year1));
                    dateTxt = String.valueOf(dayOfMonth) + "-" + String.valueOf(monthOfYear + 1)
                            + "-" + String.valueOf(year1);
                    valid();
                }
            };

            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    DatePickerFragment date = new DatePickerFragment();
                    Calendar calender = Calendar.getInstance();
                    Bundle args = new Bundle();
                    int thisDay = day;
                    int thisYear = year;
                    int thisMonth = month;
                    if (thisDay == 0)
                        thisDay = calender.get(Calendar.DAY_OF_MONTH);
                    if (thisYear == 0)
                        thisYear = calender.get(Calendar.YEAR);
                    if (thisMonth == 0)
                        thisMonth = calender.get(Calendar.MONTH);
                    args.putInt("year", thisYear);
                    args.putInt("month", thisMonth);
                    args.putInt("day", thisDay);

                    args.putLong("minDate", calender.getTimeInMillis());
                    calender.add(Calendar.DAY_OF_MONTH, 30);
                    args.putLong("maxDate", calender.getTimeInMillis());
                    date.setArguments(args);

                    date.setCallBack(ondate);
                    date.show(getFragmentManager(), "Date Picker");
                }
            }
        });

        editRide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //close keyboard
                InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }

                refresh = true;

                progress = new ProgressDialog(getActivity(), R.style.appThemeDialogue);
                progress.setMessage("Please Wait...");
                progress.setCancelable(false);
                progress.show();
                updateRates();
                String dateTxt1 = dateTxt;
                String timeTxt = journeyTime.getText().toString();
//                        String[] parts = journeyPricePerPerson.getText().toString().split("\u20B9");
                String[] parts = textviewPrice.getText().toString().split("\u20B9");
                String pricePerPersonTxt = parts[1].trim();
//                        Log.e(LOG,"pricePerPersonTxt" + pricePerPersonTxt);
//                        String noOfPersonAvailable = materialBetterSpinner.getSelectedItem().toString();
                String noOfPersonAvailable = textviewNoofSeats.getText().toString();
                String rideMessage = txtJourneyMessage.getText().toString().trim();
                String joinedString = Arrays.toString(stopageCityUpdatedRates).trim();
//                Log.e(LOG,"joinedString" + joinedString);
//                        String joinedString = Arrays.toString(stopageCityFinalRates);
                if (lblDelete.getVisibility() == View.VISIBLE) {
                    if (valid()) {
                        updateCall(dateTxt1, timeTxt, pricePerPersonTxt, noOfPersonAvailable, rideMessage, joinedString);
                    }
                } else {
                    updateCall(dateTxt1, timeTxt, pricePerPersonTxt, noOfPersonAvailable, rideMessage, joinedString);
                }

            }

        });

        deleteRide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //close keyboard
                InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }
                refresh = true;
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("Alert!");
                //builder.setIcon(R.drawable.icon);
                if (rideBean.getIsExpired()) {
                    builder.setMessage("Do you want to remove this ride from list?");
                } else if (rideBean.getIsDeleted() == 1) {
                    builder.setMessage("Do you want to put back this ride?");
                } else {
                    builder.setMessage("Do you want to delete this ride?");
                }

                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();

                        call = new ShareACarApiService(getActivity()).getShareACarApi().deleteRide(rideId);
                        call.enqueue(new Callback<ResponseBody>() {
                            @Override
                            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                                if (response.code() == 200) {

                                    try {
                                        result = response.body().string();

                                        if(getView() != null) {
                                            rideDeleted(view);
                                        }

                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }

                                } else {
                                    TSnackbar snackbar = TSnackbar
                                            .make(getView(), "Can't connect to server", TSnackbar.LENGTH_LONG);
                                    snackbar.setActionTextColor(Color.WHITE);
                                    View snackbarView = snackbar.getView();
                                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                                    textView.setTextColor(Color.WHITE);
                                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                                    snackbar.show();

                                }

                            }

                            @Override
                            public void onFailure(Call<ResponseBody> call, Throwable t) {
                                TSnackbar snackbar = TSnackbar
                                        .make(getView(), "Please check your connection", TSnackbar.LENGTH_LONG);
                                snackbar.setActionTextColor(Color.WHITE);
                                View snackbarView = snackbar.getView();
                                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                                textView.setTextColor(Color.WHITE);
                                textView.setTypeface(Typeface.DEFAULT_BOLD);
                                snackbar.show();
                            }
                        });

                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                builder.create().show();
            }
        });

        callRideOwner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                String phoneNo = rideBean.getMobileNo();
                callIntent.setData(Uri.parse("tel:" + phoneNo));
                startActivity(callIntent);
            }
        });

        emailRideOwner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + rideBean.getEmailId()));

                intent.putExtra(Intent.EXTRA_SUBJECT, "Want to share ride with you.");
                String mailBody = "Dear " + rideBean.getUserName() + ",<br><br>";
                mailBody = mailBody + "I found your details on Share Ur Car Application.I want to be on your ride, from " + rideBean.getFromCity() + " to " + rideBean.getToCity()
                        + " on " + finalDate + " " + time[0] + ":" + time[1] + ".";
                mailBody = mailBody + "<br><br>";
                mailBody = mailBody + "My contact details are as following : <br>";
                mailBody = mailBody + "Contact No : <a href='tel:" + finalContactNo + "'>" + finalContactNo + "</a><br>";
                mailBody = mailBody + "Email Id: <a href='mailto:" + finalEmailId + "'>" + finalEmailId + "</a><br><br>";
                mailBody = mailBody + "Thank You, <br>" + finalUserName + "";
                intent.putExtra(Intent.EXTRA_TEXT, Html.fromHtml(mailBody));
                startActivity(Intent.createChooser(intent, "Send email..."));
            }
        });

        shareRide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                makeFileToShare();

//                ApplicationInfo app = getActivity().getApplicationContext().getApplicationInfo();
//                filePath = getActivity().getExternalFilesDir(null).getPath() + File.separator + "ridedetails.txt";

                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
                try {
                    sendIntent.putExtra(Intent.EXTRA_TEXT, "Hey Check out this ShareUrCar ride from " + rideBean.getFromCity() + " to " + rideBean.getToCity()
                            + " for ₹ " + rideBean.getPricePerPerson() + ". Leaving on " + new SimpleDateFormat("EEE dd MMM yyyy", Locale.US).format(sdf1.parse(rideBean.getDatetimeOfDeparture()))
                            + " at " + time[0] + ":" + time[1]
                            + ".\nShared from the ShareUrCar Android App - get it here: \n https://play.google.com/store/apps/details?id=com.samyak.shareurcar&hl=en");

                } catch (ParseException e) {
                    e.printStackTrace();
                }
//                sendIntent.setType("*/*");
                sendIntent.setType("text/plain");

                PackageManager pm = getActivity().getPackageManager();
                List<ResolveInfo> resInfo = pm.queryIntentActivities(sendIntent, 0);

                for (int i = 0; i < resInfo.size(); i++) {
                    ResolveInfo ri = resInfo.get(i);
                    String packageName = ri.activityInfo.packageName;

                    if (packageName.contains("android.email") || packageName.contains("android.gm")) {
                        sendIntent.putExtra(Intent.EXTRA_SUBJECT, "Check out this ShareUrCar ride from " + rideBean.getFromCity() + " to " + rideBean.getToCity());
                    } else if (packageName.contains("xender")) {
//                        sendIntent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new File(filePath)));
                    }
                }

                getActivity().startActivity(sendIntent);
            }
        });
        return view;
    }

    /*private void makeFileToShare(){
        //make a file
        try {
            dateTime = rideBean.getDatetimeOfDeparture().split(" ");
            time = dateTime[1].split(":");
            //Whatever the file path is.
            File statText = new File(getActivity().getExternalFilesDir(null).getPath() + File.separator + "ridedetails.txt");
            FileOutputStream is = new FileOutputStream(statText);
            OutputStreamWriter osw = new OutputStreamWriter(is);
            Writer w = new BufferedWriter(osw);
            SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
            w.write("Hey Check out this ShareUrCar ride from " + rideBean.getFromCity() + " to "+ rideBean.getToCity()
                    + " for ₹ " + rideBean.getPricePerPerson() + ". Leaving on " + new SimpleDateFormat("EEE dd MMM yyyy", Locale.US).format(sdf1.parse(rideBean.getDatetimeOfDeparture()))
                    + " at " + time[0] + ":" + time[1]
                    + ".\nShared from the ShareUrCar Android App - get it here: \n https://play.google.com/store/apps/details?id=com.samyak.shareurcar&hl=en");
            w.close();
        } catch (IOException e) {
//            System.err.println("Problem writing to the file ridedetails.txt");
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }*/

    private void rideDeleted(final View view) {
        String output[] = result.split("::");
        if (output.length > 1) {
            if (output[0].equalsIgnoreCase("Success")) {

                if (rideBean.getIsDeleted() == 1 && !rideBean.getIsExpired()) {
                        TSnackbar snackbar = TSnackbar
                                .make(getView(), "Ride is put back successfully", TSnackbar.LENGTH_SHORT);
                        snackbar.setActionTextColor(Color.WHITE);
                        View snackbarView = snackbar.getView();
                        snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                        textView.setTextColor(Color.WHITE);
                        textView.setTypeface(Typeface.DEFAULT_BOLD);
                        snackbar.show();
                } else if (rideBean.getIsExpired()) {
                    TSnackbar snackbar = TSnackbar
                            .make(getView(), "Ride is removed successfully", TSnackbar.LENGTH_SHORT);
                    snackbar.setActionTextColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                    textView.setTextColor(Color.WHITE);
                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                    snackbar.show();

                } else {
                    TSnackbar snackbar = TSnackbar
                            .make(getView(), output[1], TSnackbar.LENGTH_SHORT);
                    snackbar.setActionTextColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                    textView.setTextColor(Color.WHITE);
                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                    snackbar.show();
                }

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {

                            Thread.sleep(2000);
                            // Do some stuff
                            FragmentTransaction ft = getFragmentManager().beginTransaction();
//                            ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
                            ft.replace(R.id.frame, new myRidesFragment());
                            ft.addToBackStack(null);
                            ft.commit();

                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    }
                }).start();

            } else {
                TSnackbar snackbar = TSnackbar
                        .make(getView(), output[1], TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.WHITE);
                textView.setTypeface(Typeface.DEFAULT_BOLD);
                snackbar.show();
            }
        } else {
            TSnackbar snackbar = TSnackbar
                    .make(getView(), "Please check your connection", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();
        }
    }

    public boolean valid() {

        boolean valid = true;
        String dateTxt1 = dateTxt;
        String timeTxt = journeyTime.getText().toString();
        String messageTxt = txtJourneyMessage.getText().toString();
//        String pricePerPersonTxt = textviewPrice.getText().toString();
        boolean dateFlag = true;

        Date d = null;
        try {
            d = sdf.parse(dateTxt1 + " " + timeTxt + ":00");
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Date todayDate = new Date();
        Date todayDateTime = null;
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.HOUR_OF_DAY, 5);

        try {
            todayDateTime = sdf.parse(sdf.format(cal.getTime()));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        if (dateFlag) {
            if (todayDateTime != null && d != null && d.before(todayDateTime)) {
                if ((progress != null) && progress.isShowing()) {
                    progress.dismiss();
                }
                TSnackbar snackbar = TSnackbar
                        .make(getView(), "Please select future date and time", TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.WHITE);
                textView.setTypeface(Typeface.DEFAULT_BOLD);
                snackbar.show();

                valid = false;
            }
        }

        if (dateTxt1 != null && dateTxt1.isEmpty()) {
            if ((progress != null) && progress.isShowing()) {
                progress.dismiss();
            }
            TSnackbar snackbar = TSnackbar
                    .make(getView(), "Please select date", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
            dateFlag = false;
        }
        if (timeTxt.isEmpty()) {
            if ((progress != null) && progress.isShowing()) {
                progress.dismiss();
            }
            TSnackbar snackbar = TSnackbar
                    .make(getView(), "Please select time", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
            dateFlag = false;
        }
        /*if (pricePerPersonTxt.isEmpty()) {
            journeyPricePerPerson.setError("enter valid price");
            valid = false;
        } else {
            journeyPricePerPerson.setError(null);
        }*/

        if (messageTxt.isEmpty()) {
            if ((progress != null) && progress.isShowing()) {
                progress.dismiss();
            }
            TSnackbar snackbar = TSnackbar
                    .make(getView(), "Please enter message", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
        }

        /*for(int i = 0 ; i < stopageCityPrice.length ; i++) {
            System.out.println("stopageInformationLayouts[i].getVisibility() :: " + stopageInformationLayouts[i].getVisibility() + " ::: " + View.VISIBLE);
            if (stopageInformationLayouts[i].getVisibility() == View.VISIBLE && stopageLayoutDiv.getVisibility() == View.VISIBLE)  {
                if (stopageCityPrice[i].getText().toString().isEmpty() || stopageCityPrice[i].getText().toString().equals("")) {
                    stopageCityPrice[i].setError("enter valid price");
                    valid = false;
                    System.out.println("VALIFDDDDD :::::  " + i + " ::: "  + valid);
                } else {
                    stopageCityPrice[i].setError(null);
                    String[] parts = stopageCityPrice[i].getText().toString().split("\u20B9");
                    Log.e(LOG,"part 2 " + parts[1]);
                    stopageCityFinalRates[i] = Float.parseFloat(parts[1]);
                }
            }
        }*/
        return valid;
    }

    public void deleteStopage(String stopageId) {

        updateRates();

        call = new ShareACarApiService(getActivity()).getShareACarApi().deleteStopage(stopageId);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if ((progress != null) && progress.isShowing()) {
                    progress.dismiss();
                }
                try {
                    if (response.code() == 200) {
                        result = response.body().string();
                        ResDeleteStopage();
                    } else {
                        TSnackbar snackbar = TSnackbar
                                .make(getView(), "Can't connect to server", TSnackbar.LENGTH_LONG);
                        snackbar.setActionTextColor(Color.WHITE);
                        View snackbarView = snackbar.getView();
                        snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                        textView.setTextColor(Color.WHITE);
                        textView.setTypeface(Typeface.DEFAULT_BOLD);
                        snackbar.show();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                if ((progress != null) && progress.isShowing()) {
                    progress.dismiss();
                }
                TSnackbar snackbar = TSnackbar
                        .make(getView(), "Please check your connection", TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.WHITE);
                textView.setTypeface(Typeface.DEFAULT_BOLD);
                snackbar.show();
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        myRidesFragment.loadFlag = false;
        rideListFragment.loadFlag = false;
    }

    private void ResDeleteStopage() {
        updateRates();
        String[] output = result.split("::");
        if (output.length > 1) {
            if (output[0].equalsIgnoreCase("Success")) {

                TSnackbar snackbar = TSnackbar
                        .make(getView(), output[1], TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.WHITE);
                textView.setTypeface(Typeface.DEFAULT_BOLD);
                snackbar.show();

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {

                            Thread.sleep(2000);
                            // Do some stuff
                            FragmentTransaction ft = getFragmentManager().beginTransaction();
//                            ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
                            ft.replace(R.id.frame, new myRidesFragment());
                            ft.addToBackStack(null);
                            ft.commit();


                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    }
                }).start();

            } else {
                TSnackbar snackbar = TSnackbar
                        .make(getView(), output[1], TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.WHITE);
                textView.setTypeface(Typeface.DEFAULT_BOLD);
                snackbar.show();
            }
        }
    }

    private void setPrices() {

        //no 1
        if (Integer.parseInt(stopageCityPrice[0].getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice1.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice1.setEnabled(true);
        }

        if (Integer.parseInt(stopageCityPrice[0].getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice1.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice1.setEnabled(false);
        }

        imageviewPlusPrice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*int i = Integer.parseInt(stopageCityPrice[0].getText().toString().replace("\u20B9", ""));
                int j = i / 10;
                int rounded = j * 10;
                stopageCityPrice[0].setText("\u20B9" + (rounded + 10));*/

                increaseStopagePrice(stopageCityPrice[0]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[0].getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice1.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice1.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* int i = Integer.parseInt(stopageCityPrice[0].getText().toString().replace("\u20B9", ""));
                int j = i / 10;
                int rounded = j * 10;
                stopageCityPrice[0].setText("\u20B9" + (rounded - 10));*/

                decreaseStopagePrice(stopageCityPrice[0]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[0].getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice1.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice1.setEnabled(false);
                }
            }
        });

        //no 2
        if (Integer.parseInt(stopageCityPrice[1].getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice2.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice2.setEnabled(true);
        }

        if (Integer.parseInt(stopageCityPrice[1].getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice2.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice2.setEnabled(false);
        }

        imageviewPlusPrice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                increaseStopagePrice(stopageCityPrice[1]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[1].getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice2.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice2.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                decreaseStopagePrice(stopageCityPrice[1]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[1].getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice2.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice2.setEnabled(false);
                }
            }
        });

        //no 3
        if (Integer.parseInt(stopageCityPrice[2].getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice3.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice3.setEnabled(true);
        }

        if (Integer.parseInt(stopageCityPrice[2].getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice3.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice3.setEnabled(false);
        }

        imageviewPlusPrice3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                increaseStopagePrice(stopageCityPrice[2]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[2].getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice3.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice3.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                decreaseStopagePrice(stopageCityPrice[2]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[2].getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice3.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice3.setEnabled(false);
                }
            }
        });

        //no 4
        if (Integer.parseInt(stopageCityPrice[3].getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice4.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice4.setEnabled(true);
        }

        if (Integer.parseInt(stopageCityPrice[3].getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice4.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice4.setEnabled(false);
        }

        imageviewPlusPrice4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                increaseStopagePrice(stopageCityPrice[3]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[3].getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice4.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice4.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                decreaseStopagePrice(stopageCityPrice[3]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[3].getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice4.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice4.setEnabled(false);
                }
            }
        });

        //no 1
        if (Integer.parseInt(stopageCityPrice[4].getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice5.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice5.setEnabled(true);
        }

        if (Integer.parseInt(stopageCityPrice[4].getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice5.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice5.setEnabled(false);
        }

        imageviewPlusPrice5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                increaseStopagePrice(stopageCityPrice[4]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[4].getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice5.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice5.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                decreaseStopagePrice(stopageCityPrice[4]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[4].getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice5.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice5.setEnabled(false);
                }
            }
        });

        //no 6
        if (Integer.parseInt(stopageCityPrice[5].getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice6.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice6.setEnabled(true);
        }

        if (Integer.parseInt(stopageCityPrice[5].getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice6.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice6.setEnabled(false);
        }

        imageviewPlusPrice6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                increaseStopagePrice(stopageCityPrice[5]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[5].getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice6.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice6.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                decreaseStopagePrice(stopageCityPrice[5]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[5].getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice6.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice6.setEnabled(false);
                }
            }
        });
    }

    private void updateRates() {

        /*int total = Integer.parseInt(stopageCityPrice[0].getText().toString().replace("\u20B9","")) +
                Integer.parseInt(stopageCityPrice[1].getText().toString().replace("\u20B9","")) +
                Integer.parseInt(stopageCityPrice[2].getText().toString().replace("\u20B9","")) +
                Integer.parseInt(stopageCityPrice[3].getText().toString().replace("\u20B9","")) +
                Integer.parseInt(stopageCityPrice[4].getText().toString().replace("\u20B9","")) +
                Integer.parseInt(stopageCityPrice[5].getText().toString().replace("\u20B9",""));*/

        stopageCityUpdatedRates[0] = Integer.parseInt(stopageCityPrice[0].getText().toString().replace("\u20B9", "").trim());
        stopageCityUpdatedRates[1] = Integer.parseInt(stopageCityPrice[1].getText().toString().replace("\u20B9", "").trim());
        stopageCityUpdatedRates[2] = Integer.parseInt(stopageCityPrice[2].getText().toString().replace("\u20B9", "").trim());
        stopageCityUpdatedRates[3] = Integer.parseInt(stopageCityPrice[3].getText().toString().replace("\u20B9", "").trim());
        stopageCityUpdatedRates[4] = Integer.parseInt(stopageCityPrice[4].getText().toString().replace("\u20B9", "").trim());
        stopageCityUpdatedRates[5] = Integer.parseInt(stopageCityPrice[5].getText().toString().replace("\u20B9", "").trim());

       /* Log.e(LOG,"stopageCityUpdatedRates0" + stopageCityUpdatedRates[0]);
        Log.e(LOG,"stopageCityUpdatedRates1" + stopageCityUpdatedRates[1]);
        Log.e(LOG,"stopageCityUpdatedRates2" + stopageCityUpdatedRates[2]);
        Log.e(LOG,"stopageCityUpdatedRates3" + stopageCityUpdatedRates[3]);
        Log.e(LOG,"stopageCityUpdatedRates4" + stopageCityUpdatedRates[4]);
        Log.e(LOG,"stopageCityUpdatedRates5" + stopageCityUpdatedRates[5]);*/

//        pricePerPerson.setText("\u20B9" + total);
    }

    private void updateCall(String dateTxt1, String timeTxt, String pricePerPersonTxt, String noOfPersonAvailable, String rideMessage, String joinedString) {

        call = new ShareACarApiService(getActivity()).getShareACarApi().updateRide(rideId, dateTxt1, timeTxt, pricePerPersonTxt, noOfPersonAvailable, rideMessage, joinedString);
        /*Log.e("update detailes","" + rideId);
        Log.e("update detailes","" + dateTxt1);
        Log.e("update detailes","" + timeTxt);
        Log.e("update detailes","" + pricePerPersonTxt);
        Log.e("update detailes","" + noOfPersonAvailable);
        Log.e("update detailes","" + rideMessage);
        Log.e("update detailes","" + joinedString);*/
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if ((progress != null) && progress.isShowing()) {
                    progress.dismiss();
                }

                if (response.code() == 200) {
                    try {
                        result = response.body().string();
//                    Log.e(LOG, "result " + result);
                        String output[] = result.split("::");
                        if (output.length > 1) {
                            if (output[0].equalsIgnoreCase("Success")) {

                                TSnackbar snackbar = TSnackbar
                                        .make(getView(), "Ride is updated successfully", TSnackbar.LENGTH_SHORT);
                                snackbar.setActionTextColor(Color.WHITE);
                                View snackbarView = snackbar.getView();
                                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                                textView.setTextColor(Color.WHITE);
                                textView.setTypeface(Typeface.DEFAULT_BOLD);
                                snackbar.show();


                                new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {

                                            Thread.sleep(2000);
                                            // Do some stuff
                                            FragmentTransaction ft = getFragmentManager().beginTransaction();
//                                            ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
                                            ft.replace(R.id.frame, new myRidesFragment());
                                            ft.addToBackStack(null);
                                            ft.commit();


                                        } catch (Exception e) {
                                            e.getLocalizedMessage();
                                        }
                                    }
                                }).start();

                            } else {
                                TSnackbar snackbar = TSnackbar
                                        .make(getView(), output[1], TSnackbar.LENGTH_LONG);
                                snackbar.setActionTextColor(Color.WHITE);
                                View snackbarView = snackbar.getView();
                                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                                textView.setTextColor(Color.WHITE);
                                textView.setTypeface(Typeface.DEFAULT_BOLD);
                                snackbar.show();

                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
//                        Log.e(LOG, "result ++ e.printStackTrace() ");
                    }
                } else {
                    TSnackbar snackbar = TSnackbar
                            .make(getView(), "Can't connect to server", TSnackbar.LENGTH_LONG);
                    snackbar.setActionTextColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                    textView.setTextColor(Color.WHITE);
                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                    snackbar.show();

                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                if ((progress != null) && progress.isShowing()) {
                    progress.dismiss();
                }
                TSnackbar snackbar = TSnackbar
                        .make(getView(), "Please check your connection", TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.WHITE);
                textView.setTypeface(Typeface.DEFAULT_BOLD);
                snackbar.show();
            }
        });
    }

    private void disappearButtons() {
        imageviewPlusPrice1.setVisibility(View.GONE);
        imageviewPlusPrice2.setVisibility(View.GONE);
        imageviewPlusPrice3.setVisibility(View.GONE);
        imageviewPlusPrice4.setVisibility(View.GONE);
        imageviewPlusPrice5.setVisibility(View.GONE);
        imageviewPlusPrice6.setVisibility(View.GONE);

        imageviewMinusPrice1.setVisibility(View.GONE);
        imageviewMinusPrice2.setVisibility(View.GONE);
        imageviewMinusPrice3.setVisibility(View.GONE);
        imageviewMinusPrice4.setVisibility(View.GONE);
        imageviewMinusPrice5.setVisibility(View.GONE);
        imageviewMinusPrice6.setVisibility(View.GONE);
    }

    private void increaseStopagePrice(TextView t) {
        int i = Integer.parseInt(t.getText().toString().replace("\u20B9", ""));
        if (i % 5 == 0) {
            t.setText("\u20B9" + (i + 5));
        } else {
            if (i < 10) {
                int j = i % 5;
                int k = 5 - j;
                t.setText("\u20B9" + (i + k));
            } else {
                float j = i / 5;
                int rounded = (int) ((j / 2) * 10);
                t.setText("\u20B9" + (rounded + 5));
            }
        }
    }

    private void decreaseStopagePrice(TextView t) {
        int i = Integer.parseInt(t.getText().toString().replace("\u20B9", ""));
        if (i % 5 == 0) {
            t.setText("\u20B9" + (i - 5));
        } else {
            if (i < 10) {
                int j = i % 5;
                t.setText("\u20B9" + (i - j));
            } else {
                float j = i / 5;
                int rounded = (int) ((j / 2) * 10);
                t.setText("\u20B9" + (rounded));
            }
        }
    }

    //for snackbar
   /* private static ViewGroup findSuitableParent(View view) {
        ViewGroup fallback = null;

        do {
            if(view instanceof CoordinatorLayout) {
                return (ViewGroup)view;
            }

            *//*if(view instanceof FrameLayout) {
                // android.R.id.content
                if(view.getId() == 16908290) {
                    return (ViewGroup)view;
                }

                fallback = (ViewGroup)view;
            }*//*

            if(view != null) {
                ViewParent parent = view.getParent();
                view = parent instanceof View?(View)parent:null;
            }
        } while(view != null);

        return fallback;
    }*/


    @Override
    public void onResume() {
        textviewTitle = (TextView) getActivity().findViewById(R.id.textviewTitle);

        Bundle args1 = getArguments();
        rideBean = args1.getParcelable("rideBean");

       /* shareRide = (ImageView) getActivity().findViewById(R.id.shareRide);
        if (rideBean.getStatus() == 1 || rideBean.getRideViewType().equalsIgnoreCase("rideList")) {    //if approved

            if (shareRide.getVisibility() == View.GONE)
                shareRide.setVisibility(View.VISIBLE);
        }*/

        if (textviewTitle.getVisibility() == View.GONE)
            textviewTitle.setVisibility(View.VISIBLE);
        textviewTitle.setText("Ride Information");

        header = (ImageView) getActivity().findViewById(R.id.tv_header_title);
        if (header.getVisibility() == View.VISIBLE)
            header.setVisibility(View.GONE);

        super.onResume();
    }
}