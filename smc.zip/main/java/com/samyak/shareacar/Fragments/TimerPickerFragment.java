package com.samyak.shareacar.Fragments;

import android.app.Dialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.text.format.DateFormat;
import android.widget.TimePicker;

import java.util.Calendar;

public class TimerPickerFragment extends DialogFragment {

    TimePickerDialog.OnTimeSetListener onTimeSet;

    TimePickerDialog td;
    PickTime mCallback;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the current time as the default values for the picker
        final Calendar c = Calendar.getInstance();
        int hours = c.get(Calendar.HOUR_OF_DAY), minutes = c.get(Calendar.MINUTE);
        Bundle args = getArguments();
        if (args.containsKey("hours") && args.containsKey("minutes")) {
            if (args.getInt("hours") != -1)
                hours = args.getInt("hours");
            if (args.getInt("minutes") != -1)
                minutes = args.getInt("minutes");
        }

        int hour = hours;
        int minute = minutes;

        // Create a new instance of TimePickerDialog and return it
        //td = new TimePickerDialog(getActivity(),  onTimeSet, hour, minute,
        //      DateFormat.is24HourFormat(getActivity()));

        return new TimePickerDialog(getActivity(), onTimeSet, hour, minute,
                DateFormat.is24HourFormat(getActivity()));
    }

    public void setCallBack(TimePickerDialog.OnTimeSetListener ondate) {
        onTimeSet = ondate;
    }

    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        // Do something with the time chosen by the user

        if (mCallback != null) {
            StringBuilder sb = new StringBuilder();
            sb.append(hourOfDay);
            sb.append(":");
            sb.append(minute);
            mCallback.returnTime(sb.toString());
        }
    }

    public interface PickTime {
        void returnTime(String value);
    }
}
