package com.samyak.shareacar.Fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.androidadvance.topsnackbar.TSnackbar;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.samyak.shareacar.BeforeLogin.Main;
import com.samyak.shareacar.Models.CarInfoBean;
import com.samyak.shareacar.Models.PostRideBean;
import com.samyak.shareacar.R;
import com.samyak.shareacar.RetrofitApi.ShareACarApiService;

import java.util.Arrays;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class carInfoFragment extends Fragment {
    String[] CAR_TYPE = {"[--Car Type--]", "Hatch Back", "Sedan", "SUV"};
    String[] CAR_FUEL_TYPE = {"[--Fuel Type--]", "Petrol", "Diesel", "CNG", "LPG"};
    TextView carName = null;
    TextView carCompany = null;
    TextView carYear = null;
    String resultUpdateCarInfo = "";
    Call<ResponseBody> call;
    Call<CarInfoBean> call1;
    Button Submit = null;
    Spinner carType, carFueType;


    int userId = 0;

    SQLiteDatabase mydatabase;
    String from = null;
    TextView textviewTitle;
    ImageView header, shareRide;
    View view;
    PostRideBean postRideBean;
    private boolean isRideDaily = false;
    private ProgressDialog progress;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_car_info, container, false);
        String db[] = getActivity().databaseList();

        if (!offerRideFinal.carInfoNotAdded) {
            progress = new ProgressDialog(getActivity(), R.style.appThemeDialogue);
            progress.setMessage("Please Wait...");
            progress.show();
        }

        Bundle bundle = this.getArguments();

        if (bundle != null && bundle.containsKey("from")) {
            from = bundle.getString("from");
            postRideBean = bundle.getParcelable("postRideBean");
        }

        mydatabase = getActivity().openOrCreateDatabase(db[0], Context.MODE_PRIVATE, null);
        mydatabase.execSQL("CREATE TABLE IF NOT EXISTS loginInfo(userId INTEGER ,carId INTEGER , contactNo TEXT , emailId TEXT, userName TEXT);");
        Cursor c = mydatabase.rawQuery("Select * from loginInfo", null);
        carName = (TextView) view.findViewById(R.id.input_car_name);
        carCompany = (TextView) view.findViewById(R.id.input_car_company);
        carYear = (TextView) view.findViewById(R.id.input_car_year);

        Submit = (Button) view.findViewById(R.id.btn_car_info);

        carType = (Spinner) view.findViewById(R.id.sel_car_type);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_dropdown_item_1line, CAR_TYPE);

        carType.setAdapter(adapter);
        carFueType = (Spinner) view.findViewById(R.id.sel_car_fuel);

        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_dropdown_item_1line, CAR_FUEL_TYPE);

        carFueType.setAdapter(adapter1);

        if (c != null) {
            if (c.moveToFirst()) {
                do {
                    userId = c.getInt(c.getColumnIndex("userId"));
                    if (!offerRideFinal.carInfoNotAdded) {
                        call1 = new ShareACarApiService(getActivity()).getShareACarApi().getCarInfo(userId + "");
                        call1.enqueue(new Callback<CarInfoBean>() {
                            @Override
                            public void onResponse(Call<CarInfoBean> call, Response<CarInfoBean> response) {
                                if ((progress != null) && progress.isShowing()) {
                                    progress.dismiss();
                                }
                                try {
                                    if (response.code() == 200) {

                                        CarInfoBean carInfo = response.body();
                                        carName.setText(carInfo.getCarName());
                                        carCompany.setText(carInfo.getCarCompany());
                                        carYear.setText(carInfo.getCarYear());
                                        carType.setSelection(Arrays.asList(CAR_TYPE).indexOf(carInfo.getCarType()));
                                        carFueType.setSelection(Arrays.asList(CAR_FUEL_TYPE).indexOf(carInfo.getFuelType()));

                                        if (userId == 0) {
                                            Intent intent = new Intent(getActivity(), Main.class);
                                            startActivity(intent);
                                        }
                                    } else {
                                        TSnackbar snackbar = TSnackbar
                                                .make(getView(), "Can't connect to server", TSnackbar.LENGTH_LONG);
                                        snackbar.setActionTextColor(Color.WHITE);
                                        View snackbarView = snackbar.getView();
                                        snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                                        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                                        textView.setTextColor(Color.WHITE);
                                        textView.setTypeface(Typeface.DEFAULT_BOLD);
                                        snackbar.show();
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }

                            @Override
                            public void onFailure(Call<CarInfoBean> call, Throwable t) {
                                if ((progress != null) && progress.isShowing()) {
                                    progress.dismiss();
                                }

                                //response is 0
                                if (t.getClass() != null && t.getClass() == JsonMappingException.class) {

                                    TSnackbar snackbar = TSnackbar
                                            .make(getView(), "No car details available", TSnackbar.LENGTH_SHORT);
                                    snackbar.setActionTextColor(Color.WHITE);
                                    View snackbarView = snackbar.getView();
                                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                                    textView.setTextColor(Color.WHITE);
                                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                                    snackbar.show();

                                } else {
                                    TSnackbar snackbar = TSnackbar
                                            .make(getView(), "Please check your connection", TSnackbar.LENGTH_LONG);
                                    snackbar.setActionTextColor(Color.WHITE);
                                    View snackbarView = snackbar.getView();
                                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                                    textView.setTextColor(Color.WHITE);
                                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                                    snackbar.show();
                                }
                            }
                        });
                    }
                } while (c.moveToNext());
            }
        }

        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                progress = new ProgressDialog(getActivity(), R.style.appThemeDialogue);
                progress.setMessage("Please Wait...");
                progress.show();

                //close keyboard
                InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }
                if (valid()) {
                    String carNameTxt = carName.getText().toString();
                    String carCompanyTxt = carCompany.getText().toString();
                    String carYearTxt = carYear.getText().toString();
                    String carTypeTxt = carType.getSelectedItem().toString();
                    String fuelTypeTxt = carFueType.getSelectedItem().toString();

                    call = new ShareACarApiService(getActivity()).getShareACarApi().addUpdateCarInfo(userId + "", carNameTxt, carCompanyTxt, carYearTxt, carTypeTxt, fuelTypeTxt);
                    call.enqueue(new Callback<ResponseBody>() {
                        @Override
                        public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                            if (response.code() == 200) {
                                try {
                                    resultUpdateCarInfo = response.body().string();
//                                            Log.e("response","carInfo" + response.body().string());
//                                            Log.e("resultUpdateCarInfo","" + resultUpdateCarInfo);

                                    offerRideFinal.carInfoNotAdded = false;
                                    updateCarInfoRes();

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            } else {
                                TSnackbar snackbar = TSnackbar
                                        .make(getView(), "Can't connect to server", TSnackbar.LENGTH_LONG);
                                snackbar.setActionTextColor(Color.WHITE);
                                View snackbarView = snackbar.getView();
                                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                                textView.setTextColor(Color.WHITE);
                                textView.setTypeface(Typeface.DEFAULT_BOLD);
                                snackbar.show();
                            }
                        }

                        @Override
                        public void onFailure(Call<ResponseBody> call, Throwable t) {
                            if ((progress != null) && progress.isShowing()) {
                                progress.dismiss();
                            }
                            TSnackbar snackbar = TSnackbar
                                    .make(getView(), "Please check your connection", TSnackbar.LENGTH_LONG);
                            snackbar.setActionTextColor(Color.WHITE);
                            View snackbarView = snackbar.getView();
                            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                            textView.setTextColor(Color.WHITE);
                            textView.setTypeface(Typeface.DEFAULT_BOLD);
                            snackbar.show();
                        }
                    });
                }
            }
        });
        return view;
    }

    private void updateCarInfoRes() {

        String resultArray[] = resultUpdateCarInfo.split("::");

        try {
            String carId = resultArray[2];

            mydatabase.execSQL("update loginInfo set carId = " + carId + " where userId = " + userId + ";");

            if (resultArray[0].equalsIgnoreCase("Success")) {
                if ((progress != null) && progress.isShowing()) {
                    progress.dismiss();
                }

                if (from != null && from.equalsIgnoreCase("offerRideFinal")) {

                    final FragmentTransaction ft = getFragmentManager().beginTransaction();
                    offerRideFinal orf = new offerRideFinal();

                    Bundle args = new Bundle();
                    args.putParcelable("postRideBean", postRideBean);

                    orf.setArguments(args);
                    ft.replace(R.id.frame, orf);
                    ft.addToBackStack(null);
                    ft.commit();

                } else {
                    TSnackbar snackbar = TSnackbar
                            .make(getView(), resultArray[1], TSnackbar.LENGTH_SHORT);
                    snackbar.setActionTextColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                    textView.setTextColor(Color.WHITE);
                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                    snackbar.show();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mydatabase.isOpen())
            mydatabase.close();
    }

    public boolean valid() {

        boolean valid = true;
        String carNameTxt = carName.getText().toString();
        String carCompanyTxt = carCompany.getText().toString();
//        String carYearTxt = carYear.getText().toString();

        String carTypeTxt = carType.getSelectedItem().toString();
        String carFueTypeTxt = carFueType.getSelectedItem().toString();

        if (carNameTxt.isEmpty()) {
            if ((progress != null) && progress.isShowing()) {
                progress.dismiss();
            }
            TSnackbar snackbar = TSnackbar
                    .make(getView(), "Please enter car name", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
        } else if (carCompanyTxt.isEmpty()) {
            if ((progress != null) && progress.isShowing()) {
                progress.dismiss();
            }
            TSnackbar snackbar = TSnackbar
                    .make(getView(), "Please enter car company name", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
        } else if (carTypeTxt == CAR_TYPE[0]) {
            if ((progress != null) && progress.isShowing()) {
                progress.dismiss();
            }
            TSnackbar snackbar = TSnackbar
                    .make(getView(), "Please select car type", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
        } else if (carFueTypeTxt == CAR_FUEL_TYPE[0]) {
            if ((progress != null) && progress.isShowing()) {
                progress.dismiss();
            }
            TSnackbar snackbar = TSnackbar
                    .make(getView(), "Please select fuel type", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
        }
        return valid;
    }

    @Override
    public void onResume() {
        textviewTitle = (TextView) getActivity().findViewById(R.id.textviewTitle);
        if (textviewTitle.getVisibility() == View.GONE)
            textviewTitle.setVisibility(View.VISIBLE);
        textviewTitle.setText("Car Information");

        header = (ImageView) getActivity().findViewById(R.id.tv_header_title);
        if (header.getVisibility() == View.VISIBLE)
            header.setVisibility(View.GONE);

        shareRide = (ImageView) getActivity().findViewById(R.id.shareRide);
        if (shareRide.getVisibility() == View.VISIBLE)
            shareRide.setVisibility(View.GONE);

        super.onResume();
    }
}
