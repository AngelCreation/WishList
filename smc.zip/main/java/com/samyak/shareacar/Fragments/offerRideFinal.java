package com.samyak.shareacar.Fragments;

import android.annotation.TargetApi;
import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.androidadvance.topsnackbar.TSnackbar;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.samyak.shareacar.Models.PostRideBean;
import com.samyak.shareacar.R;
import com.samyak.shareacar.RetrofitApi.ShareACarApiService;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class offerRideFinal extends Fragment {

    public static boolean carInfoNotAdded = false;
    Call<ResponseBody> call;
    String result;
    EditText message;
    TextView distance, textviewTotalDistance, pricePerPerson;
    LinearLayout stopage1, stopage2, stopage3, stopage4, stopage5, stopage6;
    TextView stopagePrice1, stopagePrice2, stopagePrice3, stopagePrice4, stopagePrice5, stopagePrice6;
    TextView stopageDistance1, stopageDistance2, stopageDistance3, stopageDistance4, stopageDistance5, stopageDistance6;
    TextView stopageRide1, stopageRide2, stopageRide3, stopageRide4, stopageRide5, stopageRide6;
    String rideDate, rideTime, startCity, destCity;
    String fromDailyDate, toDailyDate, timeDaily;
    Double startLat, startLong, destLat, destLong;
    boolean stopageFlag = true;
    Button offerRide1;
    ArrayList<Integer> proposedRate = new ArrayList<Integer>();
    //    int finalDistance[] = new int[6];
    ArrayList<Integer> finalDistance = new ArrayList<Integer>(Collections.nCopies(6, 0));
    int finalPrice[] = new int[6];
    ArrayList<Integer> finalPriceSent = new ArrayList<Integer>(Collections.nCopies(6, 0));
    ArrayList<Integer> distanceTxt = new ArrayList<Integer>(Collections.nCopies(6, 0));
    ArrayList<String> time = new ArrayList<String>(Collections.nCopies(6, ""));
    ArrayList<String> stops = new ArrayList<String>(Collections.nCopies(6, ""));
    ArrayList<String> finalTime = new ArrayList<String>(Collections.nCopies(6, ""));
    ArrayList<String> finalStops = new ArrayList<String>(Collections.nCopies(5, ""));
    ArrayList days = new ArrayList();
    boolean valid = true;
    PostRideBean postRideBean;
    View view;
    private ImageView imageviewPlus, imageviewMinus;
    private TextView textviewNoofSeats;
    private ImageView imageviewMinusPrice1, imageviewPlusPrice1;
    private ImageView imageviewMinusPrice2, imageviewPlusPrice2;
    private ImageView imageviewMinusPrice3, imageviewPlusPrice3;
    private ImageView imageviewMinusPrice4, imageviewPlusPrice4;
    private ImageView imageviewMinusPrice5, imageviewPlusPrice5;
    private ImageView imageviewMinusPrice6, imageviewPlusPrice6;
    private ImageView imageviewMinusPriceTotal, imageviewPlusPriceTotal;
    private ProgressDialog progress;
    private boolean isRideDaily = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
//        final String LOG = "offerRideFinal";
        // Inflate the layout for this fragment
        Bundle bundle = this.getArguments();
        postRideBean = bundle.getParcelable("postRideBean");

        rideDate = postRideBean.getDateRide();
        isRideDaily = postRideBean.getIsRideDaily(); //daily
        fromDailyDate = postRideBean.getFromDailyDate();  //daily
        toDailyDate = postRideBean.getToDailyDate();  //daily
        rideTime = postRideBean.getTimeRide();
        timeDaily = postRideBean.getTimeDaily();  //daily
        startCity = postRideBean.getFromCity();
        destCity = postRideBean.getToCity();
        startLat = postRideBean.getFromLat();
        startLong = postRideBean.getFromLong();
        destLat = postRideBean.getToLat();
        destLong = postRideBean.getToLong();

        proposedRate = postRideBean.getPricePerPerson();
        time = postRideBean.getRideTime();
        distanceTxt = postRideBean.getDistance();
        stops = postRideBean.getStops();
        days = postRideBean.getDaysList();  //DAILY

//        Log.e("isRideDaily","" + isRideDaily);

        int totalDistance = 0;
        int totalPrice = 0;
        int count = 0;

        for (int price : proposedRate) {
//            Log.e(LOG, "proposedRate" + price);
            totalPrice = totalPrice + price;
            if (price != 0) {
                finalPrice[count] = price;
                count++;
            }
        }
        count = 0;

        for (int dis : distanceTxt) {
            totalDistance = totalDistance + dis;
            if (dis != 0) {
                finalDistance.set(count, dis);
                count++;
            }
        }

        count = 0;
        for (String stop : stops) {
            if (stop != null && !stop.equals("")) {
                finalStops.set(count, stop);
                count++;
            }
        }

        count = 0;
        for (String ti : time) {
            if (ti != null && !ti.equals("")) {
                finalTime.set(count, ti);
                count++;
            }
        }
        int userId = 0;
        int carId = 0;
        SQLiteDatabase mydatabase = getActivity().openOrCreateDatabase("shareACar", getActivity().MODE_PRIVATE, null);
        mydatabase.execSQL("CREATE TABLE IF NOT EXISTS loginInfo(userId INTEGER ,carId INTEGER , contactNo TEXT , emailId TEXT, userName TEXT);");
        Cursor c = mydatabase.rawQuery("Select * from loginInfo", null);

        if (c != null) {
            if (c.moveToFirst()) {
                do {
                    userId = c.getInt(c.getColumnIndex("userId"));
//                    Log.e("userid in offer", "ride final" + userId);
                    carId = c.getInt(c.getColumnIndex("carId"));

                    if (carId == 0) {
                        carInfoNotAdded = true;
                        final FragmentTransaction ft = getFragmentManager().beginTransaction();
//                        ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
                        carInfoFragment cif = new carInfoFragment();
                        Bundle args = new Bundle();
                        args.putString("from", "offerRideFinal");
                        args.putParcelable("postRideBean", postRideBean);

                        /*
                        args.putBoolean("isRideDaily",isRideDaily); //daily
                        args.putString("rideDate", rideDate);
                        args.putString("fromDailyDate", fromDailyDate); //daily
                        args.putString("toDailyDate", toDailyDate); //daily
                        args.putString("rideTime", rideTime);
                        args.putString("timeDaily",timeDaily);  //daily
                        args.putString("startCity", startCity);
                        args.putString("destCity", destCity);
                        args.putDouble("startLat", startLat);
                        args.putDouble("startLong", startLong);
                        args.putDouble("destLat", destLat);
                        args.putDouble("destLong", destLong);
                        args.putIntArray("proposedRate", proposedRate);
                        args.putIntArray("distance", distanceTxt);
                        args.putStringArray("time", time);
                        args.putStringArray("stops", stops);*/
                        cif.setArguments(args);

                        ft.replace(R.id.frame, cif);
                        ft.addToBackStack(null);
                        ft.commit();
                    }
                } while (c.moveToNext());
            }
        }
        view = inflater.inflate(R.layout.fragment_offer_ride_final, container, false);

        pricePerPerson = (TextView) view.findViewById(R.id.txt_price_person_total);
        // noOfSeats = (TextView)v.findViewById(R.id.material_spinner1);
        distance = (TextView) view.findViewById(R.id.txt_ride_distance_km);
        //  distance.setText(distanceTxt+" km");
        message = (EditText) view.findViewById(R.id.txt_message);
        offerRide1 = (Button) view.findViewById(R.id.btn_submit_ride);
        offerRide1.getBackground().setAlpha(128);
        offerRide1.setEnabled(false);
        //pricePerPerson.setText(proposedRate+"");
        stopage1 = (LinearLayout) view.findViewById(R.id.layout_stopage_1);
        stopage2 = (LinearLayout) view.findViewById(R.id.layout_stopage_2);
        stopage3 = (LinearLayout) view.findViewById(R.id.layout_stopage_3);
        stopage4 = (LinearLayout) view.findViewById(R.id.layout_stopage_4);
        stopage5 = (LinearLayout) view.findViewById(R.id.layout_stopage_5);
        stopage6 = (LinearLayout) view.findViewById(R.id.layout_stopage_6);
        stopagePrice1 = (TextView) view.findViewById(R.id.txt_price_person_1);
        stopagePrice2 = (TextView) view.findViewById(R.id.txt_price_person_2);
        stopagePrice3 = (TextView) view.findViewById(R.id.txt_price_person_3);
        stopagePrice4 = (TextView) view.findViewById(R.id.txt_price_person_4);
        stopagePrice5 = (TextView) view.findViewById(R.id.txt_price_person_5);
        stopagePrice6 = (TextView) view.findViewById(R.id.txt_price_person_6);
        stopageDistance1 = (TextView) view.findViewById(R.id.txt_ride_distance_km_1);
        stopageDistance2 = (TextView) view.findViewById(R.id.txt_ride_distance_km_2);
        stopageDistance3 = (TextView) view.findViewById(R.id.txt_ride_distance_km_3);
        stopageDistance4 = (TextView) view.findViewById(R.id.txt_ride_distance_km_4);
        stopageDistance5 = (TextView) view.findViewById(R.id.txt_ride_distance_km_5);
        stopageDistance6 = (TextView) view.findViewById(R.id.txt_ride_distance_km_6);
        stopageRide1 = (TextView) view.findViewById(R.id.lbl_offer_ride_1);
        stopageRide2 = (TextView) view.findViewById(R.id.lbl_offer_ride_2);
        stopageRide3 = (TextView) view.findViewById(R.id.lbl_offer_ride_3);
        stopageRide4 = (TextView) view.findViewById(R.id.lbl_offer_ride_4);
        stopageRide5 = (TextView) view.findViewById(R.id.lbl_offer_ride_5);
        stopageRide6 = (TextView) view.findViewById(R.id.lbl_offer_ride_6);
        textviewTotalDistance = (TextView) view.findViewById(R.id.total_distance);

        imageviewPlus = (ImageView) view.findViewById(R.id.imageviewPlus);
        imageviewMinus = (ImageView) view.findViewById(R.id.imageviewMinus);
        textviewNoofSeats = (TextView) view.findViewById(R.id.textviewNoofSeats);

        imageviewPlusPrice1 = (ImageView) view.findViewById(R.id.imageviewPlusPrice1);
        imageviewPlusPrice2 = (ImageView) view.findViewById(R.id.imageviewPlusPrice2);
        imageviewPlusPrice3 = (ImageView) view.findViewById(R.id.imageviewPlusPrice3);
        imageviewPlusPrice4 = (ImageView) view.findViewById(R.id.imageviewPlusPrice4);
        imageviewPlusPrice5 = (ImageView) view.findViewById(R.id.imageviewPlusPrice5);
        imageviewPlusPrice6 = (ImageView) view.findViewById(R.id.imageviewPlusPrice6);
        imageviewPlusPriceTotal = (ImageView) view.findViewById(R.id.imageviewPlusPriceTotal);

        imageviewMinusPrice1 = (ImageView) view.findViewById(R.id.imageviewMinusPrice1);
        imageviewMinusPrice2 = (ImageView) view.findViewById(R.id.imageviewMinusPrice2);
        imageviewMinusPrice3 = (ImageView) view.findViewById(R.id.imageviewMinusPrice3);
        imageviewMinusPrice4 = (ImageView) view.findViewById(R.id.imageviewMinusPrice4);
        imageviewMinusPrice5 = (ImageView) view.findViewById(R.id.imageviewMinusPrice5);
        imageviewMinusPrice6 = (ImageView) view.findViewById(R.id.imageviewMinusPrice6);
        imageviewMinusPriceTotal = (ImageView) view.findViewById(R.id.imageviewMinusPriceTotal);

        if (Integer.parseInt(textviewNoofSeats.getText().toString()) <= 1) {
//            imageviewMinus.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinus.setEnabled(false);
        }

        if (Integer.parseInt(textviewNoofSeats.getText().toString()) > 1) {
            imageviewMinus.setImageResource(R.drawable.ic_minus);
            imageviewMinus.setEnabled(true);
        }

        imageviewPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = Integer.parseInt(textviewNoofSeats.getText().toString());
                textviewNoofSeats.setText("" + (i + 1));

                if (Integer.parseInt(textviewNoofSeats.getText().toString()) > 1) {
                    imageviewMinus.setImageResource(R.drawable.ic_minus);
                    imageviewMinus.setEnabled(true);
                }

                if (Integer.parseInt(textviewNoofSeats.getText().toString()) >= 8) {
                    imageviewPlus.setImageResource(R.drawable.ic_plus_disable);
                    imageviewPlus.setEnabled(false);
                }
            }
        });

        imageviewMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = Integer.parseInt(textviewNoofSeats.getText().toString());
                textviewNoofSeats.setText("" + (i - 1));

                if (Integer.parseInt(textviewNoofSeats.getText().toString()) < 8) {
                    imageviewPlus.setImageResource(R.drawable.ic_plus);
                    imageviewPlus.setEnabled(true);
                }

                if (Integer.parseInt(textviewNoofSeats.getText().toString()) <= 1) {
                    imageviewMinus.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinus.setEnabled(false);
                }
            }
        });

        textviewTotalDistance.setText(startCity + " - " + destCity);

        if (finalStops.get(0) != null && !finalStops.get(0).equals("")) {
            stopageRide1.setText(startCity + " - " + finalStops.get(0));
            stopageDistance1.setText(finalDistance.get(0) + " km");
//            stopageDistance1.setText(String.format("%.0f", finalDistance[0]) + " km");
            stopagePrice1.setText("\u20B9" + finalPrice[0]);
//            stopagePrice1.setText("\u20B9" + String.format("%.0f", finalPrice[0]) + "");
            stopageFlag = false;
        } else {
            stopageDistance1.setText(finalDistance.get(0) + " km");
//            stopageDistance1.setText(String.format("%.0f", finalDistance[0]) + " km");
            stopagePrice1.setText("\u20B9" + finalPrice[0]);
//            stopagePrice1.setText("\u20B9" + String.format("%.0f", finalPrice[0]) + "");
            stopage1.setVisibility(View.GONE);
        }
        if (finalStops.get(1) != null && !finalStops.get(1).equals("")) {
            stopageRide2.setText(finalStops.get(0) + " - " + finalStops.get(1));
            stopageDistance2.setText(finalDistance.get(1) + " km");
//            stopageDistance2.setText(String.format("%.0f", finalDistance[1]) + " km");
            stopagePrice2.setText("\u20B9" + finalPrice[1]);
//            stopagePrice2.setText("\u20B9" + String.format("%.0f", finalPrice[1]) + "");
            stopageFlag = false;
        } else {
            stopageRide2.setText(finalStops.get(0) + " - " + destCity);
            stopageDistance2.setText(finalDistance.get(1) + " km");
//            stopageDistance2.setText(String.format("%.0f", finalDistance[1]) + " km");
            stopagePrice2.setText("\u20B9" + finalPrice[1]);
//            stopagePrice2.setText("\u20B9" + String.format("%.0f", finalPrice[1]) + "");
            stopage3.setVisibility(View.GONE);
        }
        if (finalStops.get(2) != null && !finalStops.get(2).equals("")) {
            stopageRide3.setText(finalStops.get(1) + " - " + finalStops.get(2));
            stopageDistance3.setText(finalDistance.get(2) + " km");
//            stopageDistance3.setText(String.format("%.0f", finalDistance[2]) + " km");
            stopagePrice3.setText("\u20B9" + finalPrice[2]);
//            stopagePrice3.setText("\u20B9" + String.format("%.0f", finalPrice[2]) + "");
            stopageFlag = false;
        } else {
            stopageRide3.setText(finalStops.get(1) + " - " + destCity);
            stopageDistance3.setText(finalDistance.get(2) + " km");
//            stopageDistance3.setText(String.format("%.0f", finalDistance[2]) + " km");
            stopagePrice3.setText("\u20B9" + finalPrice[2]);
//            stopagePrice3.setText("\u20B9" + String.format("%.0f", finalPrice[2]) + "");
            stopage4.setVisibility(View.GONE);
        }
        if (finalStops.get(3) != null && !finalStops.get(3).equals("")) {
            stopageRide4.setText(finalStops.get(2) + " - " + finalStops.get(3));
            stopageDistance4.setText(finalDistance.get(3) + " km");
//            stopageDistance4.setText(String.format("%.0f", finalDistance[3]) + " km");
            stopagePrice4.setText("\u20B9" + finalPrice[3]);
//            stopagePrice4.setText("\u20B9" + String.format("%.0f", finalPrice[3]) + "");
            stopageFlag = false;
        } else {
            stopageRide4.setText(finalStops.get(2) + " - " + destCity);
            stopageDistance4.setText(finalDistance.get(3) + " km");
//            stopageDistance4.setText(String.format("%.0f", finalDistance[3]) + " km");
            stopagePrice4.setText("\u20B9" + finalPrice[3]);
//            stopagePrice4.setText("\u20B9" + String.format("%.0f", finalPrice[3]) + "");
            stopage5.setVisibility(View.GONE);
        }
        if (finalStops.get(4) != null && !finalStops.get(4).equals("")) {
            stopageRide5.setText(finalStops.get(3) + " - " + finalStops.get(4));
            stopageRide6.setText(finalStops.get(4) + " - " + destCity);
            stopageDistance5.setText(finalDistance.get(4) + " km");
//            stopageDistance5.setText(String.format("%.0f", finalDistance[4]) + " km");
            stopagePrice5.setText("\u20B9" + finalPrice[4]);
//            stopagePrice5.setText("\u20B9" + String.format("%.0f", finalPrice[4]) + "");
            stopageDistance6.setText(finalDistance.get(5) + " km");
//            stopageDistance6.setText(String.format("%.0f", finalDistance[5]) + " km");
            stopagePrice6.setText("\u20B9" + finalPrice[5]);
//            stopagePrice6.setText("\u20B9" + String.format("%.0f", finalPrice[5]) + "");
            stopageFlag = false;
        } else {
            stopageRide5.setText(finalStops.get(3) + " - " + destCity);
            stopageDistance5.setText(finalDistance.get(4) + " km");
//            stopageDistance5.setText(String.format("%.0f", finalDistance[4]) + " km");
            stopagePrice5.setText("\u20B9" + finalPrice[4]);
//            stopagePrice5.setText("\u20B9" + String.format("%.0f", finalPrice[4]) + "");
            stopage6.setVisibility(View.GONE);
        }

        if (stopageFlag) {
            stopage1.setVisibility(View.GONE);
            stopage2.setVisibility(View.GONE);
            stopage3.setVisibility(View.GONE);
            stopage4.setVisibility(View.GONE);
            stopage5.setVisibility(View.GONE);
            pricePerPerson.setText("\u20B9" + proposedRate.get(0));
//            pricePerPerson.setText("\u20B9" + String.format("%.0f", proposedRate[0]) + "");
//            pricePerPerson.setText("\u20B9" + proposedRate[0]+"");
            distance.setText(distanceTxt.get(0) + " km");
//            distance.setText(String.format("%.0f", distanceTxt[0]) + " km");
        } else {
            pricePerPerson.setText("\u20B9" + totalPrice);
//            pricePerPerson.setText("\u20B9" + String.format("%.0f", totalPrice));
            distance.setText(totalDistance + " km");
//            distance.setText(String.format("%.0f", totalDistance) + " km");
        }

        setPrices();

        final int finalUserId = userId;

        message.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                valid();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        offerRide1.setOnClickListener(new View.OnClickListener() {

            @TargetApi(Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View v) {
                makeCall(v, finalUserId);
            }
        });

        return view;
    }

    public void makeCall(View v, int finalUserId) {
        progress = new ProgressDialog(getActivity(), R.style.appThemeDialogue);
        progress.setMessage("Please Wait...");
        progress.setCancelable(false);
        progress.show();

        //close keyboard
        InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        }

        if (valid()) {

            finalPriceSent.set(0, Integer.parseInt(stopagePrice1.getText().toString().replace("\u20B9", "").trim()));
            finalPriceSent.set(1, Integer.parseInt(stopagePrice2.getText().toString().replace("\u20B9", "").trim()));
            finalPriceSent.set(2, Integer.parseInt(stopagePrice3.getText().toString().replace("\u20B9", "").trim()));
            finalPriceSent.set(3, Integer.parseInt(stopagePrice4.getText().toString().replace("\u20B9", "").trim()));
            finalPriceSent.set(4, Integer.parseInt(stopagePrice5.getText().toString().replace("\u20B9", "").trim()));
            finalPriceSent.set(5, Integer.parseInt(stopagePrice6.getText().toString().replace("\u20B9", "").trim()));

            PostRideBean postRideBean = new PostRideBean();
            postRideBean.setUserId(finalUserId);
            postRideBean.setFromCity(startCity);
            postRideBean.setToCity(destCity);
            postRideBean.setFromLat(startLat);
            postRideBean.setFromLong(startLong);
            postRideBean.setToLat(destLat);
            postRideBean.setToLong(destLong);
            postRideBean.setTotal(pricePerPerson.getText().toString().replace("\u20B9", "").trim());
            postRideBean.setPricePerPerson(finalPriceSent);
            postRideBean.setNoOfPerson(textviewNoofSeats.getText().toString());
            postRideBean.setRideMessage(message.getText().toString());
            postRideBean.setRideTime(finalTime);
            postRideBean.setStops(finalStops);
            postRideBean.setDistance(finalDistance);
//            postRideBean.setIsRideDaily(isRideDaily);

            if (isRideDaily) {
                postRideBean.setFromDailyDate(fromDailyDate);
                postRideBean.setToDailyDate(toDailyDate);
                postRideBean.setTimeDaily(timeDaily);
                postRideBean.setDaysList(days);
            } else {
                postRideBean.setDateRide(rideDate);
                postRideBean.setTimeRide(rideTime);
            }

//            Log.e("postRideBean","" + postRideBean.toString());

            try {
                //to print output string
                try {
                    Log.e("request", new ObjectMapper().writeValueAsString(postRideBean));
                } catch (JsonProcessingException e) {
                    e.printStackTrace();
                }

                if (isRideDaily) {
                    call = new ShareACarApiService(getActivity()).getShareACarApi().postRideDaily(postRideBean);
                } else {
                    call = new ShareACarApiService(getActivity()).getShareACarApi().addRide(postRideBean);
                }

//                Log.e("rideMaster","" + rideMaster.toString());
                call.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        if ((progress != null)) {
                            progress.dismiss();
                        }
                        try {
                            if (response.code() == 200) {
                                result = response.body().string();

                                TSnackbar snackbar = TSnackbar.make(getView(), result, TSnackbar.LENGTH_SHORT);
                                snackbar.setActionTextColor(Color.WHITE);
                                View snackbarView = snackbar.getView();
                                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                                textView.setTextColor(Color.WHITE);
                                textView.setTypeface(Typeface.DEFAULT_BOLD);
                                snackbar.show();

                                new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {
                                            Thread.sleep(2000);
                                            Fragment fragment = getFragmentManager().findFragmentByTag("offerRide");

                                            // Do some stuff
                                            if (result.toString().equalsIgnoreCase("Ride is posted for approval.")) {
//                                                    calledFromFinal = true;
                                                FragmentTransaction ft = getFragmentManager().beginTransaction();
                                                ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
                                                ft.replace(R.id.frame, new myRidesFragment());
//                                                    ft.remove(fragment);
                                                ft.addToBackStack(null);
                                                ft.commit();
                                            }

                                        } catch (Exception e) {
                                            e.getLocalizedMessage();
                                        }
                                    }
                                }).start();
                            } else {
                                TSnackbar snackbar = TSnackbar
                                        .make(getView(), "Can't connect to server", TSnackbar.LENGTH_LONG);
                                snackbar.setActionTextColor(Color.WHITE);
                                View snackbarView = snackbar.getView();
                                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                                textView.setTextColor(Color.WHITE);
                                textView.setTypeface(Typeface.DEFAULT_BOLD);
                                snackbar.show();
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        if ((progress != null)) {
                            progress.dismiss();
                        }
                        offerRide1.getBackground().setAlpha(255);
                        TSnackbar snackbar = TSnackbar
                                .make(getView(), "Please Check Your Connection", TSnackbar.LENGTH_LONG);
                        snackbar.setActionTextColor(Color.WHITE);
                        View snackbarView = snackbar.getView();
                        snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                        textView.setTextColor(Color.WHITE);
                        textView.setTypeface(Typeface.DEFAULT_BOLD);
                        snackbar.show();
                    }
                });

            } catch (Exception e) {
                if ((progress != null)) {
                    progress.dismiss();
                }
                e.printStackTrace();
            }
        }
    }

    public boolean valid() {

        String messageTxt = message.getText().toString();

        /*if(stopageFlag) {
            if(distanceTxt[0] == 0) {
                offerRide1.getBackground().setAlpha(128);
                offerRide1.setEnabled(false);
                valid = false;
            }
        }*/

        /*if((stopage1.getVisibility() == View.VISIBLE && finalDistance[0] == 0)
                || (stopage2.getVisibility() == View.VISIBLE && finalDistance[1] == 0 )
                || (stopage3.getVisibility() == View.VISIBLE && finalDistance[2] == 0)
                || (stopage4.getVisibility() == View.VISIBLE && finalDistance[3] == 0)
                || (stopage5.getVisibility() == View.VISIBLE && finalDistance[4] == 0 )
                || (stopage6.getVisibility() == View.VISIBLE && finalDistance[5] == 0)) {

            offerRide1.getBackground().setAlpha(128);
            offerRide1.setEnabled(false);
            valid = false;

        } else {*/
        offerRide1.getBackground().setAlpha(255);
        offerRide1.setEnabled(true);
        if (stopage1.getVisibility() == View.VISIBLE) {
                /*if (stopagePrice1.getText().toString().replace("\u20B9", "").equals(String.valueOf(0))) {
                    offerRide1.getBackground().setAlpha(128);
                    offerRide1.setEnabled(false);
                    valid = false;
                } else {
                    offerRide1.getBackground().setAlpha(255);
                    offerRide1.setEnabled(true);
                    proposedRate[0] = Float.parseFloat(stopagePrice1.getText().toString().replace("\u20B9", ""));
                    Log.e("final", "" + stopagePrice1.getText().toString().replace("\u20B9", ""));
                }*/
//                offerRide1.getBackground().setAlpha(255);
//                offerRide1.setEnabled(true);
            proposedRate.set(0, Integer.parseInt(stopagePrice1.getText().toString().replace("\u20B9", "")));
//                Log.e("final", "" + stopagePrice1.getText().toString().replace("\u20B9", ""));

        }
        if (stopage2.getVisibility() == View.VISIBLE) {
                /*if (stopagePrice2.getText().toString().replace("\u20B9", "").equals(String.valueOf(0))) {
                    offerRide1.getBackground().setAlpha(128);
                    offerRide1.setEnabled(false);
                    valid = false;
                } else {
                    offerRide1.getBackground().setAlpha(255);
                    offerRide1.setEnabled(true);
                    proposedRate[1] = Float.parseFloat(stopagePrice2.getText().toString().replace("\u20B9", ""));
                }*/
//                offerRide1.getBackground().setAlpha(255);
//                offerRide1.setEnabled(true);
            proposedRate.set(1, Integer.parseInt(stopagePrice2.getText().toString().replace("\u20B9", "")));
        }
        if (stopage3.getVisibility() == View.VISIBLE) {
               /* if (stopagePrice3.getText().toString().replace("\u20B9", "").equals(String.valueOf(0))) {
                    offerRide1.getBackground().setAlpha(128);
                    offerRide1.setEnabled(false);
                    valid = false;
                } else {
                    offerRide1.getBackground().setAlpha(255);
                    offerRide1.setEnabled(true);
                    proposedRate[2] = Float.parseFloat(stopagePrice3.getText().toString().replace("\u20B9", ""));
                }*/
//                offerRide1.getBackground().setAlpha(255);
//                offerRide1.setEnabled(true);
            proposedRate.set(2, Integer.parseInt(stopagePrice3.getText().toString().replace("\u20B9", "")));
        }
        if (stopage4.getVisibility() == View.VISIBLE) {
                /*if (stopagePrice4.getText().toString().replace("\u20B9", "").equals(String.valueOf(0))) {
                    offerRide1.getBackground().setAlpha(128);
                    offerRide1.setEnabled(false);
                    valid = false;
                } else {
                    offerRide1.getBackground().setAlpha(255);
                    offerRide1.setEnabled(true);
                    proposedRate[3] = Float.parseFloat(stopagePrice4.getText().toString().replace("\u20B9", ""));
                }*/
//                offerRide1.getBackground().setAlpha(255);
//                offerRide1.setEnabled(true);
            proposedRate.set(3, Integer.parseInt(stopagePrice4.getText().toString().replace("\u20B9", "")));
        }
        if (stopage5.getVisibility() == View.VISIBLE) {
                /*if (stopagePrice5.getText().toString().replace("\u20B9", "").equals(String.valueOf(0))) {
                    offerRide1.getBackground().setAlpha(128);
                    offerRide1.setEnabled(false);
                    valid = false;
                } else {
                    offerRide1.getBackground().setAlpha(255);
                    offerRide1.setEnabled(true);
                    proposedRate[4] = Float.parseFloat(stopagePrice5.getText().toString().replace("\u20B9", ""));
                }*/
//                offerRide1.getBackground().setAlpha(255);
//                offerRide1.setEnabled(true);
            proposedRate.set(4, Integer.parseInt(stopagePrice5.getText().toString().replace("\u20B9", "")));
        }
        if (stopage6.getVisibility() == View.VISIBLE) {
                /*if (stopagePrice6.getText().toString().replace("\u20B9", "").equals(String.valueOf(0))) {
                    offerRide1.getBackground().setAlpha(128);
                    offerRide1.setEnabled(false);
                    valid = false;
                } else {
                    offerRide1.getBackground().setAlpha(255);
                    offerRide1.setEnabled(true);
                    proposedRate[5] = Float.parseFloat(stopagePrice6.getText().toString().replace("\u20B9", ""));
                }*/
//                offerRide1.getBackground().setAlpha(255);
//                offerRide1.setEnabled(true);
            proposedRate.set(5, Integer.parseInt(stopagePrice6.getText().toString().replace("\u20B9", "")));
        }
//        }

//        String pricePerPersonTxt = pricePerPerson.getText().toString();

        if (messageTxt.isEmpty()) {
            TSnackbar snackbar = TSnackbar
                    .make(getView(), "Please Enter Message", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            offerRide1.getBackground().setAlpha(128);
            offerRide1.setEnabled(false);
            valid = false;
        }
        return valid;
    }

    private void setPrices() {

        //no 1
        if (Integer.parseInt(stopagePrice1.getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice1.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice1.setEnabled(true);
        }

        if (Integer.parseInt(stopagePrice1.getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice1.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice1.setEnabled(false);
        }

        imageviewPlusPrice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                int i = Integer.parseInt(stopagePrice1.getText().toString().replace("\u20B9", ""));
                /*int j = i / 10;
                int rounded = j * 10;
                stopagePrice1.setText("\u20B9" + (rounded + 10));*/

                increaseStopagePrice(stopagePrice1);

//                calculateTotal();

                if (Integer.parseInt(stopagePrice1.getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice1.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice1.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                int i = Integer.parseInt(stopagePrice1.getText().toString().replace("\u20B9", ""));
                /*int j = i / 10;
                int rounded = j * 10;
                if(i % 10 == 0) {
                    stopagePrice1.setText("\u20B9" + (rounded - 10));
                } else {
                    stopagePrice1.setText("\u20B9" + (rounded));
                }*/

                decreaseStopagePrice(stopagePrice1);

//                calculateTotal();

                if (Integer.parseInt(stopagePrice1.getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice1.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice1.setEnabled(false);
                }
            }
        });

        //no 2
        if (Integer.parseInt(stopagePrice2.getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice2.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice2.setEnabled(true);
        }

        if (Integer.parseInt(stopagePrice2.getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice2.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice2.setEnabled(false);
        }

        imageviewPlusPrice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                increaseStopagePrice(stopagePrice2);

//                calculateTotal();

                if (Integer.parseInt(stopagePrice2.getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice2.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice2.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                decreaseStopagePrice(stopagePrice2);

//                calculateTotal();

                if (Integer.parseInt(stopagePrice2.getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice2.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice2.setEnabled(false);
                }
            }
        });

        //no 3
        if (Integer.parseInt(stopagePrice3.getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice3.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice3.setEnabled(true);
        }

        if (Integer.parseInt(stopagePrice3.getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice3.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice3.setEnabled(false);
        }

        imageviewPlusPrice3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                increaseStopagePrice(stopagePrice3);

//                calculateTotal();

                if (Integer.parseInt(stopagePrice3.getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice3.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice3.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                decreaseStopagePrice(stopagePrice3);

//                calculateTotal();

                if (Integer.parseInt(stopagePrice3.getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice3.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice3.setEnabled(false);
                }
            }
        });

        //no 4
        if (Integer.parseInt(stopagePrice4.getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice4.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice4.setEnabled(true);
        }

        if (Integer.parseInt(stopagePrice4.getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice4.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice4.setEnabled(false);
        }

        imageviewPlusPrice4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                increaseStopagePrice(stopagePrice4);

//                calculateTotal();

                if (Integer.parseInt(stopagePrice4.getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice4.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice4.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                decreaseStopagePrice(stopagePrice4);

//                calculateTotal();

                if (Integer.parseInt(stopagePrice4.getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice4.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice4.setEnabled(false);
                }
            }
        });

        //no 5
        if (Integer.parseInt(stopagePrice5.getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice5.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice5.setEnabled(true);
        }

        if (Integer.parseInt(stopagePrice5.getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice5.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice5.setEnabled(false);
        }

        imageviewPlusPrice5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                increaseStopagePrice(stopagePrice5);

//                calculateTotal();

                if (Integer.parseInt(stopagePrice5.getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice5.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice5.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                decreaseStopagePrice(stopagePrice5);

//                calculateTotal();

                if (Integer.parseInt(stopagePrice5.getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice5.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice5.setEnabled(false);
                }
            }
        });

        //no 6
        if (Integer.parseInt(stopagePrice6.getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice6.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice6.setEnabled(true);
        }

        if (Integer.parseInt(stopagePrice6.getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice6.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice6.setEnabled(false);
        }

        imageviewPlusPrice6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                increaseStopagePrice(stopagePrice6);

//                calculateTotal();

                if (Integer.parseInt(stopagePrice6.getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice6.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice6.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                decreaseStopagePrice(stopagePrice6);

//                calculateTotal();

                if (Integer.parseInt(stopagePrice6.getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice6.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice6.setEnabled(false);
                }
            }
        });

        //total
        if (Integer.parseInt(pricePerPerson.getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPriceTotal.setImageResource(R.drawable.ic_minus);
            imageviewMinusPriceTotal.setEnabled(true);
        }

        if (Integer.parseInt(pricePerPerson.getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPriceTotal.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPriceTotal.setEnabled(false);
        }

        imageviewPlusPriceTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* int i = Integer.parseInt(pricePerPerson.getText().toString().replace("\u20B9", ""));
                int j = i / 10;
                int rounded = j * 10;
                pricePerPerson.setText("\u20B9" + (rounded + 10));*/

                increaseStopagePrice(pricePerPerson);

//                calculateTotal();

                if (Integer.parseInt(pricePerPerson.getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPriceTotal.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPriceTotal.setEnabled(true);
                }
            }
        });

        imageviewMinusPriceTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*int i = Integer.parseInt(pricePerPerson.getText().toString().replace("\u20B9", ""));
                int j = i / 10;
                int rounded = j * 10;
                if(i % 10 == 0) {
                    pricePerPerson.setText("\u20B9" + (rounded - 10));
                } else {
                    pricePerPerson.setText("\u20B9" + (rounded));
                }*/

                decreaseStopagePrice(pricePerPerson);

//                calculateTotal();

                if (Integer.parseInt(pricePerPerson.getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPriceTotal.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPriceTotal.setEnabled(false);
                }
            }
        });
    }

    /*private void calculateTotal() {

        int total = Integer.parseInt(stopagePrice1.getText().toString().replace("\u20B9","")) +
                Integer.parseInt(stopagePrice2.getText().toString().replace("\u20B9","")) +
                Integer.parseInt(stopagePrice3.getText().toString().replace("\u20B9","")) +
                Integer.parseInt(stopagePrice4.getText().toString().replace("\u20B9","")) +
                Integer.parseInt(stopagePrice5.getText().toString().replace("\u20B9","")) +
                Integer.parseInt(stopagePrice6.getText().toString().replace("\u20B9",""));

        finalPriceSent.set(0,Integer.parseInt(stopagePrice1.getText().toString().replace("\u20B9","")));
        finalPriceSent.set(1,Integer.parseInt(stopagePrice2.getText().toString().replace("\u20B9","")));
        finalPriceSent.set(2,Integer.parseInt(stopagePrice3.getText().toString().replace("\u20B9","")));
        finalPriceSent.set(3,Integer.parseInt(stopagePrice4.getText().toString().replace("\u20B9","")));
        finalPriceSent.set(4,Integer.parseInt(stopagePrice5.getText().toString().replace("\u20B9","")));
        finalPriceSent.set(5,Integer.parseInt(stopagePrice6.getText().toString().replace("\u20B9","")));

        pricePerPerson.setText("\u20B9" + total);
    }*/

    private void increaseStopagePrice(TextView t) {
        int i = Integer.parseInt(t.getText().toString().replace("\u20B9", ""));
        if (i % 5 == 0) {
            t.setText("\u20B9" + (i + 5));
        } else {
            if (i < 10) {
                int j = i % 5;
                int k = 5 - j;
                t.setText("\u20B9" + (i + k));
            } else {
                float j = i / 5;
                int rounded = (int) ((j / 2) * 10);
                t.setText("\u20B9" + (rounded + 5));
            }
        }
    }

    private void decreaseStopagePrice(TextView t) {
        int i = Integer.parseInt(t.getText().toString().replace("\u20B9", ""));
        if (i % 5 == 0) {
            t.setText("\u20B9" + (i - 5));
        } else {
            if (i < 10) {
                int j = i % 5;
                t.setText("\u20B9" + (i - j));
            } else {
                float j = i / 5;
                int rounded = (int) ((j / 2) * 10);
                t.setText("\u20B9" + (rounded));
            }
        }
    }

}
