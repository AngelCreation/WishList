package com.samyak.shareacar.Fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.androidadvance.topsnackbar.TSnackbar;
import com.samyak.shareacar.Models.UserInfoBean;
import com.samyak.shareacar.R;
import com.samyak.shareacar.RetrofitApi.ShareACarApiService;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class editPersonalInfo extends Fragment {

    TextView firstName = null;
    TextView lastName = null;
    TextView email = null;
    TextView mobileNo = null;
    TextView textviewTitle = null;
    ImageView header, shareRide;
    Button updateProfile = null;
    int userId = 0;
    Call<ResponseBody> call;
    Call<UserInfoBean> call1;
    String result;
    View view;
    private ProgressDialog progress;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_edit_personal_info, container, false);
        String db[] = getActivity().databaseList();

        progress = new ProgressDialog(getActivity(), R.style.appThemeDialogue);
        progress.setMessage("Please Wait...");
        progress.show();

        SQLiteDatabase mydatabase = getActivity().openOrCreateDatabase(db[0], Context.MODE_PRIVATE, null);
        mydatabase.execSQL("CREATE TABLE IF NOT EXISTS loginInfo(userId INTEGER ,carId INTEGER , contactNo TEXT , emailId TEXT, userName TEXT);");
        Cursor c = mydatabase.rawQuery("Select * from loginInfo", null);
        firstName = (TextView) view.findViewById(R.id.input_first_name);
        lastName = (TextView) view.findViewById(R.id.input_last_name);
        email = (TextView) view.findViewById(R.id.input_email);
        mobileNo = (TextView) view.findViewById(R.id.input_mobile_no);
        updateProfile = (Button) view.findViewById(R.id.btn_edit_profile);
        if (c != null) {
            if (c.moveToFirst()) {
                do {
                    userId = c.getInt(c.getColumnIndex("userId"));
//                    Log.e("user id ","edit personal info" + userId);

                    call1 = new ShareACarApiService(getActivity()).getShareACarApi().getUserInfo(userId + "");
                    call1.enqueue(new Callback<UserInfoBean>() {
                        @Override
                        public void onResponse(Call<UserInfoBean> call, Response<UserInfoBean> response) {
                            if ((progress != null) && progress.isShowing()) {
                                progress.dismiss();
                            }

                            if (response.code() == 200) {
                                UserInfoBean userInfoBean = response.body();
                                firstName.setText(userInfoBean.getFirstName());
                                lastName.setText(userInfoBean.getLastName());
                                email.setText(userInfoBean.getEmail());
                                mobileNo.setText(userInfoBean.getMobileNo());
                            } else {
                                TSnackbar snackbar = TSnackbar
                                        .make(getView(), "Can't connect to server", TSnackbar.LENGTH_LONG);
                                snackbar.setActionTextColor(Color.WHITE);
                                View snackbarView = snackbar.getView();
                                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                                textView.setTextColor(Color.WHITE);
                                textView.setTypeface(Typeface.DEFAULT_BOLD);
                                snackbar.show();
                            }
                        }

                        @Override
                        public void onFailure(Call<UserInfoBean> call, Throwable t) {
                            if ((progress != null) && progress.isShowing()) {
                                progress.dismiss();
                            }
                            TSnackbar snackbar = TSnackbar
                                    .make(getView(), "Please check your connection", TSnackbar.LENGTH_LONG);
                            snackbar.setActionTextColor(Color.WHITE);
                            View snackbarView = snackbar.getView();
                            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                            textView.setTextColor(Color.WHITE);
                            textView.setTypeface(Typeface.DEFAULT_BOLD);
                            snackbar.show();
                        }
                    });

                } while (c.moveToNext());
            }
        }

        mydatabase.close();

        mobileNo.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_UP) {
                    hideKeyBoard(v);
                    progress = new ProgressDialog(getActivity(), R.style.appThemeDialogue);
                    progress.setMessage("Please Wait...");
                    progress.setCancelable(false);
                    progress.show();
                    try {
                        makeCall(v);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                return false;
            }
        });


        updateProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyBoard(v);
                progress = new ProgressDialog(getActivity(), R.style.appThemeDialogue);
                progress.setMessage("Please Wait...");
                progress.setCancelable(false);
                progress.show();
                makeCall(v);
            }
        });

        return view;
    }

    public void hideKeyBoard(View v) {
        InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        }
    }

    private void makeCall(View v) {

        if (valid(v)) {
            String firstNameTxt = firstName.getText().toString();
            String lastNameTxt = lastName.getText().toString();
            String mobileNoTxt = mobileNo.getText().toString();
            String emailTxt = email.getText().toString();

            call = new ShareACarApiService(getActivity()).getShareACarApi().updateUserInfo(userId + "", firstNameTxt, lastNameTxt, emailTxt, mobileNoTxt);
            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    if ((progress != null) && progress.isShowing()) {
                        progress.dismiss();
                    }
                    if (response.code() == 200) {
                        try {
                            result = response.body().string();
                            final String resultArray[] = result.split("::");

                            TSnackbar snackbar = TSnackbar
                                    .make(getView(), resultArray[1], TSnackbar.LENGTH_SHORT);
                            snackbar.setActionTextColor(Color.WHITE);
                            View snackbarView = snackbar.getView();
                            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                            textView.setTextColor(Color.WHITE);
                            textView.setTypeface(Typeface.DEFAULT_BOLD);
                            snackbar.show();

                                /*new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {

                                            Thread.sleep(2000);
                                            // Do some stuff
                                            if(resultArray[0].equalsIgnoreCase("Success")) {
                                                Intent it = new Intent(getActivity().getApplicationContext(), HomePage.class);
                                                startActivity(it);
                                            }

                                        } catch (Exception e) {
                                            e.getLocalizedMessage();
                                        }
                                    }
                                }).start();*/

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else {
                        TSnackbar snackbar = TSnackbar
                                .make(getView(), "Can't connect to server", TSnackbar.LENGTH_LONG);
                        snackbar.setActionTextColor(Color.WHITE);
                        View snackbarView = snackbar.getView();
                        snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                        textView.setTextColor(Color.WHITE);
                        textView.setTypeface(Typeface.DEFAULT_BOLD);
                        snackbar.show();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    if ((progress != null) && progress.isShowing()) {
                        progress.dismiss();
                    }
                    TSnackbar snackbar = TSnackbar
                            .make(getView(), "Please check your connection", TSnackbar.LENGTH_LONG);
                    snackbar.setActionTextColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                    textView.setTextColor(Color.WHITE);
                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                    snackbar.show();
                }
            });
        }
    }

    public boolean valid(View view) {

        boolean valid = true;
        String firstNameTxt = firstName.getText().toString();
        String lastNameTxt = lastName.getText().toString();
        String mobileNoTxt = mobileNo.getText().toString();

        String emailTxt = email.getText().toString();

        if (firstNameTxt.isEmpty() || firstNameTxt.length() < 1) {
            if ((progress != null) && progress.isShowing()) {
                progress.dismiss();
            }
            TSnackbar snackbar = TSnackbar
                    .make(getView(), "Please enter first name", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
        } else if (lastNameTxt.isEmpty() || lastNameTxt.length() < 1) {
            if ((progress != null) && progress.isShowing()) {
                progress.dismiss();
            }
            TSnackbar snackbar = TSnackbar
                    .make(getView(), "Please enter last name", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
        } else if (emailTxt.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(emailTxt).matches()) {
            if ((progress != null) && progress.isShowing()) {
                progress.dismiss();
            }
            TSnackbar snackbar = TSnackbar
                    .make(getView(), "Please enter valid email", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();
            valid = false;
        } else if (mobileNoTxt.isEmpty() || !mobileNoTxt.matches("[0-9]+") || mobileNoTxt.length() != 10) {
            if ((progress != null) && progress.isShowing()) {
                progress.dismiss();
            }
            TSnackbar snackbar = TSnackbar
                    .make(getView(), "Please enter valid mobile number", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
        }
        return valid;
    }

    @Override
    public void onResume() {
        textviewTitle = (TextView) getActivity().findViewById(R.id.textviewTitle);
        if (textviewTitle.getVisibility() == View.GONE)
            textviewTitle.setVisibility(View.VISIBLE);
        textviewTitle.setText("Personal Information");

        header = (ImageView) getActivity().findViewById(R.id.tv_header_title);
        if (header.getVisibility() == View.VISIBLE)
            header.setVisibility(View.GONE);

        shareRide = (ImageView) getActivity().findViewById(R.id.shareRide);
        if (shareRide.getVisibility() == View.VISIBLE)
            shareRide.setVisibility(View.GONE);

        super.onResume();
    }
}
