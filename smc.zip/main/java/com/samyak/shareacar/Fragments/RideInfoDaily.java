package com.samyak.shareacar.Fragments;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import com.androidadvance.topsnackbar.TSnackbar;
import com.samyak.shareacar.BeforeLogin.Main;
import com.samyak.shareacar.Helpers.ExpandableLayout;
import com.samyak.shareacar.Models.StopageInformation;
import com.samyak.shareacar.Models.UpdateDailyRideBean;
import com.samyak.shareacar.Models.UserRideInfoBean;
import com.samyak.shareacar.R;
import com.samyak.shareacar.RetrofitApi.ShareACarApiService;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RideInfoDaily extends Fragment {

    public static boolean refresh = false;
    ImageView header;
    ImageView shareRide;
    UserRideInfoBean rideBean;
    LinearLayout[] stopageInformationLayouts = new LinearLayout[6];
    TextView stopageCityNames[] = new TextView[6];
    TextView stopageCityPrice[] = new TextView[6];
    Button stopageDeleteButton[] = new Button[6];
    int stopageCityUpdatedRates[] = new int[6];
    RelativeLayout rlPrice1, rlPrice2, rlPrice3, rlPrice4, rlPrice5, rlPrice6;
    String dailyRideId;
    int userId = 0;
    String contactNo = null, emailId = null, userName = null;
    List<StopageInformation> stopageInformationBeanArrayList;
    LinearLayout.LayoutParams loparams;
    int fromDay = 0, fromMonth = 0, fromYear = 0;
    int toDay = 0, toMonth = 0, toYear = 0;
    String months[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    Call<ResponseBody> call;
    ArrayList<String> daysList = new ArrayList<String>();
    ArrayList<String> daysToBeUpdated = new ArrayList<String>();
    private LinearLayout llTitle, llStaticData, llDynamicData,
            llStoppageInfo, setDynamicSeatPrice, llStaticSeatPrice, llStaticMessage,
            llDynamicMesage, lleditablePricePerPerson, llStaticSeat, llStopageInfo;
    private LinearLayout rideListButton, myRideButton;
    private TextView textviewTitle, textviewFromDate, textviewToDate, textviewTime, textviewFromCity,
            textviewToCity, textviewCityNameTitle, textViewPriceTitle, textviewNoofSeats,
            textviewPrice, staticSeats, staticPrice, staticMessage, CarName,
            dummy, lblDelete, textviewDistance, textviewStaticDays;
    private TextView edittextFromDate, edittextTime, edittextToDate;
    private ImageView imageviewMinusPrice1, imageviewPlusPrice1;
    private ImageView imageviewMinusPrice2, imageviewPlusPrice2;
    private ImageView imageviewMinusPrice3, imageviewPlusPrice3;
    private ImageView imageviewMinusPrice4, imageviewPlusPrice4;
    private ImageView imageviewMinusPrice5, imageviewPlusPrice5;
    private ImageView imageviewMinusPrice6, imageviewPlusPrice6;
    private ImageView imageviewPlusPrice, imageviewMinusPrice;
    private ImageView imageviewPlus, imageviewMinus;
    private ExpandableLayout expandablelayout;
    private EditText edittextMessage;
    private Button editRide, deleteRide, callRideOwner, emailRideOwner;
    private ProgressDialog progress;
    private int hours = 0, minutes = 0;
    private String fromDateTxt, toDateTxt;
    private TextView ttMon, ttTue, ttWed, ttThr, ttFri, ttSat, ttSun;
    private CheckBox checkboxSun, checkboxMon, checkboxWed, checkboxTue, checkboxThr, checkboxFri, checkboxSat;

    public RideInfoDaily() {
        // Required empty public constructor
    }

    public static int daysBetween(Calendar day1, Calendar day2) {
        Calendar dayOne = (Calendar) day1.clone(),
                dayTwo = (Calendar) day2.clone();

        if (dayOne.get(Calendar.YEAR) == dayTwo.get(Calendar.YEAR)) {
            return Math.abs(dayOne.get(Calendar.DAY_OF_YEAR) - dayTwo.get(Calendar.DAY_OF_YEAR));
        } else {
            if (dayTwo.get(Calendar.YEAR) > dayOne.get(Calendar.YEAR)) {
                //swap them
                Calendar temp = dayOne;
                dayOne = dayTwo;
                dayTwo = temp;
            }
            int extraDays = 0;

            int dayOneOriginalYearDays = dayOne.get(Calendar.DAY_OF_YEAR);

            while (dayOne.get(Calendar.YEAR) > dayTwo.get(Calendar.YEAR)) {
                dayOne.add(Calendar.YEAR, -1);
                // getActualMaximum() important for leap years
                extraDays += dayOne.getActualMaximum(Calendar.DAY_OF_YEAR);
            }
            return extraDays - dayTwo.get(Calendar.DAY_OF_YEAR) + dayOneOriginalYearDays;
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_ride_info_daily, container, false);

        Log.e("Ride Info Daily", " Called");

        shareRide = (ImageView) getActivity().findViewById(R.id.shareRide);

        llTitle = (LinearLayout) view.findViewById(R.id.llTitle);
        llStaticData = (LinearLayout) view.findViewById(R.id.llStaticData);
        llDynamicData = (LinearLayout) view.findViewById(R.id.llDynamicData);
        llStoppageInfo = (LinearLayout) view.findViewById(R.id.llStoppageInfo);
        setDynamicSeatPrice = (LinearLayout) view.findViewById(R.id.setDynamicSeatPrice);
        llStaticSeatPrice = (LinearLayout) view.findViewById(R.id.llStaticSeatPrice);
        llStaticMessage = (LinearLayout) view.findViewById(R.id.llStaticMessage);
        llDynamicMesage = (LinearLayout) view.findViewById(R.id.llDynamicMesage);
        rideListButton = (LinearLayout) view.findViewById(R.id.layout_button);
        myRideButton = (LinearLayout) view.findViewById(R.id.layout_view_ride_button);
        lleditablePricePerPerson = (LinearLayout) view.findViewById(R.id.layout_ride_price_details);
        llStaticSeat = (LinearLayout) view.findViewById(R.id.layout_available_seats);
        llStopageInfo = (LinearLayout) view.findViewById(R.id.layout_stopage_information);

        //stopages
        stopageInformationLayouts[0] = (LinearLayout) view.findViewById(R.id.layout_stopage_info_1);
        stopageInformationLayouts[1] = (LinearLayout) view.findViewById(R.id.layout_stopage_info_2);
        stopageInformationLayouts[2] = (LinearLayout) view.findViewById(R.id.layout_stopage_info_3);
        stopageInformationLayouts[3] = (LinearLayout) view.findViewById(R.id.layout_stopage_info_4);
        stopageInformationLayouts[4] = (LinearLayout) view.findViewById(R.id.layout_stopage_info_5);
        stopageInformationLayouts[5] = (LinearLayout) view.findViewById(R.id.layout_stopage_info_6);

        textviewTitle = (TextView) view.findViewById(R.id.textviewTitle);
        textviewFromDate = (TextView) view.findViewById(R.id.textviewFromDate);
        textviewToDate = (TextView) view.findViewById(R.id.textviewToDate);
        textviewTime = (TextView) view.findViewById(R.id.textviewTime);
        textviewFromCity = (TextView) view.findViewById(R.id.textviewFromCity);
        textviewToCity = (TextView) view.findViewById(R.id.textviewToCity);
        textviewNoofSeats = (TextView) view.findViewById(R.id.textviewNoofSeats);
        textviewPrice = (TextView) view.findViewById(R.id.textviewPrice);
        staticSeats = (TextView) view.findViewById(R.id.lbl_available_seats);
        staticPrice = (TextView) view.findViewById(R.id.lbl_price_per_person);
        staticMessage = (TextView) view.findViewById(R.id.lbl_ride_message);
        textviewStaticDays = (TextView) view.findViewById(R.id.textviewStaticDays);

        textviewDistance = (TextView) view.findViewById(R.id.lbl_distance);
        CarName = (TextView) view.findViewById(R.id.CarName);

        //stopages
        textviewCityNameTitle = (TextView) view.findViewById(R.id.textviewCityNameTitle);
        textViewPriceTitle = (TextView) view.findViewById(R.id.textViewPriceTitle);

        stopageCityNames[0] = (TextView) view.findViewById(R.id.input_stopage_1);
        stopageCityNames[1] = (TextView) view.findViewById(R.id.input_stopage_2);
        stopageCityNames[2] = (TextView) view.findViewById(R.id.input_stopage_3);
        stopageCityNames[3] = (TextView) view.findViewById(R.id.input_stopage_4);
        stopageCityNames[4] = (TextView) view.findViewById(R.id.input_stopage_5);
        stopageCityNames[5] = (TextView) view.findViewById(R.id.input_stopage_6);

        stopageCityPrice[0] = (TextView) view.findViewById(R.id.input_price_stopage_1);
        stopageCityPrice[1] = (TextView) view.findViewById(R.id.input_price_stopage_2);
        stopageCityPrice[2] = (TextView) view.findViewById(R.id.input_price_stopage_3);
        stopageCityPrice[3] = (TextView) view.findViewById(R.id.input_price_stopage_4);
        stopageCityPrice[4] = (TextView) view.findViewById(R.id.input_price_stopage_5);
        stopageCityPrice[5] = (TextView) view.findViewById(R.id.input_price_stopage_6);

        stopageDeleteButton[0] = (Button) view.findViewById(R.id.btn_delete_stop_1);
        stopageDeleteButton[1] = (Button) view.findViewById(R.id.btn_delete_stop_2);
        stopageDeleteButton[2] = (Button) view.findViewById(R.id.btn_delete_stop_3);
        stopageDeleteButton[3] = (Button) view.findViewById(R.id.btn_delete_stop_4);
        stopageDeleteButton[4] = (Button) view.findViewById(R.id.btn_delete_stop_5);
        stopageDeleteButton[5] = (Button) view.findViewById(R.id.btn_delete_stop_6);

        //Relative
        rlPrice1 = (RelativeLayout) view.findViewById(R.id.rlPrice1);
        rlPrice2 = (RelativeLayout) view.findViewById(R.id.rlPrice2);
        rlPrice3 = (RelativeLayout) view.findViewById(R.id.rlPrice3);
        rlPrice4 = (RelativeLayout) view.findViewById(R.id.rlPrice4);
        rlPrice5 = (RelativeLayout) view.findViewById(R.id.rlPrice5);
        rlPrice6 = (RelativeLayout) view.findViewById(R.id.rlPrice6);

        edittextFromDate = (TextView) view.findViewById(R.id.edittextFromDate);
        edittextTime = (TextView) view.findViewById(R.id.edittextTime);
        edittextToDate = (TextView) view.findViewById(R.id.edittextToDate);

        dummy = (TextView) view.findViewById(R.id.dummy);
        lblDelete = (TextView) view.findViewById(R.id.lbl_delete);

        //stopages
        imageviewPlusPrice1 = (ImageView) view.findViewById(R.id.imageviewPlusPrice1);
        imageviewPlusPrice2 = (ImageView) view.findViewById(R.id.imageviewPlusPrice2);
        imageviewPlusPrice3 = (ImageView) view.findViewById(R.id.imageviewPlusPrice3);
        imageviewPlusPrice4 = (ImageView) view.findViewById(R.id.imageviewPlusPrice4);
        imageviewPlusPrice5 = (ImageView) view.findViewById(R.id.imageviewPlusPrice5);
        imageviewPlusPrice6 = (ImageView) view.findViewById(R.id.imageviewPlusPrice6);

        imageviewMinusPrice1 = (ImageView) view.findViewById(R.id.imageviewMinusPrice1);
        imageviewMinusPrice2 = (ImageView) view.findViewById(R.id.imageviewMinusPrice2);
        imageviewMinusPrice3 = (ImageView) view.findViewById(R.id.imageviewMinusPrice3);
        imageviewMinusPrice4 = (ImageView) view.findViewById(R.id.imageviewMinusPrice4);
        imageviewMinusPrice5 = (ImageView) view.findViewById(R.id.imageviewMinusPrice5);
        imageviewMinusPrice6 = (ImageView) view.findViewById(R.id.imageviewMinusPrice6);

        imageviewPlusPrice = (ImageView) view.findViewById(R.id.imageviewPlusPrice);
        imageviewMinusPrice = (ImageView) view.findViewById(R.id.imageviewMinusPrice);
        imageviewPlus = (ImageView) view.findViewById(R.id.imageviewPlus);
        imageviewMinus = (ImageView) view.findViewById(R.id.imageviewMinus);

        ttMon = (TextView) view.findViewById(R.id.ttMon);
        ttTue = (TextView) view.findViewById(R.id.ttTue);
        ttWed = (TextView) view.findViewById(R.id.ttWed);
        ttThr = (TextView) view.findViewById(R.id.ttThr);
        ttFri = (TextView) view.findViewById(R.id.ttFri);
        ttSat = (TextView) view.findViewById(R.id.ttSat);
        ttSun = (TextView) view.findViewById(R.id.ttSun);

        checkboxSun = (CheckBox) view.findViewById(R.id.checkboxSun);
        checkboxMon = (CheckBox) view.findViewById(R.id.checkboxMon);
        checkboxTue = (CheckBox) view.findViewById(R.id.checkboxTue);
        checkboxWed = (CheckBox) view.findViewById(R.id.checkboxWed);
        checkboxThr = (CheckBox) view.findViewById(R.id.checkboxThr);
        checkboxFri = (CheckBox) view.findViewById(R.id.checkboxFri);
        checkboxSat = (CheckBox) view.findViewById(R.id.checkboxSat);

        expandablelayout = (ExpandableLayout) view.findViewById(R.id.expandablelayout);

        edittextMessage = (EditText) view.findViewById(R.id.edittextMessage);

        //buttons
        editRide = (Button) view.findViewById(R.id.btn_edit_ride);
        deleteRide = (Button) view.findViewById(R.id.btn_delete_ride);
        callRideOwner = (Button) view.findViewById(R.id.btn_call_ride_owner);
        emailRideOwner = (Button) view.findViewById(R.id.btn_email_ride_owner);

        Bundle args = getArguments();
        rideBean = args.getParcelable("rideBean");
        dailyRideId = rideBean.getRideId();

        view.findViewById(R.id.expandMe).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        expandablelayout.toggleExpansion();
                    }
                });

        SQLiteDatabase mydatabase = getActivity().openOrCreateDatabase("shareACar", getActivity().MODE_PRIVATE, null);
        mydatabase.execSQL("CREATE TABLE IF NOT EXISTS loginInfo(userId INTEGER ,carId INTEGER , contactNo TEXT , emailId TEXT, userName TEXT);");
        Cursor c = mydatabase.rawQuery("Select * from loginInfo", null);
        if (c != null) {
            if (c.moveToFirst()) {
                do {
                    userId = c.getInt(c.getColumnIndex("userId"));
                    contactNo = c.getString(c.getColumnIndex("contactNo"));
                    emailId = c.getString(c.getColumnIndex("emailId"));
                    userName = c.getString(c.getColumnIndex("userName"));
                } while (c.moveToNext());
            }
        } else {
            Intent intent = new Intent(getActivity(), Main.class);
            startActivity(intent);
        }
        if (userId == 0) {
            Intent intent = new Intent(getActivity(), Main.class);
            startActivity(intent);
        }

        getDaysList();

        if (rideBean.getStatus() == 1) { //if approved
            llDynamicData.setVisibility(View.GONE); //hide editable dates and time
            disappearButtons(); //hide stopage price change buttons
            lleditablePricePerPerson.setVisibility(View.INVISIBLE);
            llStaticSeat.setVisibility(View.GONE);
            llDynamicMesage.setVisibility(View.GONE);
            myRideButton.setVisibility(View.GONE);  //fide call and email buttons
            textviewTitle.setText("Active");
            lblDelete.setVisibility(View.GONE);

            if (shareRide.getVisibility() == View.GONE)
                shareRide.setVisibility(View.VISIBLE);
        } else if (rideBean.getIsDeleted() != 1 && !rideBean.getRideViewType().equalsIgnoreCase("rideList") && !rideBean.getIsExpired()) {
            llTitle.setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.yellow));
            textviewTitle.setText("Pending for Approval");
            llStaticData.setVisibility(View.GONE); //hide editable dates and time
            llStaticSeatPrice.setVisibility(View.GONE); //ll static price and seat
            llStaticMessage.setVisibility(View.GONE);
            myRideButton.setVisibility(View.GONE);  //fide call and email buttons

            if (shareRide.getVisibility() == View.VISIBLE)
                shareRide.setVisibility(View.GONE);

            textviewCityNameTitle.setGravity(Gravity.CENTER);
            for (int i = 0; i < 6; i++) {
                stopageCityNames[i].setGravity(Gravity.CENTER);
            }
        }

        if (rideBean.getIsDeleted() == 1) {
            llTitle.setBackgroundColor(Color.RED);
            textviewTitle.setText("Deleted");
            llDynamicData.setVisibility(View.GONE); //hide editable dates and time
            setDynamicSeatPrice.setVisibility(View.GONE);
            llDynamicMesage.setVisibility(View.GONE);
            disappearButtons();

            if (shareRide.getVisibility() == View.VISIBLE)
                shareRide.setVisibility(View.GONE);

            editRide.setVisibility(View.GONE);
            deleteRide.setText("Put Back");
            lblDelete.setVisibility(View.GONE);

            //show single button in center
            LinearLayout.LayoutParams loparams = (LinearLayout.LayoutParams) dummy.getLayoutParams();
            loparams.weight = 0;
            dummy.setLayoutParams(loparams);
        }

        if (rideBean.getRideViewType().equalsIgnoreCase("findride")) {
            llTitle.setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.green));
            textviewTitle.setText("Have your seat booked");
            disappearButtons();
            llDynamicData.setVisibility(View.GONE); //hide editable dates and time
            setDynamicSeatPrice.setVisibility(View.GONE);
            llDynamicMesage.setVisibility(View.GONE);

            if (shareRide.getVisibility() == View.GONE)
                shareRide.setVisibility(View.VISIBLE);

            rideListButton.setVisibility(View.GONE);

        } else {
            myRideButton.setVisibility(View.GONE);
            llStopageInfo.setVisibility(View.GONE);
        }

        stopageInformationBeanArrayList = rideBean.getStopageInformation();

        if (Integer.parseInt(rideBean.getNoOfStops()) == 0) {
            llStoppageInfo.setVisibility(View.GONE);
        }

        if (Integer.parseInt(rideBean.getNoOfStops()) > 0 && !rideBean.getRideViewType().equalsIgnoreCase("findride")) {
            llStopageInfo.setVisibility(View.VISIBLE);

            for (int i = 0; i <= Integer.parseInt(rideBean.getNoOfStops()); i++) {

                stopageInformationLayouts[i].setVisibility(View.VISIBLE);
                stopageCityNames[i].setText(stopageInformationBeanArrayList.get(i).getStopageFromPlaceName() + " - " +
                        stopageInformationBeanArrayList.get(i).getStopageToPlaceName());
                stopageCityPrice[i].setText("\u20B9" + stopageInformationBeanArrayList.get(i).getPricePerPerson());
                final int finalI = i;
                stopageDeleteButton[i].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        progress = new ProgressDialog(getActivity(), R.style.appThemeDialogue);
                        progress.setMessage("Please Wait...");
                        progress.show();
                        deleteStopage(stopageInformationBeanArrayList.get(finalI).getStopageId());
                    }
                });
                if (rideBean.getStatus() == 1 || rideBean.getIsDeleted() == 1 || rideBean.getIsExpired()) {
//                    System.out.println("In if condition");
                    stopageCityPrice[i].setEnabled(false);
                    stopageDeleteButton[i].setVisibility(View.GONE);
                    lblDelete.setVisibility(View.GONE);

                    loparams = (LinearLayout.LayoutParams) textviewCityNameTitle.getLayoutParams();
                    loparams.weight = 2f;
                    loparams = (LinearLayout.LayoutParams) stopageCityNames[0].getLayoutParams();
                    loparams.weight = 2f;
                    loparams = (LinearLayout.LayoutParams) stopageCityNames[1].getLayoutParams();
                    loparams.weight = 2f;
                    loparams = (LinearLayout.LayoutParams) stopageCityNames[2].getLayoutParams();
                    loparams.weight = 2f;
                    loparams = (LinearLayout.LayoutParams) stopageCityNames[3].getLayoutParams();
                    loparams.weight = 2f;
                    loparams = (LinearLayout.LayoutParams) stopageCityNames[4].getLayoutParams();
                    loparams.weight = 2f;
                    loparams = (LinearLayout.LayoutParams) stopageCityNames[5].getLayoutParams();
                    loparams.weight = 2f;

                    loparams = (LinearLayout.LayoutParams) textViewPriceTitle.getLayoutParams();
                    loparams.weight = 1f;
                    loparams = (LinearLayout.LayoutParams) rlPrice1.getLayoutParams();
                    loparams.weight = 1f;
                    loparams = (LinearLayout.LayoutParams) rlPrice2.getLayoutParams();
                    loparams.weight = 1f;
                    loparams = (LinearLayout.LayoutParams) rlPrice3.getLayoutParams();
                    loparams.weight = 1f;
                    loparams = (LinearLayout.LayoutParams) rlPrice4.getLayoutParams();
                    loparams.weight = 1f;
                    loparams = (LinearLayout.LayoutParams) rlPrice5.getLayoutParams();
                    loparams.weight = 1f;
                    loparams = (LinearLayout.LayoutParams) rlPrice6.getLayoutParams();
                    loparams.weight = 1f;
                }
            }

            for (int i = Integer.parseInt(rideBean.getNoOfStops()) + 1; i < 6; i++) {
                stopageInformationLayouts[i].setVisibility(View.GONE);
            }

        } else if (Integer.parseInt(rideBean.getNoOfStops()) == 0 || rideBean.getRideViewType().equalsIgnoreCase("rideList")) {
            llStopageInfo.setVisibility(View.GONE);
        }

        textviewFromCity.setText(rideBean.getFromCity());
        textviewToCity.setText(rideBean.getToCity());

        textviewPrice.setText("\u20B9" + rideBean.getPricePerPerson());

        Date fromDate = null, toDate = null;
        SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        try {
            fromDate = df1.parse(rideBean.getDatetimeOfDeparture());
            textviewFromDate.setText(new SimpleDateFormat("dd MMM yyyy", Locale.US).format(fromDate));
            edittextFromDate.setText(new SimpleDateFormat("dd MMM yyyy", Locale.US).format(fromDate));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        try {
            toDate = df1.parse(rideBean.getDatetimeOfArival());
            textviewToDate.setText(new SimpleDateFormat("dd MMM yyyy", Locale.US).format(toDate));
            edittextToDate.setText(new SimpleDateFormat("dd MMM yyyy", Locale.US).format(toDate));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String fromDateArray[] = rideBean.getDatetimeOfDeparture().split("-");
        fromDay = Integer.parseInt(fromDateArray[2]);
        fromMonth = Integer.parseInt(fromDateArray[1]) - 1;
        fromYear = Integer.parseInt(fromDateArray[0]);
        fromDateTxt = fromDateArray[2] + "-" + fromDateArray[1] + "-" + fromDateArray[0];

        String toDateArray[] = rideBean.getDatetimeOfArival().split("-");
        toDay = Integer.parseInt(toDateArray[2]);
        toMonth = Integer.parseInt(toDateArray[1]) - 1;
        toYear = Integer.parseInt(toDateArray[0]);
        toDateTxt = toDateArray[2] + "-" + toDateArray[1] + "-" + toDateArray[0];

        String time1 = rideBean.getTimeDaily();
        String[] finalTime = time1.split(":");
        hours = Integer.parseInt(finalTime[0]);
        minutes = Integer.parseInt(finalTime[1]);

        textviewTime.setText(finalTime[0] + ":" + finalTime[1]);
        edittextTime.setText(finalTime[0] + ":" + finalTime[1]);

        textviewPrice.setText("\u20B9" + rideBean.getPricePerPerson());
        staticPrice.setText("\u20B9" + rideBean.getPricePerPerson() + "/Seat");

        staticSeats.setText(Integer.toString(rideBean.getNoOfSeatsAvailable()));
        textviewNoofSeats.setText(Integer.toString(rideBean.getNoOfSeatsAvailable()));

        textviewDistance.setText(rideBean.getDistance() + " km");
        staticMessage.setText(rideBean.getRideMessage());
        edittextMessage.setText(rideBean.getRideMessage());
        CarName.setText(rideBean.getCarName());

        if (Integer.parseInt(textviewNoofSeats.getText().toString()) <= 1) {
            imageviewMinus.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinus.setEnabled(false);
        }

        if (Integer.parseInt(textviewNoofSeats.getText().toString()) > 1) {
            imageviewMinus.setImageResource(R.drawable.ic_minus);
            imageviewMinus.setEnabled(true);
        }

        imageviewPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = Integer.parseInt(textviewNoofSeats.getText().toString());
                textviewNoofSeats.setText("" + (i + 1));

                if (Integer.parseInt(textviewNoofSeats.getText().toString()) > 1) {
                    imageviewMinus.setImageResource(R.drawable.ic_minus);
                    imageviewMinus.setEnabled(true);
                }

                if (Integer.parseInt(textviewNoofSeats.getText().toString()) >= 8) {
                    imageviewPlus.setImageResource(R.drawable.ic_plus_disable);
                    imageviewPlus.setEnabled(false);
                }
            }
        });

        imageviewMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = Integer.parseInt(textviewNoofSeats.getText().toString());
                textviewNoofSeats.setText("" + (i - 1));

                if (Integer.parseInt(textviewNoofSeats.getText().toString()) < 8) {
                    imageviewPlus.setImageResource(R.drawable.ic_plus);
                    imageviewPlus.setEnabled(true);
                }

                if (Integer.parseInt(textviewNoofSeats.getText().toString()) <= 1) {
                    imageviewMinus.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinus.setEnabled(false);
                }
            }
        });

        //total price per co-traveller

        if (Integer.parseInt(textviewPrice.getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice.setEnabled(true);
        }

        if (Integer.parseInt(textviewPrice.getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice.setEnabled(false);
        }

        imageviewPlusPrice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                increaseStopagePrice(textviewPrice);

                if (Integer.parseInt(textviewPrice.getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                decreaseStopagePrice(textviewPrice);

                if (Integer.parseInt(textviewPrice.getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice.setEnabled(false);
                }
            }
        });

        setPrices();

        setTimeListener();

        setFromDateListener();

        setToDateListener();

        editRide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //close keyboard
                InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }

                refresh = true;

                progress = new ProgressDialog(getActivity(), R.style.appThemeDialogue);
                progress.setMessage("Please Wait...");
                progress.setCancelable(false);
                progress.show();

                updateRates();

                String[] parts = textviewPrice.getText().toString().split("\u20B9");

                List<Integer> stopageRates = new ArrayList<Integer>();
                for (int index = 0; index < stopageCityUpdatedRates.length; index++) {
                    stopageRates.add(stopageCityUpdatedRates[index]);
                }

                setDaysListToSend();

                UpdateDailyRideBean dailyRideBean = new UpdateDailyRideBean();
                dailyRideBean.setDailyRideId(dailyRideId);
                dailyRideBean.setFromDailyDate(fromDateTxt);
                dailyRideBean.setToDailyDate(toDateTxt);
                dailyRideBean.setDailyTime(edittextTime.getText().toString());
                dailyRideBean.setPricePerPerson(parts[1].trim());
                dailyRideBean.setDaysList(daysToBeUpdated);
                dailyRideBean.setNoOfPersonAvailable(textviewNoofSeats.getText().toString());
                dailyRideBean.setRideMessage(edittextMessage.getText().toString().trim());
                dailyRideBean.setFinalRates(stopageRates);

                if (lblDelete.getVisibility() == View.VISIBLE) {
                    if (valid()) {
                        updateCall(dailyRideBean);
                    }
                } else {
                    updateCall(dailyRideBean);
                }

            }

        });

        deleteRide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //close keyboard
                InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }
                refresh = true;
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("Alert!");
                //builder.setIcon(R.drawable.icon);
                if (rideBean.getIsExpired()) {
                    builder.setMessage("Do you want to remove this ride from list?");
                } else if (rideBean.getIsDeleted() == 1) {
                    builder.setMessage("Do you want to put back this ride?");
                } else {
                    builder.setMessage("Do you want to delete this ride?");
                }

                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();

                        call = new ShareACarApiService(getActivity()).getShareACarApi().deleteDailyRide(dailyRideId);
                        call.enqueue(new Callback<ResponseBody>() {
                            @Override
                            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                                if (response.code() == 200) {
                                    try {
                                        if(getView() != null) {
                                            rideDeleted(response.body().string());
                                        }
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                } else {
                                    TSnackbar snackbar = TSnackbar
                                            .make(getView(), "Can't connect to server", TSnackbar.LENGTH_LONG);
                                    snackbar.setActionTextColor(Color.WHITE);
                                    View snackbarView = snackbar.getView();
                                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                                    textView.setTextColor(Color.WHITE);
                                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                                    snackbar.show();
                                }
                            }

                            @Override
                            public void onFailure(Call<ResponseBody> call, Throwable t) {
                                TSnackbar snackbar = TSnackbar
                                        .make(getView(), "Please check your connection", TSnackbar.LENGTH_LONG);
                                snackbar.setActionTextColor(Color.WHITE);
                                View snackbarView = snackbar.getView();
                                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                                textView.setTextColor(Color.WHITE);
                                textView.setTypeface(Typeface.DEFAULT_BOLD);
                                snackbar.show();
                            }
                        });

                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                builder.create().show();
            }
        });

        /*callRideOwner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                String phoneNo = rideBean.getMobileNo();
                callIntent.setData(Uri.parse("tel:" + phoneNo));
                startActivity(callIntent);
            }
        });*/

        /*emailRideOwner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + rideBean.getEmailId()));

                intent.putExtra(Intent.EXTRA_SUBJECT, "Want to share ride with you.");
                String mailBody = "Dear " + rideBean.getUserName() + ",<br><br>";
//                mailBody = mailBody + "I found your details on Share Ur Car Application.I want to be on your ride, from " + rideBean.getFromCity() + " to " + rideBean.getToCity()
//                        + " on " + finalDate + " " + time[0] + ":" + time[1] + ".";
                mailBody = mailBody + "<br><br>";
                mailBody = mailBody + "My contact details are as following : <br>";
                mailBody = mailBody + "Contact No : <a href='tel:" + contactNo + "'>" + contactNo + "</a><br>";
                mailBody = mailBody + "Email Id: <a href='mailto:" + emailId + "'>" + emailId + "</a><br><br>";
                mailBody = mailBody + "Thank You, <br>" + userName + "";
                intent.putExtra(Intent.EXTRA_TEXT, Html.fromHtml(mailBody));
                startActivity(Intent.createChooser(intent, "Send email..."));
            }
        });*/

        shareRide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                makeFileToShare();

//                ApplicationInfo app = getActivity().getApplicationContext().getApplicationInfo();
//                filePath = getActivity().getExternalFilesDir(null).getPath() + File.separator + "ridedetails.txt";

                String time[] = rideBean.getTimeDaily().split(":");

                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
                try {
                    sendIntent.putExtra(Intent.EXTRA_TEXT, "Hey Check out this ShareUrCar ride from " + rideBean.getFromCity() + " to " + rideBean.getToCity()
                            + " for ₹ " + rideBean.getPricePerPerson() + " available from " + new SimpleDateFormat("EEE dd MMM yyyy", Locale.US).format(sdf1.parse(rideBean.getDatetimeOfDeparture()))
                            + " to " + new SimpleDateFormat("EEE dd MMM yyyy", Locale.US).format(sdf1.parse(rideBean.getDatetimeOfArival())) + " at " + time[0] + ":" + time[1]
                            + ".\n\nShared from the ShareUrCar Android App - get it here: \n https://play.google.com/store/apps/details?id=com.samyak.shareurcar&hl=en");
                } catch (ParseException e) {
                    e.printStackTrace();
                }
//                sendIntent.setType("*/*");
                sendIntent.setType("text/plain");

                PackageManager pm = getActivity().getPackageManager();
                List<ResolveInfo> resInfo = pm.queryIntentActivities(sendIntent, 0);

                for (int i = 0; i < resInfo.size(); i++) {
                    ResolveInfo ri = resInfo.get(i);
                    String packageName = ri.activityInfo.packageName;

                    if (packageName.contains("android.email") || packageName.contains("android.gm")) {
                        sendIntent.putExtra(Intent.EXTRA_SUBJECT, "Check out this ShareUrCar ride from " + rideBean.getFromCity() + " to " + rideBean.getToCity());
                    } else if (packageName.contains("xender")) {
//                        sendIntent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new File(filePath)));
                    }
                }
                getActivity().startActivity(sendIntent);
            }
        });

        return view;
    }

    private void updateRates() {

        /*int total = Integer.parseInt(stopageCityPrice[0].getText().toString().replace("\u20B9","")) +
                Integer.parseInt(stopageCityPrice[1].getText().toString().replace("\u20B9","")) +
                Integer.parseInt(stopageCityPrice[2].getText().toString().replace("\u20B9","")) +
                Integer.parseInt(stopageCityPrice[3].getText().toString().replace("\u20B9","")) +
                Integer.parseInt(stopageCityPrice[4].getText().toString().replace("\u20B9","")) +
                Integer.parseInt(stopageCityPrice[5].getText().toString().replace("\u20B9",""));*/

        stopageCityUpdatedRates[0] = Integer.parseInt(stopageCityPrice[0].getText().toString().replace("\u20B9", "").trim());
        stopageCityUpdatedRates[1] = Integer.parseInt(stopageCityPrice[1].getText().toString().replace("\u20B9", "").trim());
        stopageCityUpdatedRates[2] = Integer.parseInt(stopageCityPrice[2].getText().toString().replace("\u20B9", "").trim());
        stopageCityUpdatedRates[3] = Integer.parseInt(stopageCityPrice[3].getText().toString().replace("\u20B9", "").trim());
        stopageCityUpdatedRates[4] = Integer.parseInt(stopageCityPrice[4].getText().toString().replace("\u20B9", "").trim());
        stopageCityUpdatedRates[5] = Integer.parseInt(stopageCityPrice[5].getText().toString().replace("\u20B9", "").trim());

       /* Log.e(LOG,"stopageCityUpdatedRates0" + stopageCityUpdatedRates[0]);
        Log.e(LOG,"stopageCityUpdatedRates1" + stopageCityUpdatedRates[1]);
        Log.e(LOG,"stopageCityUpdatedRates2" + stopageCityUpdatedRates[2]);
        Log.e(LOG,"stopageCityUpdatedRates3" + stopageCityUpdatedRates[3]);
        Log.e(LOG,"stopageCityUpdatedRates4" + stopageCityUpdatedRates[4]);
        Log.e(LOG,"stopageCityUpdatedRates5" + stopageCityUpdatedRates[5]);*/

//        pricePerPerson.setText("\u20B9" + total);
    }

    private void setPrices() {

        //no 1
        if (Integer.parseInt(stopageCityPrice[0].getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice1.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice1.setEnabled(true);
        }

        if (Integer.parseInt(stopageCityPrice[0].getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice1.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice1.setEnabled(false);
        }

        imageviewPlusPrice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*int i = Integer.parseInt(stopageCityPrice[0].getText().toString().replace("\u20B9", ""));
                int j = i / 10;
                int rounded = j * 10;
                stopageCityPrice[0].setText("\u20B9" + (rounded + 10));*/

                increaseStopagePrice(stopageCityPrice[0]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[0].getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice1.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice1.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* int i = Integer.parseInt(stopageCityPrice[0].getText().toString().replace("\u20B9", ""));
                int j = i / 10;
                int rounded = j * 10;
                stopageCityPrice[0].setText("\u20B9" + (rounded - 10));*/

                decreaseStopagePrice(stopageCityPrice[0]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[0].getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice1.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice1.setEnabled(false);
                }
            }
        });

        //no 2
        if (Integer.parseInt(stopageCityPrice[1].getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice2.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice2.setEnabled(true);
        }

        if (Integer.parseInt(stopageCityPrice[1].getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice2.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice2.setEnabled(false);
        }

        imageviewPlusPrice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                increaseStopagePrice(stopageCityPrice[1]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[1].getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice2.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice2.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                decreaseStopagePrice(stopageCityPrice[1]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[1].getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice2.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice2.setEnabled(false);
                }
            }
        });

        //no 3
        if (Integer.parseInt(stopageCityPrice[2].getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice3.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice3.setEnabled(true);
        }

        if (Integer.parseInt(stopageCityPrice[2].getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice3.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice3.setEnabled(false);
        }

        imageviewPlusPrice3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                increaseStopagePrice(stopageCityPrice[2]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[2].getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice3.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice3.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                decreaseStopagePrice(stopageCityPrice[2]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[2].getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice3.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice3.setEnabled(false);
                }
            }
        });

        //no 4
        if (Integer.parseInt(stopageCityPrice[3].getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice4.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice4.setEnabled(true);
        }

        if (Integer.parseInt(stopageCityPrice[3].getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice4.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice4.setEnabled(false);
        }

        imageviewPlusPrice4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                increaseStopagePrice(stopageCityPrice[3]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[3].getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice4.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice4.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                decreaseStopagePrice(stopageCityPrice[3]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[3].getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice4.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice4.setEnabled(false);
                }
            }
        });

        //no 1
        if (Integer.parseInt(stopageCityPrice[4].getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice5.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice5.setEnabled(true);
        }

        if (Integer.parseInt(stopageCityPrice[4].getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice5.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice5.setEnabled(false);
        }

        imageviewPlusPrice5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                increaseStopagePrice(stopageCityPrice[4]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[4].getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice5.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice5.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                decreaseStopagePrice(stopageCityPrice[4]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[4].getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice5.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice5.setEnabled(false);
                }
            }
        });

        //no 6
        if (Integer.parseInt(stopageCityPrice[5].getText().toString().replace("\u20B9", "")) > 5) {
            imageviewMinusPrice6.setImageResource(R.drawable.ic_minus);
            imageviewMinusPrice6.setEnabled(true);
        }

        if (Integer.parseInt(stopageCityPrice[5].getText().toString().replace("\u20B9", "")) <= 5) {
            imageviewMinusPrice6.setImageResource(R.drawable.ic_minus_disable);
            imageviewMinusPrice6.setEnabled(false);
        }

        imageviewPlusPrice6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                increaseStopagePrice(stopageCityPrice[5]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[5].getText().toString().replace("\u20B9", "")) > 5) {
                    imageviewMinusPrice6.setImageResource(R.drawable.ic_minus);
                    imageviewMinusPrice6.setEnabled(true);
                }
            }
        });

        imageviewMinusPrice6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                decreaseStopagePrice(stopageCityPrice[5]);

                updateRates();

                if (Integer.parseInt(stopageCityPrice[5].getText().toString().replace("\u20B9", "")) <= 5) {
                    imageviewMinusPrice6.setImageResource(R.drawable.ic_minus_disable);
                    imageviewMinusPrice6.setEnabled(false);
                }
            }
        });
    }

    private void increaseStopagePrice(TextView t) {
        int i = Integer.parseInt(t.getText().toString().replace("\u20B9", ""));
        if (i % 5 == 0) {
            t.setText("\u20B9" + (i + 5));
        } else {
            if (i < 10) {
                int j = i % 5;
                int k = 5 - j;
                t.setText("\u20B9" + (i + k));
            } else {
                float j = i / 5;
                int rounded = (int) ((j / 2) * 10);
                t.setText("\u20B9" + (rounded + 5));
            }
        }
    }

    private void decreaseStopagePrice(TextView t) {
        int i = Integer.parseInt(t.getText().toString().replace("\u20B9", ""));
        if (i % 5 == 0) {
            t.setText("\u20B9" + (i - 5));
        } else {
            if (i < 10) {
                int j = i % 5;
                t.setText("\u20B9" + (i - j));
            } else {
                float j = i / 5;
                int rounded = (int) ((j / 2) * 10);
                t.setText("\u20B9" + (rounded));
            }
        }
    }

    private void disappearButtons() {
        imageviewPlusPrice1.setVisibility(View.GONE);
        imageviewPlusPrice2.setVisibility(View.GONE);
        imageviewPlusPrice3.setVisibility(View.GONE);
        imageviewPlusPrice4.setVisibility(View.GONE);
        imageviewPlusPrice5.setVisibility(View.GONE);
        imageviewPlusPrice6.setVisibility(View.GONE);

        imageviewMinusPrice1.setVisibility(View.GONE);
        imageviewMinusPrice2.setVisibility(View.GONE);
        imageviewMinusPrice3.setVisibility(View.GONE);
        imageviewMinusPrice4.setVisibility(View.GONE);
        imageviewMinusPrice5.setVisibility(View.GONE);
        imageviewMinusPrice6.setVisibility(View.GONE);
    }

    private void setFromDateListener() {
        edittextFromDate.setOnClickListener(new View.OnClickListener() {

            DatePickerDialog.OnDateSetListener ondate = new DatePickerDialog.OnDateSetListener() {

                public void onDateSet(DatePicker view, int year1, int monthOfYear,
                                      int dayOfMonth) {
                    fromDay = dayOfMonth;
                    fromMonth = monthOfYear;
                    fromYear = year1;
//                    journeyDate.setText(String.valueOf(dayOfMonth) + "-" + String.valueOf(monthOfYear + 1)
//                            + "-" + String.valueOf(year1));
                    edittextFromDate.setText(String.valueOf(dayOfMonth) + " " + months[monthOfYear]
                            + " " + String.valueOf(year1));
                    fromDateTxt = String.valueOf(dayOfMonth) + "-" + String.valueOf(monthOfYear + 1)
                            + "-" + String.valueOf(year1);
                    valid();

                    setDays();
                }
            };

            @Override
            public void onClick(View v) {

                DatePickerFragment date = new DatePickerFragment();
                Calendar calender = Calendar.getInstance();
                Bundle args = new Bundle();
                int thisDay = fromDay;
                int thisYear = fromYear;
                int thisMonth = fromMonth;
                if (thisDay == 0)
                    thisDay = calender.get(Calendar.DAY_OF_MONTH);
                if (thisYear == 0)
                    thisYear = calender.get(Calendar.YEAR);
                if (thisMonth == 0)
                    thisMonth = calender.get(Calendar.MONTH);
                args.putInt("year", thisYear);
                args.putInt("month", thisMonth);
                args.putInt("day", thisDay);
                args.putLong("minDate", calender.getTimeInMillis());
                calender.add(Calendar.DAY_OF_MONTH, 30);
                args.putLong("maxDate", calender.getTimeInMillis());

                if (!edittextToDate.getText().toString().matches("")) {
                    Date from = null;
                    try {
                        from = new SimpleDateFormat("dd MMM yyyy", Locale.US).parse(edittextToDate.getText().toString());
                        Calendar calendar1 = Calendar.getInstance();
                        calendar1.setTime(from);
                        if (calendar1.getTimeInMillis() < calender.getTimeInMillis()) {
                            args.putLong("maxDate", calendar1.getTimeInMillis());
                        } else {
                            args.putLong("maxDate", calender.getTimeInMillis());
                        }
                    } catch (ParseException e) {
                        e.printStackTrace();
                        calender.add(Calendar.DAY_OF_MONTH, 30);
                        args.putLong("maxDate", calender.getTimeInMillis());
                    }
                }

                date.setArguments(args);

                date.setCallBack(ondate);
                date.show(getFragmentManager(), "Date Picker");

            }
        });

        edittextFromDate.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            DatePickerDialog.OnDateSetListener ondate = new DatePickerDialog.OnDateSetListener() {

                public void onDateSet(DatePicker view, int year1, int monthOfYear,
                                      int dayOfMonth) {
                    fromDay = dayOfMonth;
                    fromMonth = monthOfYear;
                    fromYear = year1;
//                    journeyDate.setText(String.valueOf(dayOfMonth) + "-" + String.valueOf(monthOfYear + 1)
//                            + "-" + String.valueOf(year1));
                    edittextFromDate.setText(String.valueOf(dayOfMonth) + " " + months[monthOfYear - 1]
                            + " " + String.valueOf(year1));
                    fromDateTxt = String.valueOf(dayOfMonth) + "-" + String.valueOf(monthOfYear + 1)
                            + "-" + String.valueOf(year1);
                    valid();

                    setDays();
                }
            };

            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    DatePickerFragment date = new DatePickerFragment();
                    Calendar calender = Calendar.getInstance();
                    Bundle args = new Bundle();
                    int thisDay = fromDay;
                    int thisYear = fromYear;
                    int thisMonth = fromMonth;
                    if (thisDay == 0)
                        thisDay = calender.get(Calendar.DAY_OF_MONTH);
                    if (thisYear == 0)
                        thisYear = calender.get(Calendar.YEAR);
                    if (thisMonth == 0)
                        thisMonth = calender.get(Calendar.MONTH);
                    args.putInt("year", thisYear);
                    args.putInt("month", thisMonth);
                    args.putInt("day", thisDay);

                    args.putLong("minDate", calender.getTimeInMillis());
                    calender.add(Calendar.DAY_OF_MONTH, 30);
                    args.putLong("maxDate", calender.getTimeInMillis());

                    if (!edittextToDate.getText().toString().matches("")) {
                        Date from = null;
                        try {
                            from = new SimpleDateFormat("dd MMM yyyy", Locale.US).parse(edittextToDate.getText().toString());
                            Calendar calendar1 = Calendar.getInstance();
                            calendar1.setTime(from);
                            if (calendar1.getTimeInMillis() < calender.getTimeInMillis()) {
                                args.putLong("maxDate", calendar1.getTimeInMillis());
                            } else {
                                args.putLong("maxDate", calender.getTimeInMillis());
                            }
                        } catch (ParseException e) {
                            e.printStackTrace();
                            calender.add(Calendar.DAY_OF_MONTH, 30);
                            args.putLong("maxDate", calender.getTimeInMillis());
                        }
                    }

                    date.setArguments(args);

                    date.setCallBack(ondate);
                    date.show(getFragmentManager(), "Date Picker");
                }
            }
        });
    }

    private void setToDateListener() {
        edittextToDate.setOnClickListener(new View.OnClickListener() {

            DatePickerDialog.OnDateSetListener ondate = new DatePickerDialog.OnDateSetListener() {

                public void onDateSet(DatePicker view, int year1, int monthOfYear,
                                      int dayOfMonth) {
                    toDay = dayOfMonth;
                    toMonth = monthOfYear;
                    toYear = year1;
//                    journeyDate.setText(String.valueOf(dayOfMonth) + "-" + String.valueOf(monthOfYear + 1)
//                            + "-" + String.valueOf(year1));
                    edittextToDate.setText(String.valueOf(dayOfMonth) + " " + months[monthOfYear]
                            + " " + String.valueOf(year1));
                    toDateTxt = String.valueOf(dayOfMonth) + "-" + String.valueOf(monthOfYear + 1)
                            + "-" + String.valueOf(year1);
                    valid();

                    setDays();
                }
            };

            @Override
            public void onClick(View v) {

                DatePickerFragment date = new DatePickerFragment();
                Calendar calender = Calendar.getInstance();
                Bundle args = new Bundle();
                int thisDay = toDay;
                int thisYear = toYear;
                int thisMonth = toMonth;
                if (thisDay == 0)
                    thisDay = calender.get(Calendar.DAY_OF_MONTH);
                if (thisYear == 0)
                    thisYear = calender.get(Calendar.YEAR);
                if (thisMonth == 0)
                    thisMonth = calender.get(Calendar.MONTH);
                args.putInt("year", thisYear);
                args.putInt("month", thisMonth);
                args.putInt("day", thisDay);

                Calendar calender1 = Calendar.getInstance();
                if (!edittextFromDate.getText().toString().matches("")) {
                    Date from = null;
                    try {
                        from = new SimpleDateFormat("dd MMM yyyy", Locale.US).parse(edittextFromDate.getText().toString());
                        Calendar calendar1 = Calendar.getInstance();
                        calendar1.setTime(from);
                        calendar1.add(Calendar.DAY_OF_MONTH, 1);
                        args.putLong("minDate", calendar1.getTimeInMillis());
                    } catch (ParseException e) {
                        e.printStackTrace();
                        args.putLong("minDate", calender1.getTimeInMillis());
                    }
                } else {
                    args.putLong("minDate", calender1.getTimeInMillis());
                }
//                        args.putLong("minDate", calendar.getTimeInMillis());

                calender1.add(Calendar.YEAR, 1);
                args.putLong("maxDate", calender1.getTimeInMillis());
                date.setArguments(args);

                date.setCallBack(ondate);
                date.show(getFragmentManager(), "Date Picker");
            }
        });

        edittextToDate.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            DatePickerDialog.OnDateSetListener ondate = new DatePickerDialog.OnDateSetListener() {

                public void onDateSet(DatePicker view, int year1, int monthOfYear,
                                      int dayOfMonth) {
                    toDay = dayOfMonth;
                    toMonth = monthOfYear;
                    toYear = year1;
//                    journeyDate.setText(String.valueOf(dayOfMonth) + "-" + String.valueOf(monthOfYear + 1)
//                            + "-" + String.valueOf(year1));
                    edittextToDate.setText(String.valueOf(dayOfMonth) + " " + months[monthOfYear - 1]
                            + " " + String.valueOf(year1));
                    toDateTxt = String.valueOf(dayOfMonth) + "-" + String.valueOf(monthOfYear + 1)
                            + "-" + String.valueOf(year1);
                    valid();

                    setDays();
                }
            };

            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    DatePickerFragment date = new DatePickerFragment();
                    Calendar calender = Calendar.getInstance();
                    Bundle args = new Bundle();
                    int thisDay = toDay;
                    int thisYear = toYear;
                    int thisMonth = toMonth;
                    if (thisDay == 0)
                        thisDay = calender.get(Calendar.DAY_OF_MONTH);
                    if (thisYear == 0)
                        thisYear = calender.get(Calendar.YEAR);
                    if (thisMonth == 0)
                        thisMonth = calender.get(Calendar.MONTH);
                    args.putInt("year", thisYear);
                    args.putInt("month", thisMonth);
                    args.putInt("day", thisDay);

                    Calendar calender1 = Calendar.getInstance();
                    if (!edittextFromDate.getText().toString().matches("")) {
                        Date from = null;
                        try {
                            from = new SimpleDateFormat("dd MMM yyyy", Locale.US).parse(edittextFromDate.getText().toString());
                            Calendar calendar1 = Calendar.getInstance();
                            calendar1.setTime(from);
                            calendar1.add(Calendar.DAY_OF_MONTH, 1);
                            args.putLong("minDate", calendar1.getTimeInMillis());
                        } catch (ParseException e) {
                            e.printStackTrace();
                            args.putLong("minDate", calender1.getTimeInMillis());
                        }
                    } else {
                        args.putLong("minDate", calender1.getTimeInMillis());
                    }
//                        args.putLong("minDate", calendar.getTimeInMillis());

                    calender1.add(Calendar.YEAR, 1);
                    args.putLong("maxDate", calender1.getTimeInMillis());
                    date.setArguments(args);
                    date.setCallBack(ondate);
                    date.show(getFragmentManager(), "Date Picker");
                }
            }
        });
    }

    private void setTimeListener() {
        edittextTime.setOnFocusChangeListener(new View.OnFocusChangeListener() {

            TimePickerDialog.OnTimeSetListener onTimeSet = new TimePickerDialog.OnTimeSetListener() {

                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    hours = hourOfDay;
                    minutes = minute;
                    edittextTime.setText(String.format("%02d", hourOfDay)
                            + ":" + String.format("%02d", minute));
                    valid();
                }
            };

            @Override
            public void onFocusChange(View v, boolean e) {
                if (e) {
                    TimerPickerFragment newFragment = new TimerPickerFragment();
                    Bundle args = new Bundle();
                    args.putInt("hours", hours);
                    args.putInt("minutes", minutes);
                    newFragment.setArguments(args);
                    newFragment.setCallBack(onTimeSet);
                    newFragment.show(getFragmentManager(), "timePicker");
                }
            }

        });

        edittextTime.setOnClickListener(new View.OnClickListener() {
            TimePickerDialog.OnTimeSetListener onTimeSet = new TimePickerDialog.OnTimeSetListener() {

                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    hours = hourOfDay;
                    minutes = minute;
                    edittextTime.setText(String.format("%02d", hourOfDay) + ":"
                            + String.format("%02d", minute));
                    valid();
                }
            };

            @Override
            public void onClick(View v) {
                TimerPickerFragment newFragment = new TimerPickerFragment();
                Bundle args = new Bundle();
                args.putInt("hours", hours);
                args.putInt("minutes", minutes);
                newFragment.setArguments(args);
                newFragment.setCallBack(onTimeSet);
                newFragment.show(getFragmentManager(), "timePicker");
            }
        });
    }

    private void updateCall(UpdateDailyRideBean dailyRideBean) {

        call = new ShareACarApiService(getActivity()).getShareACarApi().updateDailyRide(dailyRideBean);

        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if ((progress != null) && progress.isShowing()) {
                    progress.dismiss();
                }

                if (response.code() == 200) {
                    try {
                        String result = response.body().string();
                        Log.e("Ride Info Daily Result", "result " + response.body().string());
                        String output[] = result.split("::");
                        if (output.length > 1) {
                            if (output[0].equalsIgnoreCase("Success")) {

                                TSnackbar snackbar = TSnackbar
                                        .make(getView(), "Ride is updated successfully", TSnackbar.LENGTH_SHORT);
                                snackbar.setActionTextColor(Color.WHITE);
                                View snackbarView = snackbar.getView();
                                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                                textView.setTextColor(Color.WHITE);
                                textView.setTypeface(Typeface.DEFAULT_BOLD);
                                snackbar.show();


                                new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        try {

                                            Thread.sleep(2000);
                                            // Do some stuff
                                            FragmentTransaction ft = getFragmentManager().beginTransaction();
//                                            ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
                                            ft.replace(R.id.frame, new myRidesFragment());
                                            ft.addToBackStack(null);
                                            ft.commit();


                                        } catch (Exception e) {
                                            e.getLocalizedMessage();
                                        }
                                    }
                                }).start();

                            } else {
                                TSnackbar snackbar = TSnackbar
                                        .make(getView(), output[1], TSnackbar.LENGTH_LONG);
                                snackbar.setActionTextColor(Color.WHITE);
                                View snackbarView = snackbar.getView();
                                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                                textView.setTextColor(Color.WHITE);
                                textView.setTypeface(Typeface.DEFAULT_BOLD);
                                snackbar.show();

                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
//                        Log.e(LOG, "result ++ e.printStackTrace() ");
                    }
                } else {
                    TSnackbar snackbar = TSnackbar
                            .make(getView(), "Can't connect to server", TSnackbar.LENGTH_LONG);
                    snackbar.setActionTextColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                    textView.setTextColor(Color.WHITE);
                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                    snackbar.show();

                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                if ((progress != null) && progress.isShowing()) {
                    progress.dismiss();
                }
                TSnackbar snackbar = TSnackbar
                        .make(getView(), "Please check your connection", TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.WHITE);
                textView.setTypeface(Typeface.DEFAULT_BOLD);
                snackbar.show();
            }
        });
    }

    public void deleteStopage(String stopageId) {

        updateRates();

        call = new ShareACarApiService(getActivity()).getShareACarApi().deleteStopageDaily(stopageId);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if ((progress != null) && progress.isShowing()) {
                    progress.dismiss();
                }
                try {
                    if (response.code() == 200) {
                        String result = response.body().string();
                        ResDeleteStopage(result);
                    } else {
                        TSnackbar snackbar = TSnackbar
                                .make(getView(), "Can't connect to server", TSnackbar.LENGTH_LONG);
                        snackbar.setActionTextColor(Color.WHITE);
                        View snackbarView = snackbar.getView();
                        snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                        TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                        textView.setTextColor(Color.WHITE);
                        textView.setTypeface(Typeface.DEFAULT_BOLD);
                        snackbar.show();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                if ((progress != null) && progress.isShowing()) {
                    progress.dismiss();
                }
                TSnackbar snackbar = TSnackbar
                        .make(getView(), "Please check your connection", TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.WHITE);
                textView.setTypeface(Typeface.DEFAULT_BOLD);
                snackbar.show();
            }
        });
    }

    private void ResDeleteStopage(String result) {
        updateRates();
        String[] output = result.split("::");
        if (output.length > 1) {
            if (output[0].equalsIgnoreCase("Success")) {

                TSnackbar snackbar = TSnackbar
                        .make(getView(), output[1], TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.WHITE);
                textView.setTypeface(Typeface.DEFAULT_BOLD);
                snackbar.show();

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {

                            Thread.sleep(2000);
                            // Do some stuff
                            FragmentTransaction ft = getFragmentManager().beginTransaction();
//                            ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
                            ft.replace(R.id.frame, new myRidesFragment());
                            ft.addToBackStack(null);
                            ft.commit();


                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    }
                }).start();

            } else {
                TSnackbar snackbar = TSnackbar
                        .make(getView(), output[1], TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.WHITE);
                textView.setTypeface(Typeface.DEFAULT_BOLD);
                snackbar.show();
            }
        }
    }

    private void rideDeleted(String result) {
        String output[] = result.split("::");
        if (output.length > 1) {
            if (output[0].equalsIgnoreCase("Success")) {

                if (rideBean.getIsDeleted() == 1 && !rideBean.getIsExpired()) {
                    TSnackbar snackbar = TSnackbar
                            .make(getView(), "Ride is put back successfully", TSnackbar.LENGTH_SHORT);
                    snackbar.setActionTextColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                    textView.setTextColor(Color.WHITE);
                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                    snackbar.show();

                } else if (rideBean.getIsExpired()) {
                    TSnackbar snackbar = TSnackbar
                            .make(getView(), "Ride is removed successfully", TSnackbar.LENGTH_SHORT);
                    snackbar.setActionTextColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                    textView.setTextColor(Color.WHITE);
                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                    snackbar.show();

                } else {
                    TSnackbar snackbar = TSnackbar
                            .make(getView(), output[1], TSnackbar.LENGTH_SHORT);
                    snackbar.setActionTextColor(Color.WHITE);
                    View snackbarView = snackbar.getView();
                    snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                    TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                    textView.setTextColor(Color.WHITE);
                    textView.setTypeface(Typeface.DEFAULT_BOLD);
                    snackbar.show();
                }

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {

                            Thread.sleep(2000);
                            // Do some stuff
                            FragmentTransaction ft = getFragmentManager().beginTransaction();
//                            ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
                            ft.replace(R.id.frame, new myRidesFragment());
                            ft.addToBackStack(null);
                            ft.commit();

                        } catch (Exception e) {
                            e.getLocalizedMessage();
                        }
                    }
                }).start();

            } else {
                TSnackbar snackbar = TSnackbar
                        .make(getView(), output[1], TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.WHITE);
                textView.setTypeface(Typeface.DEFAULT_BOLD);
                snackbar.show();
            }
        } else {
            TSnackbar snackbar = TSnackbar
                    .make(getView(), "Please check your connection", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();
        }
    }

    public boolean valid() {

        boolean valid = true;
        boolean dateFlag = true;

        Date from = null;
        DateFormat df = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
        String fromDailyText = "", toDailyText = "";
        try {
            from = new SimpleDateFormat("dd MMM yyyy", Locale.US).parse(edittextFromDate.getText().toString());
            fromDailyText = df.format(from);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.US);
        Date fDate = null;
        try {
            fDate = sdf.parse(fromDailyText + " " + edittextTime.getText().toString() + ":00");
        } catch (ParseException e) {
            e.printStackTrace();
        }

        Date todayDateTime = null;
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.HOUR_OF_DAY, 5);

        try {
            todayDateTime = sdf.parse(sdf.format(cal.getTime()));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        try {
            todayDateTime = sdf.parse(sdf.format(cal.getTime()));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        if (dateFlag) {
            if (todayDateTime != null && fDate != null && fDate.before(todayDateTime)) {
                if ((progress != null) && progress.isShowing()) {
                    progress.dismiss();
                }
                TSnackbar snackbar = TSnackbar
                        .make(getView(), "Please select future date and time", TSnackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.WHITE);
                View snackbarView = snackbar.getView();
                snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
                TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
                textView.setTextColor(Color.WHITE);
                textView.setTypeface(Typeface.DEFAULT_BOLD);
                snackbar.show();

                valid = false;
            }
        }

        if (fromDateTxt != null && fromDateTxt.isEmpty()) {
            if ((progress != null) && progress.isShowing()) {
                progress.dismiss();
            }
            TSnackbar snackbar = TSnackbar
                    .make(getView(), "Please select date", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
            dateFlag = false;
        }
        if (edittextTime.getText().toString().isEmpty()) {
            if ((progress != null) && progress.isShowing()) {
                progress.dismiss();
            }
            TSnackbar snackbar = TSnackbar
                    .make(getView(), "Please select time", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
            dateFlag = false;
        }

        if (edittextMessage.getText().toString().isEmpty()) {
            if ((progress != null) && progress.isShowing()) {
                progress.dismiss();
            }
            TSnackbar snackbar = TSnackbar
                    .make(getView(), "Please enter message", TSnackbar.LENGTH_LONG);
            snackbar.setActionTextColor(Color.WHITE);
            View snackbarView = snackbar.getView();
            snackbarView.setBackgroundColor(Color.parseColor("#df013A"));
            TextView textView = (TextView) snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text);
            textView.setTextColor(Color.WHITE);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            snackbar.show();

            valid = false;
            dateFlag = false;
        }
        return valid;
    }

    private void getDaysList() {
        daysList = rideBean.getDaysList();

        if (daysList.size() > 0) {
            StringBuffer sb = new StringBuffer("");

            goneAllDays();

            for (int day = 0; day < daysList.size(); day++) {

                if (daysList.get(day).length() > 0) {
                    if (day == daysList.size() - 1) {
                        sb.append(changeStringAppearence(daysList.get(day)));
                    } else {
                        sb.append(changeStringAppearence(daysList.get(day)) + ", ");
                    }
                }

                switch (daysList.get(day)) {
                    case "sun":
                        ttSun.setVisibility(View.VISIBLE);
                        checkboxSun.setVisibility(View.VISIBLE);
                        checkboxSun.setChecked(true);
                        break;
                    case "mon":
                        ttMon.setVisibility(View.VISIBLE);
                        checkboxMon.setVisibility(View.VISIBLE);
                        checkboxMon.setChecked(true);
                        break;
                    case "tue":
                        ttTue.setVisibility(View.VISIBLE);
                        checkboxTue.setVisibility(View.VISIBLE);
                        checkboxTue.setChecked(true);
                        break;
                    case "wed":
                        ttWed.setVisibility(View.VISIBLE);
                        checkboxWed.setVisibility(View.VISIBLE);
                        checkboxWed.setChecked(true);
                        break;
                    case "thu":
                        ttThr.setVisibility(View.VISIBLE);
                        checkboxThr.setVisibility(View.VISIBLE);
                        checkboxThr.setChecked(true);
                        break;
                    case "fri":
                        checkboxFri.setVisibility(View.VISIBLE);
                        ttFri.setVisibility(View.VISIBLE);
                        checkboxFri.setChecked(true);
                        break;
                    case "sat":
                        ttSat.setVisibility(View.VISIBLE);
                        checkboxSat.setVisibility(View.VISIBLE);
                        checkboxSat.setChecked(true);
                        break;
                }
            }
            textviewStaticDays.setText(sb);
        } else {
            visibleAllDays();
        }
    }

    private void setDays() {

        String fromDate = edittextFromDate.getText().toString();
        String toDate = edittextToDate.getText().toString();

        Date from = null;
        try {
            from = new SimpleDateFormat("dd MMM yyyy", Locale.US).parse(fromDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        Date to = null;
        try {
            to = new SimpleDateFormat("dd MMM yyyy", Locale.US).parse(toDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        DateFormat df = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
        fromDateTxt = df.format(from);
        toDateTxt = df.format(to);

        Calendar calObjFrom = Calendar.getInstance();
        calObjFrom.setTime(from);

        Calendar calObjTo = Calendar.getInstance();
        calObjTo.setTime(to);

        int daysBetween = daysBetween(calObjFrom, calObjTo) - 1;

//                Calendar c1 = (Calendar) calFromDaily.clone(), c2 = (Calendar) calToDaily.clone();

        if (daysBetween <= 5) {

            String[] days = new String[]{"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
            ArrayList<String> daysSelected = new ArrayList();

            int fd = 0, td = 0;
//            if(fromDay == null){
            daysSelected.add(new SimpleDateFormat("EEEE", Locale.US).format(from));
            fd = Arrays.asList(days).indexOf(new SimpleDateFormat("EEEE", Locale.US).format(from));
//            } /*else {
//                daysSelected.add(fromDay);
//                fd = Arrays.asList(days).indexOf(fromDay);
//            }*/

//            daysSelected.add(toDay);

            daysSelected.add(new SimpleDateFormat("EEEE", Locale.US).format(to));
            td = Arrays.asList(days).indexOf(new SimpleDateFormat("EEEE", Locale.US).format(to));

//            int td = Arrays.asList(days).indexOf(toDay);

            if (fd > td) {
                for (int z = 0; z < days.length; z++) {
                    if (z > fd) {
                        daysSelected.add(days[z]);
                    }
                }
                for (int z = 0; z < td; z++) {
                    daysSelected.add(days[z]);
                }
            } else {
                for (int i = fd + 1; i < td; i++) {
                    daysSelected.add(days[i]);
                }
            }

            goneAllDays();

            for (int i = 0; i < daysSelected.size(); i++) {
                switch (daysSelected.get(i)) {
                    case "Monday":
                        ttMon.setVisibility(View.VISIBLE);
                        checkboxMon.setVisibility(View.VISIBLE);
                        break;
                    case "Tuesday":
                        ttTue.setVisibility(View.VISIBLE);
                        checkboxTue.setVisibility(View.VISIBLE);
                        break;
                    case "Wednesday":
                        ttWed.setVisibility(View.VISIBLE);
                        checkboxWed.setVisibility(View.VISIBLE);
                        break;
                    case "Thursday":
                        ttThr.setVisibility(View.VISIBLE);
                        checkboxThr.setVisibility(View.VISIBLE);
                        break;
                    case "Friday":
                        ttFri.setVisibility(View.VISIBLE);
                        checkboxFri.setVisibility(View.VISIBLE);
                        break;
                    case "Saturday":
                        ttSat.setVisibility(View.VISIBLE);
                        checkboxSat.setVisibility(View.VISIBLE);
                        break;
                    case "Sunday":
                        ttSun.setVisibility(View.VISIBLE);
                        checkboxSun.setVisibility(View.VISIBLE);
                        break;
                }
            }
        } else {
            visibleAllDays();
        }
//        setDaysList();
    }

    private void goneAllDays() {
        ttMon.setVisibility(View.GONE);
        checkboxMon.setVisibility(View.GONE);
        ttTue.setVisibility(View.GONE);
        checkboxTue.setVisibility(View.GONE);
        ttWed.setVisibility(View.GONE);
        checkboxWed.setVisibility(View.GONE);
        ttThr.setVisibility(View.GONE);
        checkboxThr.setVisibility(View.GONE);
        ttFri.setVisibility(View.GONE);
        checkboxFri.setVisibility(View.GONE);
        ttSat.setVisibility(View.GONE);
        checkboxSat.setVisibility(View.GONE);
        ttSun.setVisibility(View.GONE);
        checkboxSun.setVisibility(View.GONE);
    }

    private void visibleAllDays() {
        ttMon.setVisibility(View.VISIBLE);
        checkboxMon.setVisibility(View.VISIBLE);
        ttTue.setVisibility(View.VISIBLE);
        checkboxTue.setVisibility(View.VISIBLE);
        ttWed.setVisibility(View.VISIBLE);
        checkboxWed.setVisibility(View.VISIBLE);
        ttThr.setVisibility(View.VISIBLE);
        checkboxThr.setVisibility(View.VISIBLE);
        ttFri.setVisibility(View.VISIBLE);
        checkboxFri.setVisibility(View.VISIBLE);
        ttSat.setVisibility(View.VISIBLE);
        checkboxSat.setVisibility(View.VISIBLE);
        ttSun.setVisibility(View.VISIBLE);
        checkboxSun.setVisibility(View.VISIBLE);
    }

    private void setDaysListToSend() {
        if (checkboxSun.getVisibility() == View.VISIBLE && checkboxSun.isChecked()) {
            daysToBeUpdated.add("sun");
        }

        if (checkboxMon.getVisibility() == View.VISIBLE && checkboxMon.isChecked()) {
            daysToBeUpdated.add("mon");
        }

        if (checkboxTue.getVisibility() == View.VISIBLE && checkboxTue.isChecked()) {
            daysToBeUpdated.add("tue");
        }

        if (checkboxWed.getVisibility() == View.VISIBLE && checkboxWed.isChecked()) {
            daysToBeUpdated.add("wed");
        }

        if (checkboxThr.getVisibility() == View.VISIBLE && checkboxThr.isChecked()) {
            daysToBeUpdated.add("thu");
        }

        if (checkboxFri.getVisibility() == View.VISIBLE && checkboxFri.isChecked()) {
            daysToBeUpdated.add("fri");
        }

        if (checkboxSat.getVisibility() == View.VISIBLE && checkboxSat.isChecked()) {
            daysToBeUpdated.add("sat");
        }
    }

    private String changeStringAppearence(String input) {
        return input.substring(0, 1).toUpperCase() + input.substring(1);
    }

    @Override
    public void onResume() {
        textviewTitle = (TextView) getActivity().findViewById(R.id.textviewTitle);

        Bundle args1 = getArguments();
        rideBean = args1.getParcelable("rideBean");

        /*shareRide = (ImageView) getActivity().findViewById(R.id.shareRide);
        if (rideBean.getStatus() == 1 || rideBean.getRideViewType().equalsIgnoreCase("rideList")) {    //if approved

            if (shareRide.getVisibility() == View.GONE)
                shareRide.setVisibility(View.VISIBLE);
        }*/

        if (textviewTitle.getVisibility() == View.GONE)
            textviewTitle.setVisibility(View.VISIBLE);
        textviewTitle.setText("Ride Information");

        header = (ImageView) getActivity().findViewById(R.id.tv_header_title);
        if (header.getVisibility() == View.VISIBLE)
            header.setVisibility(View.GONE);

        super.onResume();
    }
}
