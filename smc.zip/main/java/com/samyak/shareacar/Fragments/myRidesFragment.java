package com.samyak.shareacar.Fragments;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.samyak.shareacar.Adapters.rideAdapter;
import com.samyak.shareacar.BeforeLogin.Main;
import com.samyak.shareacar.Models.UserRideInfoBean;
import com.samyak.shareacar.R;
import com.samyak.shareacar.RetrofitApi.ShareACarApiService;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class myRidesFragment extends Fragment {

    public static boolean loadFlag = true;
    ImageView shareRide;
    List<UserRideInfoBean> rideInfoBeanArrayList = new ArrayList<>();
    Call<List<UserRideInfoBean>> call;
    //    String result;
    View v;
    RecyclerView recList;
    rideAdapter ca;
    LinearLayout connecting;
    TextView textviewM1, textviewM2, textviewTitle, textviewWelcome, textviewM3;
    ImageView header;
    int userId;
    private SwipeRefreshLayout swipeRefreshLayout;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadFlag = true;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.fragment_my_rides, container, false);
        rideListFragment.changeTitle = false;

        connecting = (LinearLayout) v.findViewById(R.id.connecting);
        textviewM1 = (TextView) v.findViewById(R.id.textviewM1);
        textviewM2 = (TextView) v.findViewById(R.id.textviewM2);
        textviewM3 = (TextView) v.findViewById(R.id.textviewM3);
        textviewWelcome = (TextView) v.findViewById(R.id.textviewWelcome);
        connecting.setVisibility(View.VISIBLE);

        userId = 0;

        SQLiteDatabase mydatabase = getActivity().openOrCreateDatabase("shareACar", Context.MODE_PRIVATE, null);
        mydatabase.execSQL("CREATE TABLE IF NOT EXISTS loginInfo(userId INTEGER ,carId INTEGER , contactNo TEXT , emailId TEXT, userName TEXT);");
        final Cursor c = mydatabase.rawQuery("Select * from loginInfo", null);

        if (c != null) {
            if (c.moveToFirst()) {
                do {
                    userId = c.getInt(c.getColumnIndex("userId"));
                } while (c.moveToNext());
            }
        } else {
            Intent intent = new Intent(getActivity(), Main.class);
            startActivity(intent);
        }

        if (userId == 0) {
            Intent intent = new Intent(getActivity(), Main.class);
            startActivity(intent);
        }

        recList = (RecyclerView) v.findViewById(R.id.cardList);
        recList.setHasFixedSize(true);
        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        recList.setLayoutManager(llm);
        ca = new rideAdapter(rideInfoBeanArrayList, false, getActivity());
        recList.setAdapter(ca);

        if (loadFlag) {
            swipeRefreshLayout = (SwipeRefreshLayout) v.findViewById(R.id.swipe_refresh_layout);
            swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    getData(userId);
                }
            });

            getData(userId);
        }
        c.close();
        mydatabase.close();

        return v;
    }

    private void getData(int userId) {

        call = new ShareACarApiService(getActivity()).getShareACarApi().getUserRide(userId + "");
        call.enqueue(new Callback<List<UserRideInfoBean>>() {
            @Override
            public void onResponse(Call<List<UserRideInfoBean>> call, Response<List<UserRideInfoBean>> response) {
                    /*try {
                        Log.e("response in myRides", new ObjectMapper().writeValueAsString(response.body()));
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }*/
                connecting.setVisibility(View.GONE);

                if (swipeRefreshLayout.isRefreshing()) {
                    swipeRefreshLayout.setRefreshing(false);
                }

                if (response.code() == 200) {
                    // Do awesome stuff
                    if (response.body().size() == 0) {

                        connecting.setVisibility(View.VISIBLE);
                        textviewM1.setText("No Rides Found");
                        textviewM1.setTextSize(25.0f);
                        textviewM2.setText("");
                        if (textviewWelcome.getVisibility() == View.VISIBLE)
                            textviewWelcome.setVisibility(View.GONE);

                            /*new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    try {

                                        Thread.sleep(2000);
                                        // Do some stuff
                                        FragmentTransaction ft = getFragmentManager().beginTransaction();
                                        ft.replace(R.id.frame, new HomeFragment());
                                        ft.addToBackStack(null);
                                        ft.commit();


                                    } catch (Exception e) {
                                        e.getLocalizedMessage();
                                    }
                                }
                            }).start();*/

                    } else {
                        rideInfoBeanArrayList.clear();
                        rideInfoBeanArrayList.addAll(response.body());

                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                ca.notifyDataSetChanged();
                                loadFlag = false;
                            }
                        });
                    }
                } else {
                    // Handle other response codes
                    connecting.setVisibility(View.VISIBLE);
                    textviewM1.setText("There may have been a connection");
                    textviewM2.setText("error with one of our servers.");
                    textviewM3.setText("(click here to try to reconnect)");
                    textviewM3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            FragmentManager fragmentManager = getFragmentManager();
                            fragmentManager.beginTransaction().replace(R.id.frame, new myRidesFragment(), "MyRidesFragment").addToBackStack(null).commit();
                        }
                    });
                    if (textviewWelcome.getVisibility() == View.VISIBLE)
                        textviewWelcome.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFailure(Call<List<UserRideInfoBean>> call, Throwable t) {
                t.printStackTrace();

                if (swipeRefreshLayout.isRefreshing()) {
                    swipeRefreshLayout.setRefreshing(false);
                }

                connecting.setVisibility(View.VISIBLE);
                textviewM1.setText("There may have been a connection");
                textviewM2.setText("error with one of our servers.");
                textviewM1.setTypeface(null, Typeface.BOLD);
                textviewM2.setTypeface(null, Typeface.BOLD);
                textviewM3.setText("(click here to try to reconnect)");
                textviewM3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        FragmentManager fragmentManager = getFragmentManager();
                        fragmentManager.beginTransaction().replace(R.id.frame, new myRidesFragment(), "MyRidesFragment").addToBackStack(null).commit();
                    }
                });

                if (textviewWelcome.getVisibility() == View.VISIBLE)
                    textviewWelcome.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public void onResume() {

        textviewTitle = (TextView) getActivity().findViewById(R.id.textviewTitle);
        if (textviewTitle.getVisibility() == View.GONE)
            textviewTitle.setVisibility(View.VISIBLE);
        textviewTitle.setText("My Rides");

        header = (ImageView) getActivity().findViewById(R.id.tv_header_title);
        if (header.getVisibility() == View.VISIBLE)
            header.setVisibility(View.GONE);

        shareRide = (ImageView) getActivity().findViewById(R.id.shareRide);
        if (shareRide.getVisibility() == View.VISIBLE)
            shareRide.setVisibility(View.GONE);

        super.onResume();
    }
}
