package com.samyak.shareacar.Fragments;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.samyak.shareacar.BeforeLogin.Main;
import com.samyak.shareacar.R;

public class HomeFragment extends Fragment {

    TextView textviewTitle = null;
    ImageView header, shareRide;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_home, container, false);
        Button offerRide = (Button) v.findViewById(R.id.btn_offer_a_ride);
        Button findRide = (Button) v.findViewById(R.id.btn_find_a_ride);
        int userId = 0;
        SQLiteDatabase mydatabase = getActivity().openOrCreateDatabase("shareACar", Context.MODE_PRIVATE, null);
        mydatabase.execSQL("CREATE TABLE IF NOT EXISTS loginInfo(userId INTEGER ,carId INTEGER , contactNo TEXT , emailId TEXT, userName TEXT);");
        Cursor c = mydatabase.rawQuery("Select * from loginInfo", null);

        if (c != null) {
            if (c.moveToFirst()) {
                do {
                    userId = c.getInt(c.getColumnIndex("userId"));
                    Log.e("useriiiiiID", "" + userId);
                } while (c.moveToNext());
            }
        } else {
            Intent intent = new Intent(getActivity(), Main.class);
            startActivity(intent);
        }
        if (userId == 0) {
            if (this.getArguments() != null) {
                if (this.getArguments().containsKey("Logout")) {
                    Intent intent = new Intent(getActivity(), Main.class);
                    intent.putExtra("Logout", true);
                    startActivity(intent);
                }
            } else {
                Intent intent = new Intent(getActivity(), Main.class);
                startActivity(intent);
            }

        }


        offerRide.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
                ft.replace(R.id.frame, new offerRide(), "offerRide");
                ft.addToBackStack(null);
                ft.commit();
            }
        });
        findRide.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.setCustomAnimations(R.anim.slide_in, R.anim.slide_out);
                ft.replace(R.id.frame, new findRideFragment());
                ft.addToBackStack(null);
                ft.commit();
            }
        });
        return v;
    }

    @Override
    public void onResume() {
        textviewTitle = (TextView) getActivity().findViewById(R.id.textviewTitle);
        header = (ImageView) getActivity().findViewById(R.id.tv_header_title);
        if (textviewTitle.getVisibility() == View.VISIBLE)
            textviewTitle.setVisibility(View.GONE);
        if (header.getVisibility() == View.GONE)
            header.setVisibility(View.VISIBLE);
        shareRide = (ImageView) getActivity().findViewById(R.id.shareRide);
        if (shareRide.getVisibility() == View.VISIBLE)
            shareRide.setVisibility(View.GONE);
        super.onResume();
    }
}



