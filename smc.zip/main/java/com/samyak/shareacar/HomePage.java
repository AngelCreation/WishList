package com.samyak.shareacar;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.crashlytics.android.Crashlytics;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.RewardedVideoAd;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;
import com.samyak.shareacar.BeforeLogin.Fragments.RideListOut;
import com.samyak.shareacar.BeforeLogin.Main;
import com.samyak.shareacar.Fragments.HomeFragment;
import com.samyak.shareacar.Fragments.RideInfoDaily;
import com.samyak.shareacar.Fragments.carInfoFragment;
import com.samyak.shareacar.Fragments.changePasswordFragment;
import com.samyak.shareacar.Fragments.editPersonalInfo;
import com.samyak.shareacar.Fragments.findRideFragment;
import com.samyak.shareacar.Fragments.logoutFragment;
import com.samyak.shareacar.Fragments.myRidesFragment;
import com.samyak.shareacar.Fragments.offerRide;
import com.samyak.shareacar.Fragments.rideInfoFragment;
import com.samyak.shareacar.Fragments.rideListFragment;
import com.samyak.shareacar.Models.UserRideInfoBean;

import java.util.List;

import io.fabric.sdk.android.Fabric;

public class HomePage extends AppCompatActivity {

    public static boolean connectionFlag = true;
    TextView textviewTitle = null;

    boolean goToHome = false;

    DrawerLayout drawerLayout;

    ImageView imageViewLogo, imageviewHome, imageviewMyRides, imageviewPersonalInfo,
            imageviewCarDetails, imageviewChangePass, imageviewRefer, imageviewLogout, shareRide;

    LinearLayout linearLayoutHome, linearLayoutMyRides, linearEditPersonalInfo,
            linearLayoutYourCarDetails, linearLayoutEditPassword, linearLayoutRefer, linearLayoutLogOut;

    TextView textviewTitleUser, textviewShorty, textViewHome, textViewMyRides,
            textViewEditPersonalInfo, textViewSYourCarDetails, textViewEditPass, textViewRefer, textViewLogout;

//    private RewardedVideoAd mRewardedVideoAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_nav);
        Fabric.with(this, new Crashlytics());

        AdView mAdView = (AdView) findViewById(R.id.adView);
        // AdRequest adRequest = new AdRequest.Builder().build();
        AdRequest adRequest = new AdRequest.Builder()
//                .addTestDevice("E675ADF3D213DB10C8CA35617B0D0014")  //asus
//                .addTestDevice("D9F9B07C3F3A43A479C2F2DA15A68146")  //micromax
//               .addTestDevice("C790F88E883449C92A6735BD1F6B610C") //samsung
                .build();
        mAdView.loadAd(adRequest);

        /*// Initialize the Mobile Ads SDK.
        MobileAds.initialize(HomePage.this,"ca-app-pub-1713818242363443~3699777610");

        mRewardedVideoAd = MobileAds.getRewardedVideoAdInstance(this);
        mRewardedVideoAd.setRewardedVideoAdListener(new RewardedVideoAdListener() {
            @Override
            public void onRewardedVideoAdLoaded() {
                Toast.makeText(HomePage.this, "onRewardedVideoAdLoaded", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onRewardedVideoAdOpened() {

            }

            @Override
            public void onRewardedVideoStarted() {

            }

            @Override
            public void onRewardedVideoAdClosed() {

            }

            @Override
            public void onRewarded(RewardItem rewardItem) {
                Toast.makeText(HomePage.this, "onRewarded", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onRewardedVideoAdLeftApplication() {

            }

            @Override
            public void onRewardedVideoAdFailedToLoad(int i) {
                Toast.makeText(HomePage.this, "onRewardedVideoAdFailedToLoad", Toast.LENGTH_SHORT).show();
            }
        });

        mRewardedVideoAd.loadAd("ca-app-pub-1713818242363443/8892000017", new AdRequest.Builder().build());
        if (mRewardedVideoAd.isLoaded()) {
            mRewardedVideoAd.show();
        }*/

        textviewTitle = (TextView) findViewById(R.id.textviewTitle);

        textviewTitleUser = (TextView) findViewById(R.id.textviewTitleUser);
        textviewShorty = (TextView) findViewById(R.id.textviewShorty);

        linearLayoutHome = (LinearLayout) findViewById(R.id.linearLayoutHome);
        linearLayoutMyRides = (LinearLayout) findViewById(R.id.linearLayoutMyRides);
        linearEditPersonalInfo = (LinearLayout) findViewById(R.id.linearEditPersonalInfo);
        linearLayoutYourCarDetails = (LinearLayout) findViewById(R.id.linearLayoutYourCarDetails);
        linearLayoutEditPassword = (LinearLayout) findViewById(R.id.linearLayoutEditPassword);
        linearLayoutRefer = (LinearLayout) findViewById(R.id.linearLayoutRefer);
        linearLayoutLogOut = (LinearLayout) findViewById(R.id.linearLayoutLogOut);

        imageviewHome = (ImageView) findViewById(R.id.imageviewHome);
        imageviewMyRides = (ImageView) findViewById(R.id.imageviewMyRides);
        imageviewPersonalInfo = (ImageView) findViewById(R.id.imageviewPersonalInfo);
        imageviewCarDetails = (ImageView) findViewById(R.id.imageviewCarDetails);
        imageviewChangePass = (ImageView) findViewById(R.id.imageviewChangePass);
        imageviewRefer = (ImageView) findViewById(R.id.imageviewRefer);
        imageviewLogout = (ImageView) findViewById(R.id.imageviewLogout);

        textViewHome = (TextView) findViewById(R.id.textViewHome);
        textViewMyRides = (TextView) findViewById(R.id.textViewMyRides);
        textViewEditPersonalInfo = (TextView) findViewById(R.id.textViewEditPersonalInfo);
        textViewSYourCarDetails = (TextView) findViewById(R.id.textViewSYourCarDetails);
        textViewEditPass = (TextView) findViewById(R.id.textViewEditPass);
        textViewRefer = (TextView) findViewById(R.id.textViewRefer);
        textViewLogout = (TextView) findViewById(R.id.textViewLogout);

        setHomeSelected();

        setNavigationDrawer();

//        makeFileToShare();

        int userId = 0;

        String fullName;
        SQLiteDatabase mydatabase = openOrCreateDatabase("shareACar", MODE_PRIVATE, null);
        mydatabase.execSQL("CREATE TABLE IF NOT EXISTS loginInfo(userId INTEGER, carId INTEGER, contactNo TEXT, emailId TEXT, userName TEXT);");
        Cursor c = mydatabase.rawQuery("Select * from loginInfo", null);
        if (c != null) {
            if (c.moveToFirst()) {
                do {
                    userId = c.getInt(c.getColumnIndex("userId"));
                    try {
                        fullName = c.getString(c.getColumnIndex("userName"));
                        String[] parts = fullName.split(" ");
                        String part1 = parts[0].trim();
                        String part2 = parts[1].trim();
                        textviewShorty.setText(part1 + "\n" + part2);
                        textviewTitleUser.setText("" + Character.toUpperCase(part1.charAt(0)) + Character.toUpperCase(part2.charAt(0)));
                    } catch (Exception e) {
                        textviewShorty.setText("User");
                    }

                } while (c.moveToNext());
            }
        } else {
            Intent intent = new Intent(this, Main.class);
            startActivity(intent);
            finish();
            return;
        }
        if (userId == 0) {
            Intent intent = new Intent(this, Main.class);
            startActivity(intent);
            finish();
            return;
        }
        findRideFragment.City[0] = "";
        findRideFragment.City[1] = "";

        imageviewHome.setImageResource(R.drawable.ic_nav_home_white);

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        if (getIntent().getExtras() != null) {
            if (getIntent().getExtras().containsKey("callOfferRide")) {
                transaction.replace(R.id.frame, new offerRide());
            } else if (getIntent().getExtras().containsKey("callFindRide")) {
                goToHome = true;
                rideInfoFragment rif = new rideInfoFragment();
                rif.setArguments(getIntent().getExtras());
                transaction.replace(R.id.frame, rif);
            } else {
                transaction.replace(R.id.frame, new HomeFragment());
            }
        } else {
            transaction.replace(R.id.frame, new HomeFragment());
        }
        transaction.addToBackStack(null);
        transaction.commit();
    }

    private void setNavigationDrawer() {
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

        drawerLayout.setDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                hideKeyBoard(drawerView);
            }

            @Override
            public void onDrawerOpened(View drawerView) {

            }

            @Override
            public void onDrawerClosed(View drawerView) {

            }

            @Override
            public void onDrawerStateChanged(int newState) {

            }
        });

        imageViewLogo = (ImageView) findViewById(R.id.drawer_logo);

        imageViewLogo.requestFocus();

        imageViewLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hideKeyBoard(view);
                drawerLayout.openDrawer(Gravity.LEFT);
            }
        });

        linearLayoutHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                setHomeSelected();

                drawerLayout.closeDrawers();

                Intent it = new Intent(getApplicationContext(), HomePage.class);
                finish();
                startActivity(it);

                overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
            }
        });

        linearLayoutMyRides.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                setMyRidesSelected();

                drawerLayout.closeDrawers();

                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().setCustomAnimations(R.anim.slide_in, R.anim.slide_out).replace(R.id.frame, new myRidesFragment(), "MyRidesFragment").addToBackStack(null).commit();
            }
        });

        linearEditPersonalInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                setPersonalInfoSelected();

                drawerLayout.closeDrawers();

                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().setCustomAnimations(R.anim.slide_in, R.anim.slide_out).replace(R.id.frame, new editPersonalInfo(), "EditPersonalInfoFragment").addToBackStack(null).commit();
            }
        });

        linearLayoutYourCarDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                setCarDetailsSelected();

                drawerLayout.closeDrawers();

                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().setCustomAnimations(R.anim.slide_in, R.anim.slide_out).replace(R.id.frame, new carInfoFragment(), "YourCarDetailsFragment").addToBackStack(null).commit();
            }
        });

        linearLayoutEditPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                setChangePasswordSelected();

                drawerLayout.closeDrawers();

                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().setCustomAnimations(R.anim.slide_in, R.anim.slide_out).replace(R.id.frame, new changePasswordFragment(), "ChangePasswordFragment").addToBackStack(null).commit();
            }
        });

        linearLayoutRefer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                drawerLayout.closeDrawers();
//                setReferSelected();

//                ApplicationInfo app = getApplicationContext().getApplicationInfo();
//                filePath = getExternalFilesDir(null).getPath() + File.separator + "shareurcar.txt";

//                onShareClick(view);

                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                try {
                    sendIntent.putExtra(Intent.EXTRA_TEXT,
                            "Hey I came across this awsome App! Download Now. https://play.google.com/store/apps/details?id=com.samyak.shareurcar&hl=en");
                } catch (Exception e) {
                    e.printStackTrace();
                }
//                sendIntent.setType("*/*");
                sendIntent.setType("text/plain");

                PackageManager pm = getPackageManager();
                List<ResolveInfo> resInfo = pm.queryIntentActivities(sendIntent, 0);

                for (int i = 0; i < resInfo.size(); i++) {
                    ResolveInfo ri = resInfo.get(i);
                    String packageName = ri.activityInfo.packageName;

                    if (packageName.contains("android.email") || packageName.contains("android.gm")) {
                        sendIntent.putExtra(Intent.EXTRA_SUBJECT, "ShareUrCar Application");
                    } /*else if(packageName.contains("xender")){
//                        sendIntent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new File(filePath)));
                    }*/
                }

                startActivity(sendIntent);
            }
        });

        linearLayoutLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                setLogOutSelected();

                drawerLayout.closeDrawers();

                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.frame, new logoutFragment(), "LogoutFragment").addToBackStack(null).commit();
            }
        });

    }

    private void setHomeSelected() {
        linearLayoutHome.setBackgroundColor(ContextCompat.getColor(HomePage.this, R.color.primary));
        linearLayoutMyRides.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearEditPersonalInfo.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutYourCarDetails.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutEditPassword.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutRefer.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutLogOut.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));

        textViewHome.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.white));
        textViewMyRides.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewEditPersonalInfo.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewSYourCarDetails.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewEditPass.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewRefer.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewLogout.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));

        imageviewHome.setImageResource(R.drawable.ic_nav_home_white);
        imageviewMyRides.setImageResource(R.drawable.ic_nav_myrides_black);
        imageviewPersonalInfo.setImageResource(R.drawable.ic_nav_personalinfo_black);
        imageviewCarDetails.setImageResource(R.drawable.ic_nav_car_black);
        imageviewChangePass.setImageResource(R.drawable.ic_nav_changepass_black);
        imageviewRefer.setImageResource(R.drawable.ic_action_share_black);
        imageviewLogout.setImageResource(R.drawable.ic_nav_logout_black);
    }

    private void setMyRidesSelected() {
        linearLayoutHome.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutMyRides.setBackgroundColor(ContextCompat.getColor(HomePage.this, R.color.primary));
        linearEditPersonalInfo.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutYourCarDetails.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutEditPassword.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutRefer.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutLogOut.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));

        textViewHome.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewMyRides.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.white));
        textViewEditPersonalInfo.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewSYourCarDetails.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewEditPass.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewRefer.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewLogout.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));

        imageviewHome.setImageResource(R.drawable.ic_nav_home_black);
        imageviewMyRides.setImageResource(R.drawable.ic_nav_myrides_white);
        imageviewPersonalInfo.setImageResource(R.drawable.ic_nav_personalinfo_black);
        imageviewCarDetails.setImageResource(R.drawable.ic_nav_car_black);
        imageviewChangePass.setImageResource(R.drawable.ic_nav_changepass_black);
        imageviewRefer.setImageResource(R.drawable.ic_action_share_black);
        imageviewLogout.setImageResource(R.drawable.ic_nav_logout_black);
    }

    private void setPersonalInfoSelected() {
        linearLayoutHome.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutMyRides.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearEditPersonalInfo.setBackgroundColor(ContextCompat.getColor(HomePage.this, R.color.primary));
        linearLayoutYourCarDetails.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutEditPassword.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutRefer.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutLogOut.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));

        textViewHome.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewMyRides.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewEditPersonalInfo.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.white));
        textViewSYourCarDetails.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewEditPass.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewRefer.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewLogout.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));

        imageviewHome.setImageResource(R.drawable.ic_nav_home_black);
        imageviewMyRides.setImageResource(R.drawable.ic_nav_myrides_black);
        imageviewPersonalInfo.setImageResource(R.drawable.ic_nav_personalinfo_white);
        imageviewCarDetails.setImageResource(R.drawable.ic_nav_car_black);
        imageviewChangePass.setImageResource(R.drawable.ic_nav_changepass_black);
        imageviewRefer.setImageResource(R.drawable.ic_action_share_black);
        imageviewLogout.setImageResource(R.drawable.ic_nav_logout_black);
    }

    private void setCarDetailsSelected() {
        linearLayoutHome.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutMyRides.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearEditPersonalInfo.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutYourCarDetails.setBackgroundColor(ContextCompat.getColor(HomePage.this, R.color.primary));
        linearLayoutEditPassword.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutRefer.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutLogOut.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));

        textViewHome.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewMyRides.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewEditPersonalInfo.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewSYourCarDetails.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.white));
        textViewEditPass.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewRefer.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewLogout.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));

        imageviewHome.setImageResource(R.drawable.ic_nav_home_black);
        imageviewMyRides.setImageResource(R.drawable.ic_nav_myrides_black);
        imageviewPersonalInfo.setImageResource(R.drawable.ic_nav_personalinfo_black);
        imageviewCarDetails.setImageResource(R.drawable.ic_nav_car_white);
        imageviewChangePass.setImageResource(R.drawable.ic_nav_changepass_black);
        imageviewRefer.setImageResource(R.drawable.ic_action_share_black);
        imageviewLogout.setImageResource(R.drawable.ic_nav_logout_black);
    }

    private void setChangePasswordSelected() {
        linearLayoutHome.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutMyRides.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearEditPersonalInfo.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutYourCarDetails.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutEditPassword.setBackgroundColor(ContextCompat.getColor(HomePage.this, R.color.primary));
        linearLayoutRefer.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutLogOut.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));

        textViewHome.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewMyRides.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewEditPersonalInfo.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewSYourCarDetails.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewEditPass.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.white));
        textViewRefer.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewLogout.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));

        imageviewHome.setImageResource(R.drawable.ic_nav_home_black);
        imageviewMyRides.setImageResource(R.drawable.ic_nav_myrides_black);
        imageviewPersonalInfo.setImageResource(R.drawable.ic_nav_personalinfo_black);
        imageviewCarDetails.setImageResource(R.drawable.ic_nav_car_black);
        imageviewChangePass.setImageResource(R.drawable.ic_nav_changepass_white);
        imageviewRefer.setImageResource(R.drawable.ic_action_share_black);
        imageviewLogout.setImageResource(R.drawable.ic_nav_logout_black);
    }

    private void setLogOutSelected() {
        linearLayoutHome.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutMyRides.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearEditPersonalInfo.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutYourCarDetails.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutEditPassword.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutRefer.setBackgroundColor(ContextCompat.getColor(HomePage.this, android.R.color.transparent));
        linearLayoutLogOut.setBackgroundColor(ContextCompat.getColor(HomePage.this, R.color.primary));

        textViewHome.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewMyRides.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewEditPersonalInfo.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewSYourCarDetails.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewEditPass.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewRefer.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.black));
        textViewLogout.setTextColor(ContextCompat.getColor(HomePage.this, android.R.color.white));

        imageviewHome.setImageResource(R.drawable.ic_nav_home_black);
        imageviewMyRides.setImageResource(R.drawable.ic_nav_myrides_black);
        imageviewPersonalInfo.setImageResource(R.drawable.ic_nav_personalinfo_black);
        imageviewCarDetails.setImageResource(R.drawable.ic_nav_car_black);
        imageviewChangePass.setImageResource(R.drawable.ic_nav_changepass_black);
        imageviewRefer.setImageResource(R.drawable.ic_action_share_black);
        imageviewLogout.setImageResource(R.drawable.ic_nav_logout_white);
    }

    /*private void makeFileToShare() {
            try {
                //Whatever the file path is.
                File statText = new File(getExternalFilesDir(null).getPath() + File.separator + "shareurcar.txt");
                FileOutputStream is = new FileOutputStream(statText);
                OutputStreamWriter osw = new OutputStreamWriter(is);
                Writer w = new BufferedWriter(osw);
                w.write("Hey I came across this awsome App! Download Now. https://play.google.com/store/apps/details?id=com.samyak.shareurcar&hl=en");
                w.close();
            } catch (IOException e) {
                System.err.println("Problem writing to the file statsTest.txt");
            }
    }*/

    @Override
    public void onBackPressed() {

       /* FragmentManager fragmentManager = this.getSupportFragmentManager();
        List<android.support.v4.app.Fragment> fragments = fragmentManager.getFragments();
        if (fragments != null) {
            for (android.support.v4.app.Fragment fragment : fragments) {
                if (fragment != null && fragment.isVisible()) {
                    *//*if (!fragment.getClass().equals(HomeFragment.class)) {
                        super.onBackPressed();
                    }*//*
                    if (fragment.getClass().equals(myRidesFragment.class)) {    //main
                            *//*setHomeSelected();
                            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                            ft.replace(R.id.frame, new HomeFragment());
                            ft.addToBackStack(null);
                            ft.commit();*//*

                        Intent it = new Intent(getApplicationContext(), HomePage.class);
                        finish();
                        startActivity(it);
                        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                    } else if (fragment.getClass().equals(findRideFragment.class)) {
                        setHomeSelected();
                       *//* FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                        ft.replace(R.id.frame, new HomeFragment());
                        ft.addToBackStack(null);
                        ft.commit();*//*
                        Intent it = new Intent(getApplicationContext(), HomePage.class);
                        finish();
                        startActivity(it);
                        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                    } else if (fragment.getClass().equals(offerRide.class)) {

                        *//*setHomeSelected();
                        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                        ft.replace(R.id.frame, new HomeFragment());
                        ft.addToBackStack(null);
                        ft.commit();*//*
                        Intent it = new Intent(getApplicationContext(), HomePage.class);
                        finish();
                        startActivity(it);
                        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);

                    } else if (fragment.getClass().equals(editPersonalInfo.class)) {
                        *//*setHomeSelected();
                        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                        ft.replace(R.id.frame, new HomeFragment());
                        ft.addToBackStack(null);
                        ft.commit();*//*
                        Intent it = new Intent(getApplicationContext(), HomePage.class);
                        finish();
                        startActivity(it);
                        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                    } else if (fragment.getClass().equals(carInfoFragment.class)) {
                        *//*setHomeSelected();
                        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                        ft.replace(R.id.frame, new HomeFragment());
                        ft.addToBackStack(null);
                        ft.commit();*//*
                        *//*if(offerRideFinal.noCarDetails){
                            getSupportFragmentManager().popBackStackImmediate();

                        } else {*//*
                            Intent it = new Intent(getApplicationContext(), HomePage.class);
                            finish();
                            startActivity(it);
                            overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
//                        }

                    } else if (fragment.getClass().equals(changePasswordFragment.class)) {
                        *//*setHomeSelected();
                        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                        ft.replace(R.id.frame, new HomeFragment());
                        ft.addToBackStack(null);
                        ft.commit();*//*
                        Intent it = new Intent(getApplicationContext(), HomePage.class);
                        finish();
                        startActivity(it);
                        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                    } else if (fragment.getClass().equals(rideInfoFragment.class)) {
                        super.onBackPressed();
                         if(rideListFragment.changeTitle){
                            if(goToHome) {
//                                goToHome = false;
                                Intent it = new Intent(getApplicationContext(), HomePage.class);
                                finish();
                                startActivity(it);
                                overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                            } else {
                                textviewTitle.setText("Ride List");
                            }
//                            rideListFragment.changeTitle = false;
                        } else {
                             if(rideInfoFragment.refresh){
                                 FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                                 ft.replace(R.id.frame, new myRidesFragment());
                                 ft.addToBackStack(null);
                                 ft.commit();
                                 rideInfoFragment.refresh = false;
                             } else {
                                 textviewTitle.setText("My Rides");
                             }
                         }
                    }

                    else if (fragment.getClass().equals(HomeFragment.class)) {
                        *//*if (doubleBackToExitPressedOnce) {
                            moveTaskToBack(true);
                            return;
                        }
                        this.doubleBackToExitPressedOnce = true;
                        // super.onBackPressed();
                        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                doubleBackToExitPressedOnce = false;
                            }
                        }, 2000);*//*
                        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(HomePage.this);
                        builder.setMessage(Html.fromHtml("Do you want to exit?"))
                                .setCancelable(false)
//                    .setTitle("Act Detail")
                                .setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        finish();
                                        return;
                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                        android.app.AlertDialog alert = builder.create();
                        alert.show();
                    }
                    else {
                        super.onBackPressed();
                    }
                }
            }
            //return fragment;
        }*/

        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.frame);

        if (drawerLayout.isDrawerOpen(Gravity.LEFT)) {
            drawerLayout.closeDrawers();
        } else if (fragment instanceof myRidesFragment) {
            goToHomePage();
        } else if (fragment instanceof findRideFragment) {
            setHomeSelected();
            goToHomePage();
        } else if (fragment instanceof offerRide) {
            goToHomePage();
        } else if (fragment instanceof editPersonalInfo) {
            goToHomePage();
        } else if (fragment instanceof carInfoFragment) {
            goToHomePage();
        } else if (fragment instanceof changePasswordFragment) {
            goToHomePage();
        } else if (fragment instanceof rideInfoFragment) {
            super.onBackPressed();
            shareRide = (ImageView) findViewById(R.id.shareRide);
            if (shareRide.getVisibility() == View.VISIBLE)
                shareRide.setVisibility(View.GONE);
            if (rideListFragment.changeTitle || RideListOut.changeTitle) {
                rideListFragment.changeTitle = false;
                RideListOut.changeTitle = false;
                if (goToHome) {
                    goToHomePage();
                } else {
                    textviewTitle.setText("Ride List");
                }
            } else {
                if (rideInfoFragment.refresh) {
                    rideInfoFragment.refresh = false;
                    FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                    ft.replace(R.id.frame, new myRidesFragment());
                    ft.addToBackStack(null);
                    ft.commit();
                } else {
                    textviewTitle.setText("My Rides");
                }
            }
        } else if (fragment instanceof RideInfoDaily) {
            super.onBackPressed();
            shareRide = (ImageView) findViewById(R.id.shareRide);
            if (shareRide.getVisibility() == View.VISIBLE)
                shareRide.setVisibility(View.GONE);
            if (RideInfoDaily.refresh) {
                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.frame, new myRidesFragment());
                ft.addToBackStack(null);
                ft.commit();
                RideInfoDaily.refresh = false;
            } else {
                textviewTitle.setText("My Rides");
            }
        } else if (fragment instanceof HomeFragment) {
            LayoutInflater factory = LayoutInflater.from(HomePage.this);
            final View confirmDialogView = factory.inflate(R.layout.alertbox, null);
            final Dialog confirmDialog = new Dialog(HomePage.this);
            confirmDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            confirmDialog.setContentView(confirmDialogView);
            TextView message = (TextView) confirmDialogView.findViewById(R.id.message);
            message.setText("Do You Want To Exit From Appplication?");
            ((TextView) confirmDialogView.findViewById(R.id.confirm)).setText("Please Confirm!");
            ((TextView) confirmDialogView.findViewById(R.id.getPro)).setVisibility(View.GONE);
            ((Button) confirmDialogView.findViewById(R.id.cancel)).setText("Cancel");
            ((Button) confirmDialogView.findViewById(R.id.ok)).setText("Exit");

            confirmDialogView.findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    confirmDialog.dismiss();
                }
            });
            confirmDialogView.findViewById(R.id.ok).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                    confirmDialog.dismiss();
                    return;
                }
            });
            confirmDialog.show();
        } else {
            super.onBackPressed();
        }
    }

    public void moveToRideInfo(UserRideInfoBean rideBean) {

      /* if(b) {
           Intent myIntent = new Intent(HomePage.this, LoginActivity.class);
           myIntent.putExtra("callFindRide",true);
           myIntent.putExtra("rideBean", rideBean);
           finish();
           startActivity(myIntent);

           overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
       } else {*/

        Bundle args = new Bundle();
        args.putParcelable("rideBean", rideBean);

        if (rideBean.getRideViewType().equalsIgnoreCase("daily")) {
            RideInfoDaily rid = new RideInfoDaily();
            rid.setArguments(args);
            Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.frame);
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.hide(fragment); //hide self
            transaction.add(R.id.frame, rid);
            transaction.addToBackStack(null);
            transaction.commit();
        } else {
            rideInfoFragment rif = new rideInfoFragment();
            rif.setArguments(args);
            Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.frame);
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.hide(fragment); //hide self
            transaction.add(R.id.frame, rif);
            transaction.addToBackStack(null);
            transaction.commit();
        }
    }

    private void goToHomePage() {
        Intent it = new Intent(getApplicationContext(), HomePage.class);
        finish();
        startActivity(it);
        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
    }

    private void hideKeyBoard(View view) {
        //close keyboard
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
}
