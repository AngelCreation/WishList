package com.samyak.shareacar.Helpers.ViewHolder;

import android.app.Dialog;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.samyak.shareacar.BeforeLogin.Main;
import com.samyak.shareacar.HomePage;
import com.samyak.shareacar.Models.UserRideInfoBean;
import com.samyak.shareacar.R;

/**
 * Created by hprajapati on 8/7/16.
 */
public class rideInfoHandler extends RecyclerView.ViewHolder {
    public TextView rideDateTime;
    public TextView rideTime;
    public TextView journeyDetails;
    public TextView userName;
    public TextView expired;
    public TextView rideFromDailyDate;
    public TextView rideToDailyDate;
    public TextView rideTimeDaily;
    public RelativeLayout cardView;
    public UserRideInfoBean rideBean;
    public boolean callFind;

    public rideInfoHandler(View v, final Context context) {
        super(v);
        rideDateTime = (TextView) v.findViewById(R.id.txt_ride_date_handle);
        rideTime = (TextView) v.findViewById(R.id.txt_ride_time_handle);
        journeyDetails = (TextView) v.findViewById(R.id.txt_journey_details_handle);
        expired = (TextView) v.findViewById(R.id.txt_ride_expired_handle);
        rideFromDailyDate = (TextView) v.findViewById(R.id.rideFromDailyDate);
        rideToDailyDate = (TextView) v.findViewById(R.id.rideToDailyDate);
        rideTimeDaily = (TextView) v.findViewById(R.id.rideTimeDaily);
        cardView = (RelativeLayout) v.findViewById(R.id.card_view_relative);

        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (callFind) {
                    LayoutInflater factory = LayoutInflater.from(context);
                    final View confirmDialogView = factory.inflate(R.layout.alertbox, null);
                    final Dialog confirmDialog = new Dialog(context);
                    confirmDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    confirmDialog.setContentView(confirmDialogView);
                    TextView message = (TextView) confirmDialogView.findViewById(R.id.message);
                    message.setText("You need to be authenticated to see ride details");
                    ((TextView) confirmDialogView.findViewById(R.id.confirm)).setText("Almost There!");
                    ((TextView) confirmDialogView.findViewById(R.id.getPro)).setText("Log in");
                    ((Button) confirmDialogView.findViewById(R.id.cancel)).setVisibility(View.GONE);
                    ((Button) confirmDialogView.findViewById(R.id.ok)).setVisibility(View.GONE);
                    confirmDialogView.findViewById(R.id.getPro).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //your business logic
                            confirmDialog.dismiss();

                            ((Main) itemView.getContext()).moveToRideInfo(rideBean);

                            /*if(rideBean.getRideViewType().equalsIgnoreCase("daily")){

                            } else {
                                ((Main) itemView.getContext()).moveToRideInfo(rideBean);
                            }*/

                        }
                    });
                    confirmDialog.show();
                } else {
                    ((HomePage) itemView.getContext()).moveToRideInfo(rideBean);
                }
            }
        });
    }
}
