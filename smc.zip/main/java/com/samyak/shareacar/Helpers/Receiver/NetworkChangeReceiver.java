package com.samyak.shareacar.Helpers.Receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.samyak.shareacar.Helpers.NetworkUtill;
import com.samyak.shareacar.HomePage;

public class NetworkChangeReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(final Context context, final Intent intent) {

        boolean IsConnected = NetworkUtill.getConnectivityStatusString(context);
        HomePage.connectionFlag = IsConnected;

        // Toast in here, you can retrieve other value like String from NetworkUtil
        // but you need some change in NetworkUtil Class
    }
}