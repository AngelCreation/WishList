package com.samyak.shareacar.Helpers;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;

/**
 * Created by hprajapati on 6/7/16.
 */
public class util {

    public static boolean checkConnection(Activity a) {
        ConnectivityManager connec = (ConnectivityManager) a.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connec != null && (
                (connec.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == android.net.NetworkInfo.State.CONNECTED) ||
                        (connec.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == android.net.NetworkInfo.State.CONNECTED))) {

//            try {
//                if (InetAddress.getByName("http://www.google.com").isReachable(1000))
//                {
            // host reachable
            return true;
//                }
//                else
//                {
//                    // host not reachable
//                    return false;
//                }
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
        } else if (connec != null && (
                (connec.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == android.net.NetworkInfo.State.DISCONNECTED) ||
                        (connec.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == android.net.NetworkInfo.State.DISCONNECTED))) {

            return false;
        }
        return false;


    }
}
